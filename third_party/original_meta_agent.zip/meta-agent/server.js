import express from 'express';
import cors from 'cors';
import fetch from 'node-fetch';

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Proxy for external APIs
app.post('/api/proxy', async (req, res) => {
  try {
    const { url, method = 'GET', headers = {}, body } = req.body;

    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
    };

    if (body && ['POST', 'PUT', 'PATCH'].includes(method)) {
      options.body = JSON.stringify(body);
    }

    const response = await fetch(url, options);
    const data = await response.text();

    res.json({
      status: response.status,
      statusText: response.statusText,
      headers: Object.fromEntries(response.headers.entries()),
      body: data,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// AI APIs
app.post('/api/ai/completions', async (req, res) => {
  try {
    const { apiKey, model = 'gpt-3.5-turbo', messages, temperature = 0.7 } = req.body;

    if (!apiKey) {
      return res.status(400).json({ error: 'API key required' });
    }

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ model, messages, temperature }),
    });

    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Weather API (free, no key needed)
app.get('/api/weather', async (req, res) => {
  try {
    const { city = 'London' } = req.query;
    const response = await fetch(
      `https://wttr.in/${encodeURIComponent(city)}?format=j1`
    );
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Crypto prices (CoinGecko - free API)
app.get('/api/crypto', async (req, res) => {
  try {
    const { coins = 'bitcoin,ethereum' } = req.query;
    const response = await fetch(
      `https://api.coingecko.com/api/v3/simple/price?ids=${coins}&vs_currencies=usd&include_24hr_change=true`
    );
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// News API (free tier)
app.get('/api/news', async (req, res) => {
  try {
    const { topic = 'technology' } = req.query;
    const response = await fetch(
      `https://newsapi.org/v2/everything?q=${encodeURIComponent(topic)}&pageSize=5&sortBy=publishedAt&apiKey=demo`
    );
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Public APIs list
app.get('/api/public-apis', async (req, res) => {
  try {
    const response = await fetch('https://api.publicapis.org/entries?category=blockchain&https=true');
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Test connection endpoint
app.get('/api/status', (req, res) => {
  res.json({
    status: 'online',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// Webhook receiver (for testing webhooks)
app.post('/api/webhook/test', (req, res) => {
  console.log('Webhook received:', req.body);
  res.json({
    received: true,
    timestamp: new Date().toISOString(),
    payload: req.body,
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Meta Agent API running on port ${PORT}`);
  console.log(`📡 Endpoints:`);
  console.log(`   GET  /api/status - System status`);
  console.log(`   GET  /api/weather?city=London - Weather data`);
  console.log(`   GET  /api/crypto?coins=bitcoin - Crypto prices`);
  console.log(`   GET  /api/news?topic=AI - News`);
  console.log(`   POST /api/proxy - Generic proxy`);
  console.log(`   POST /api/ai/completions - OpenAI`);
  console.log(`   POST /api/webhook/test - Test webhooks`);
});
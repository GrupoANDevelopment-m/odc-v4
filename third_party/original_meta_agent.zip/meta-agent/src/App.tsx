import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Brain, Database, Cpu, Sparkles, Network, GitBranch,
  Layers, Code2, Eye, Zap, Atom, Binary, Layers3,
  DatabaseZap, GitMerge, Settings, Play, Pause,
  RefreshCw, Trash2, Plus, ChevronRight, Terminal, Box,
  CircleDot, Hexagon, Pentagon, Square, Workflow, Link2,
  Globe, Cloud, Server, HardDrive, Wifi, Lock, Key,
  Plug, ArrowRight, CheckCircle, XCircle, AlertCircle,
  Clock, Activity, Zap as ZapIcon, Webhook, CloudOff, Route,
  Globe2, CloudRain, Bitcoin, Newspaper, Radar, Telescope
} from 'lucide-react';

// Types for Meta-Programming System
interface MetaNode {
  id: string;
  type: 'program' | 'memory' | 'data' | 'process' | 'reflex' | 'internet';
  label: string;
  x: number;
  y: number;
  connections: string[];
  metadata: Record<string, any>;
}

interface MetaRule {
  id: string;
  name: string;
  condition: string;
  action: string;
  active: boolean;
}

interface MemoryFragment {
  id: string;
  content: string;
  timestamp: number;
  importance: number;
  connections: string[];
}

interface DataSchema {
  id: string;
  name: string;
  fields: Array<{ name: string; type: string; nullable: boolean }>;
  relationships: Array<{ target: string; type: string }>;
}

interface ProcessThread {
  id: string;
  name: string;
  status: 'idle' | 'running' | 'paused' | 'completed';
  progress: number;
  logs: string[];
}

interface Integration {
  id: string;
  name: string;
  type: 'api' | 'database' | 'messaging' | 'storage' | 'ai' | 'webhook' | 'custom';
  status: 'connected' | 'disconnected' | 'error' | 'syncing';
  endpoint: string;
  lastSync: number;
  config: Record<string, any>;
  metrics: {
    requests: number;
    latency: number;
    uptime: number;
  };
}

interface WebhookEndpoint {
  id: string;
  name: string;
  url: string;
  events: string[];
  status: 'active' | 'paused';
  logs: Array<{ timestamp: number; event: string; status: 'success' | 'error' }>;
}

interface InternetData {
  type: 'weather' | 'crypto' | 'news' | 'ip' | 'time';
  data: any;
  timestamp: number;
  loading: boolean;
  error: string | null;
}

// Neural Network Visualization Component
const NeuralNetworkViz: React.FC<{ nodes: MetaNode[] }> = ({ nodes }) => (
  <svg className="w-full h-full" viewBox="0 0 400 300">
    <defs>
      <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
        <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(0,240,255,0.1)" strokeWidth="0.5"/>
      </pattern>
    </defs>
    <rect width="400" height="300" fill="url(#grid)"/>

    {nodes.map((node, i) =>
      node.connections.map((targetId, j) => {
        const target = nodes.find(n => n.id === targetId);
        if (!target) return null;
        return (
          <line
            key={`${i}-${j}`}
            x1={node.x} y1={node.y} x2={target.x} y2={target.y}
            stroke="rgba(0,240,255,0.3)"
            strokeWidth="1"
            strokeDasharray="5,5"
            style={{ animation: 'neural-pulse 2s ease-in-out infinite' }}
          />
        );
      })
    )}

    {nodes.map((node, i) => {
      const colors: Record<string, string> = {
        program: '#00f0ff',
        memory: '#b347ff',
        data: '#ff3d9a',
        process: '#ffd700',
        reflex: '#00ff88',
        internet: '#ff6b35'
      };
      return (
        <g key={node.id} className="cursor-pointer" style={{ animation: `float ${3 + i * 0.5}s ease-in-out infinite` }}>
          <circle
            cx={node.x} cy={node.y} r={25}
            fill={`url(#gradient-${node.type || 'program'})`}
            stroke={colors[node.type || 'program']}
            strokeWidth="2"
            style={{ filter: 'drop-shadow(0 0 10px currentColor)' }}
          />
          <text x={node.x} y={node.y + 4} textAnchor="middle" fill="white" fontSize="12">
            {node.label.charAt(0)}
          </text>
          <circle
            cx={node.x} cy={node.y} r={30}
            fill="none"
            stroke={colors[node.type || 'program']}
            strokeWidth="1"
            opacity="0.5"
            style={{ animation: 'pulse-ring 2s ease-out infinite' }}
          />
        </g>
      );
    })}

    <defs>
      <radialGradient id="gradient-program">
        <stop offset="0%" stopColor="rgba(0,240,255,0.8)"/>
        <stop offset="100%" stopColor="rgba(0,240,255,0.2)"/>
      </radialGradient>
      <radialGradient id="gradient-memory">
        <stop offset="0%" stopColor="rgba(179,71,255,0.8)"/>
        <stop offset="100%" stopColor="rgba(179,71,255,0.2)"/>
      </radialGradient>
      <radialGradient id="gradient-data">
        <stop offset="0%" stopColor="rgba(255,61,154,0.8)"/>
        <stop offset="100%" stopColor="rgba(255,61,154,0.2)"/>
      </radialGradient>
      <radialGradient id="gradient-process">
        <stop offset="0%" stopColor="rgba(255,215,0,0.8)"/>
        <stop offset="100%" stopColor="rgba(255,215,0,0.2)"/>
      </radialGradient>
      <radialGradient id="gradient-reflex">
        <stop offset="0%" stopColor="rgba(0,255,136,0.8)"/>
        <stop offset="100%" stopColor="rgba(0,255,136,0.2)"/>
      </radialGradient>
      <radialGradient id="gradient-internet">
        <stop offset="0%" stopColor="rgba(255,107,53,0.8)"/>
        <stop offset="100%" stopColor="rgba(255,107,53,0.2)"/>
      </radialGradient>
    </defs>
  </svg>
);

const BinaryRain: React.FC = () => {
  const [columns, setColumns] = useState<string[]>([]);

  useEffect(() => {
    const generateColumn = () => Array.from({ length: 30 }, () => Math.random() > 0.5 ? '1' : '0').join('\n');
    setColumns(Array.from({ length: 20 }, () => generateColumn()));
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden opacity-20 pointer-events-none">
      {columns.map((col, i) => (
        <div key={i} className="data-stream absolute" style={{
          left: `${i * 5}%`,
          animation: `binary-rain ${5 + Math.random() * 5}s linear infinite`,
          animationDelay: `${Math.random() * 5}s`
        }}>{col}</div>
      ))}
    </div>
  );
};

const MetaProgramEditor: React.FC<{ code: string; onChange: (code: string) => void }> = ({ code, onChange }) => (
  <div className="code-block h-full overflow-auto">
    <div className="flex items-center gap-2 mb-3 pb-2 border-b border-cyan-500/30">
      <span className="text-xs text-cyan-400 font-mono">META_LISP</span>
      <span className="text-xs text-gray-500">v1.0</span>
    </div>
    <textarea
      value={code}
      onChange={(e) => onChange(e.target.value)}
      className="w-full h-32 bg-transparent border-none outline-none resize-none font-mono text-sm text-gray-300 leading-relaxed"
      placeholder="(meta-define self-modifier (lambda (x) (transform x (reflect))))"
      spellCheck={false}
    />
    <div className="mt-2 flex gap-2">
      <span className="code-keyword">def</span>
      <span className="code-function">meta</span>
      <span className="code-variable">reflect</span>
      <span className="code-string">transform</span>
    </div>
  </div>
);

const MemoryOrbs: React.FC<{ memories: MemoryFragment[] }> = ({ memories }) => (
  <div className="relative w-full h-40 flex items-center justify-center">
    {memories.map((mem, i) => (
      <div key={mem.id} className="memory-orb absolute" style={{
        animationDelay: `${i * 0.5}s`,
        left: `${20 + i * 15}%`,
        top: `${30 + Math.sin(i) * 20}%`
      }} title={mem.content.substring(0, 50)}>
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-purple-500/30 to-transparent animate-pulse" />
      </div>
    ))}
    <svg className="absolute inset-0 w-full h-full pointer-events-none">
      {memories.slice(0, -1).map((_, i) => (
        <line key={`mem-${i}`} x1={`${20 + i * 15}%`} y1="50%" x2={`${20 + (i + 1) * 15}%`} y2={`${30 + Math.sin(i + 1) * 20}%`}
          stroke="rgba(179,71,255,0.3)" strokeWidth="1" strokeDasharray="4,4" />
      ))}
    </svg>
  </div>
);

const DataFlowViz: React.FC<{ schemas: DataSchema[] }> = ({ schemas }) => (
  <div className="space-y-3">
    {schemas.map((schema) => (
      <div key={schema.id} className="glass-panel p-4 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <Database className="w-4 h-4 text-cyan-400" />
          <span className="font-mono text-cyan-400">{schema.name}</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {schema.fields.map((field, j) => (
            <span key={j} className={`px-2 py-1 rounded text-xs font-mono ${
              field.type === 'string' ? 'bg-pink-500/20 text-pink-400' :
              field.type === 'number' ? 'bg-purple-500/20 text-purple-400' : 'bg-green-500/20 text-green-400'
            }`}>{field.name}: {field.type}</span>
          ))}
        </div>
        {schema.relationships.length > 0 && (
          <div className="mt-2 flex items-center gap-1 text-xs text-gray-500">
            <GitMerge className="w-3 h-3" />
            {schema.relationships.map((rel, j) => <span key={j}>{rel.target}({rel.type})</span>)}
          </div>
        )}
      </div>
    ))}
  </div>
);

const ProcessMonitor: React.FC<{ processes: ProcessThread[] }> = ({ processes }) => (
  <div className="space-y-2">
    {processes.map((proc) => (
      <div key={proc.id} className="glass-panel p-3 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${
              proc.status === 'running' ? 'bg-green-400 animate-pulse' :
              proc.status === 'paused' ? 'bg-yellow-400' : proc.status === 'completed' ? 'bg-cyan-400' : 'bg-gray-400'
            }`} />
            <span className="font-mono text-sm text-gray-300">{proc.name}</span>
          </div>
          <span className="text-xs text-gray-500">{proc.status}</span>
        </div>
        <div className="w-full h-1 bg-gray-800 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 transition-all duration-500" style={{ width: `${proc.progress}%` }} />
        </div>
        {proc.logs.length > 0 && <div className="mt-2 text-xs font-mono text-gray-500 max-h-16 overflow-y-auto">{proc.logs[proc.logs.length - 1]}</div>}
      </div>
    ))}
  </div>
);

const IntegrationCard: React.FC<{ integration: Integration; onToggle: () => void; onTest: () => void }> = ({ integration, onToggle, onTest }) => {
  const statusIcons = {
    connected: <CheckCircle className="w-4 h-4 text-green-400" />,
    disconnected: <CloudOff className="w-4 h-4 text-gray-400" />,
    error: <XCircle className="w-4 h-4 text-red-400" />,
    syncing: <RefreshCw className="w-4 h-4 text-yellow-400 animate-spin" />
  };
  const typeIcons: Record<string, JSX.Element> = {
    api: <Route className="w-5 h-5" />,
    database: <Database className="w-5 h-5" />,
    messaging: <ZapIcon className="w-5 h-5" />,
    storage: <HardDrive className="w-5 h-5" />,
    ai: <Brain className="w-5 h-5" />,
    webhook: <Webhook className="w-5 h-5" />,
    custom: <Plug className="w-5 h-5" />
  };

  return (
    <div className="glass-panel p-4 rounded-lg">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${
            integration.type === 'api' ? 'bg-cyan-500/20 text-cyan-400' :
            integration.type === 'database' ? 'bg-purple-500/20 text-purple-400' :
            integration.type === 'messaging' ? 'bg-green-500/20 text-green-400' :
            integration.type === 'storage' ? 'bg-yellow-500/20 text-yellow-400' :
            integration.type === 'ai' ? 'bg-pink-500/20 text-pink-400' :
            'bg-gray-500/20 text-gray-400'
          }`}>
            {typeIcons[integration.type]}
          </div>
          <div>
            <h4 className="font-medium text-white">{integration.name}</h4>
            <p className="text-xs text-gray-500 font-mono truncate">{integration.endpoint}</p>
          </div>
        </div>
        {statusIcons[integration.status]}
      </div>

      <div className="grid grid-cols-3 gap-2 mb-3">
        <div className="text-center p-2 rounded bg-gray-800/50">
          <div className="text-lg font-bold text-cyan-400">{integration.metrics.requests}</div>
          <div className="text-xs text-gray-500">Requests</div>
        </div>
        <div className="text-center p-2 rounded bg-gray-800/50">
          <div className="text-lg font-bold text-purple-400">{integration.metrics.latency}ms</div>
          <div className="text-xs text-gray-500">Latency</div>
        </div>
        <div className="text-center p-2 rounded bg-gray-800/50">
          <div className="text-lg font-bold text-green-400">{integration.metrics.uptime}%</div>
          <div className="text-xs text-gray-500">Uptime</div>
        </div>
      </div>

      <div className="flex gap-2">
        <button onClick={onToggle} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
          integration.status === 'connected'
            ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
            : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
        }`}>
          {integration.status === 'connected' ? 'Disconnect' : 'Connect'}
        </button>
        <button onClick={onTest} className="px-4 py-2 rounded-lg bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 transition-colors">
          Test
        </button>
      </div>
    </div>
  );
};

const WebhookManager: React.FC<{ webhooks: WebhookEndpoint[]; onToggle: (id: string) => void }> = ({ webhooks, onToggle }) => (
  <div className="space-y-3">
    {webhooks.map((webhook) => (
      <div key={webhook.id} className="glass-panel p-4 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Webhook className="w-4 h-4 text-cyan-400" />
            <span className="font-medium text-white">{webhook.name}</span>
          </div>
          <button onClick={() => onToggle(webhook.id)} className={`w-12 h-6 rounded-full transition-colors ${
            webhook.status === 'active' ? 'bg-green-500' : 'bg-gray-600'
          }`}>
            <div className={`w-4 h-4 rounded-full bg-white shadow transition-transform ${webhook.status === 'active' ? 'translate-x-7' : 'translate-x-1'}`} />
          </button>
        </div>
        <div className="font-mono text-xs text-gray-500 mb-2 truncate">{webhook.url}</div>
        <div className="flex flex-wrap gap-1 mb-2">
          {webhook.events.map((event, i) => (
            <span key={i} className="px-2 py-1 rounded bg-purple-500/20 text-purple-400 text-xs">{event}</span>
          ))}
        </div>
        {webhook.logs.length > 0 && (
          <div className="text-xs text-gray-500">
            Last: {webhook.logs[webhook.logs.length - 1].event} - {webhook.logs[webhook.logs.length - 1].status}
          </div>
        )}
      </div>
    ))}
  </div>
);

const APIExplorer: React.FC<{ onTest: (method: string, path: string) => void }> = ({ onTest }) => {
  const [method, setMethod] = useState('GET');
  const [path, setPath] = useState('/api/v1/meta-agent/status');

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <select value={method} onChange={(e) => setMethod(e.target.value)} className="px-3 py-2 rounded-lg bg-gray-800 border border-cyan-500/30 text-cyan-400 font-mono text-sm">
          <option value="GET">GET</option>
          <option value="POST">POST</option>
          <option value="PUT">PUT</option>
          <option value="DELETE">DELETE</option>
          <option value="PATCH">PATCH</option>
        </select>
        <input type="text" value={path} onChange={(e) => setPath(e.target.value)} className="flex-1 px-3 py-2 rounded-lg bg-gray-800 border border-cyan-500/30 text-gray-300 font-mono text-sm outline-none focus:border-cyan-500" />
      </div>
      <button onClick={() => onTest(method, path)} className="w-full py-3 rounded-lg bg-gradient-to-r from-cyan-500 to-purple-500 text-white font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-2">
        <ZapIcon className="w-4 h-4" />
        Execute Request
      </button>
      <div className="code-block p-4 rounded-lg">
        <div className="text-xs text-gray-500 mb-2">Response Preview</div>
        <pre className="text-sm text-green-400 font-mono overflow-x-auto">{`{
  "status": "online",
  "version": "1.0.0",
  "capabilities": ["meta-programming", "meta-memory", "integrations"],
  "uptime": 99.97
}`}</pre>
      </div>
    </div>
  );
};

const DataStreamMonitor: React.FC<{ streams: Array<{ name: string; rate: string; status: string }> }> = ({ streams }) => (
  <div className="space-y-2">
    {streams.map((stream, i) => (
      <div key={i} className="glass-panel p-3 rounded-lg flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-green-400 animate-pulse" />
          <span className="text-sm text-gray-300">{stream.name}</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-xs font-mono text-cyan-400">{stream.rate}/s</span>
          <div className={`w-2 h-2 rounded-full ${stream.status === 'active' ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
        </div>
      </div>
    ))}
  </div>
);

// Internet Real Data Component
const InternetPanel: React.FC<{ addLog: (msg: string) => void }> = ({ addLog }) => {
  const [weather, setWeather] = useState<any>(null);
  const [crypto, setCrypto] = useState<any>(null);
  const [news, setNews] = useState<any>(null);
  const [ipInfo, setIpInfo] = useState<any>(null);
  const [loading, setLoading] = useState<Record<string, boolean>>({});
  const [city, setCity] = useState('London');
  const [customUrl, setCustomUrl] = useState('');

  const fetchWeather = async () => {
    setLoading(prev => ({ ...prev, weather: true }));
    try {
      addLog(`Fetching weather for ${city}...`);
      const response = await fetch(`https://wttr.in/${encodeURIComponent(city)}?format=j1`);
      const data = await response.json();
      setWeather(data);
      addLog(`Weather data received: ${data.current_condition?.[0]?.temp_C}°C`);
    } catch (err: any) {
      addLog(`Weather error: ${err.message}`);
    }
    setLoading(prev => ({ ...prev, weather: false }));
  };

  const fetchCrypto = async () => {
    setLoading(prev => ({ ...prev, crypto: true }));
    try {
      addLog('Fetching crypto prices...');
      const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd&include_24hr_change=true');
      const data = await response.json();
      setCrypto(data);
      addLog(`Crypto: BTC $${data.bitcoin?.usd}, ETH $${data.ethereum?.usd}`);
    } catch (err: any) {
      addLog(`Crypto error: ${err.message}`);
    }
    setLoading(prev => ({ ...prev, crypto: false }));
  };

  const fetchNews = async () => {
    setLoading(prev => ({ ...prev, news: true }));
    try {
      addLog('Fetching latest AI news...');
      const response = await fetch('https://newsapi.org/v2/everything?q=artificial+intelligence&pageSize=5&sortBy=publishedAt&apiKey=demo');
      const data = await response.json();
      setNews(data);
      addLog(`News: ${data.articles?.length || 0} articles`);
    } catch (err: any) {
      addLog(`News error: ${err.message}`);
    }
    setLoading(prev => ({ ...prev, news: false }));
  };

  const fetchIP = async () => {
    setLoading(prev => ({ ...prev, ip: true }));
    try {
      addLog('Getting your IP info...');
      const response = await fetch('https://ipapi.co/json/');
      const data = await response.json();
      setIpInfo(data);
      addLog(`IP: ${data.ip} from ${data.city}, ${data.country}`);
    } catch (err: any) {
      addLog(`IP error: ${err.message}`);
    }
    setLoading(prev => ({ ...prev, ip: false }));
  };

  const testCustomURL = async () => {
    if (!customUrl) return;
    setLoading(prev => ({ ...prev, custom: true }));
    try {
      addLog(`Testing: ${customUrl}`);
      const response = await fetch(customUrl);
      const text = await response.text();
      addLog(`Response: ${response.status} (${text.length} bytes)`);
    } catch (err: any) {
      addLog(`Error: ${err.message}`);
    }
    setLoading(prev => ({ ...prev, custom: false }));
  };

  return (
    <div className="space-y-4">
      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-2">
        <button onClick={fetchIP} disabled={loading.ip} className="glass-panel p-3 rounded-lg flex items-center gap-2 hover:bg-orange-500/20 transition-colors">
          <Globe2 className="w-4 h-4 text-orange-400" />
          <span className="text-sm text-gray-300">My IP</span>
          {loading.ip && <RefreshCw className="w-3 h-3 animate-spin" />}
        </button>
        <button onClick={fetchCrypto} disabled={loading.crypto} className="glass-panel p-3 rounded-lg flex items-center gap-2 hover:bg-yellow-500/20 transition-colors">
          <Bitcoin className="w-4 h-4 text-yellow-400" />
          <span className="text-sm text-gray-300">Crypto</span>
          {loading.crypto && <RefreshCw className="w-3 h-3 animate-spin" />}
        </button>
        <button onClick={fetchWeather} disabled={loading.weather} className="glass-panel p-3 rounded-lg flex items-center gap-2 hover:bg-blue-500/20 transition-colors">
          <CloudRain className="w-4 h-4 text-blue-400" />
          <span className="text-sm text-gray-300">Weather</span>
          {loading.weather && <RefreshCw className="w-3 h-3 animate-spin" />}
        </button>
        <button onClick={fetchNews} disabled={loading.news} className="glass-panel p-3 rounded-lg flex items-center gap-2 hover:bg-purple-500/20 transition-colors">
          <Newspaper className="w-4 h-4 text-purple-400" />
          <span className="text-sm text-gray-300">News</span>
          {loading.news && <RefreshCw className="w-3 h-3 animate-spin" />}
        </button>
      </div>

      {/* Weather Search */}
      <div className="glass-panel p-4 rounded-lg">
        <div className="flex gap-2 mb-3">
          <input
            type="text"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            placeholder="City name..."
            className="flex-1 px-3 py-2 rounded-lg bg-gray-800 border border-blue-500/30 text-gray-300 font-mono text-sm outline-none focus:border-blue-500"
          />
          <button onClick={fetchWeather} className="px-4 py-2 rounded-lg bg-blue-500/20 text-blue-400 hover:bg-blue-500/30">
            Search
          </button>
        </div>
        {weather?.current_condition && (
          <div className="flex items-center gap-4">
            <div className="text-4xl">{weather.current_condition[0].weatherCode === '113' ? '☀️' : '☁️'}</div>
            <div>
              <div className="text-2xl font-bold text-white">{weather.current_condition[0].temp_C}°C</div>
              <div className="text-sm text-gray-400">{weather?.nearest_area?.[0]?.areaName?.[0]?.value}</div>
            </div>
            <div className="ml-auto text-right text-xs text-gray-500">
              <div>Humidity: {weather.current_condition[0].humidity}%</div>
              <div>Wind: {weather.current_condition[0].windspeedKmph} km/h</div>
            </div>
          </div>
        )}
      </div>

      {/* Crypto Prices */}
      {crypto && (
        <div className="glass-panel p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-3">
            <Bitcoin className="w-4 h-4 text-yellow-400" />
            <span className="font-medium text-white">Crypto Prices</span>
          </div>
          <div className="space-y-2">
            {crypto.bitcoin && (
              <div className="flex items-center justify-between p-2 rounded bg-gray-800/50">
                <div className="flex items-center gap-2">
                  <span className="text-yellow-400">₿</span>
                  <span className="text-white">Bitcoin</span>
                </div>
                <div className="text-right">
                  <div className="font-bold text-white">${crypto.bitcoin.usd.toLocaleString()}</div>
                  <div className={`text-xs ${(crypto.bitcoin.usd_24h_change || 0) > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {(crypto.bitcoin.usd_24h_change || 0) > 0 ? '▲' : '▼'} {Math.abs(crypto.bitcoin.usd_24h_change || 0).toFixed(2)}%
                  </div>
                </div>
              </div>
            )}
            {crypto.ethereum && (
              <div className="flex items-center justify-between p-2 rounded bg-gray-800/50">
                <div className="flex items-center gap-2">
                  <span className="text-purple-400">Ξ</span>
                  <span className="text-white">Ethereum</span>
                </div>
                <div className="text-right">
                  <div className="font-bold text-white">${crypto.ethereum.usd.toLocaleString()}</div>
                  <div className={`text-xs ${(crypto.ethereum.usd_24h_change || 0) > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {(crypto.ethereum.usd_24h_change || 0) > 0 ? '▲' : '▼'} {Math.abs(crypto.ethereum.usd_24h_change || 0).toFixed(2)}%
                  </div>
                </div>
              </div>
            )}
            {crypto.solana && (
              <div className="flex items-center justify-between p-2 rounded bg-gray-800/50">
                <div className="flex items-center gap-2">
                  <span className="text-green-400">◎</span>
                  <span className="text-white">Solana</span>
                </div>
                <div className="text-right">
                  <div className="font-bold text-white">${crypto.solana.usd.toLocaleString()}</div>
                  <div className={`text-xs ${(crypto.solana.usd_24h_change || 0) > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {(crypto.solana.usd_24h_change || 0) > 0 ? '▲' : '▼'} {Math.abs(crypto.solana.usd_24h_change || 0).toFixed(2)}%
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* IP Info */}
      {ipInfo && (
        <div className="glass-panel p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-3">
            <Radar className="w-4 h-4 text-orange-400" />
            <span className="font-medium text-white">Your Location</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="p-2 rounded bg-gray-800/50">
              <div className="text-gray-500">IP</div>
              <div className="text-white font-mono">{ipInfo.ip}</div>
            </div>
            <div className="p-2 rounded bg-gray-800/50">
              <div className="text-gray-500">Country</div>
              <div className="text-white">{ipInfo.country_name}</div>
            </div>
            <div className="p-2 rounded bg-gray-800/50">
              <div className="text-gray-500">City</div>
              <div className="text-white">{ipInfo.city}</div>
            </div>
            <div className="p-2 rounded bg-gray-800/50">
              <div className="text-gray-500">ISP</div>
              <div className="text-white truncate">{ipInfo.org}</div>
            </div>
          </div>
        </div>
      )}

      {/* News */}
      {news?.articles && news.articles.length > 0 && (
        <div className="glass-panel p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-3">
            <Newspaper className="w-4 h-4 text-purple-400" />
            <span className="font-medium text-white">Latest AI News</span>
          </div>
          <div className="space-y-2">
            {news.articles.slice(0, 3).map((article: any, i: number) => (
              <a key={i} href={article.url} target="_blank" rel="noopener noreferrer" className="block p-2 rounded bg-gray-800/50 hover:bg-gray-800 transition-colors">
                <div className="text-sm text-white truncate">{article.title}</div>
                <div className="text-xs text-gray-500">{article.source?.name} • {new Date(article.publishedAt).toLocaleDateString()}</div>
              </a>
            ))}
          </div>
        </div>
      )}

      {/* Custom URL Test */}
      <div className="glass-panel p-4 rounded-lg">
        <div className="flex items-center gap-2 mb-3">
          <Telescope className="w-4 h-4 text-cyan-400" />
          <span className="font-medium text-white">Test Any URL</span>
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            value={customUrl}
            onChange={(e) => setCustomUrl(e.target.value)}
            placeholder="https://api.example.com/data"
            className="flex-1 px-3 py-2 rounded-lg bg-gray-800 border border-cyan-500/30 text-gray-300 font-mono text-sm outline-none focus:border-cyan-500"
          />
          <button onClick={testCustomURL} disabled={loading.custom} className="px-4 py-2 rounded-lg bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30">
            {loading.custom ? <RefreshCw className="w-4 h-4 animate-spin" /> : 'Go'}
          </button>
        </div>
      </div>
    </div>
  );
};

// Main MetaAgent Component
export default function MetaAgent() {
  const [activeTab, setActiveTab] = useState<'program' | 'memory' | 'data' | 'process' | 'reflex' | 'integrations' | 'internet'>('program');
  const [metaNodes] = useState<MetaNode[]>([
    { id: 'p1', type: 'program', label: 'MetaCode', x: 100, y: 150, connections: ['m1', 'd1'], metadata: {} },
    { id: 'm1', type: 'memory', label: 'Memory', x: 200, y: 80, connections: ['p2', 'd2'], metadata: {} },
    { id: 'd1', type: 'data', label: 'Schema', x: 200, y: 220, connections: ['m2'], metadata: {} },
    { id: 'p2', type: 'program', label: 'Reflect', x: 300, y: 100, connections: ['r1'], metadata: {} },
    { id: 'm2', type: 'memory', label: 'State', x: 300, y: 200, connections: ['p2'], metadata: {} },
    { id: 'd2', type: 'data', label: 'Stream', x: 280, y: 150, connections: ['r1'], metadata: {} },
    { id: 'r1', type: 'reflex', label: 'Reflex', x: 350, y: 150, connections: ['p1'], metadata: {} },
    { id: 'i1', type: 'internet', label: 'Internet', x: 150, y: 250, connections: ['d1', 'r1'], metadata: {} },
  ]);

  const [metaRules, setMetaRules] = useState<MetaRule[]>([
    { id: 'rule1', name: 'Auto-Reflect', condition: 'onModify', action: 'reflect()', active: true },
    { id: 'rule2', name: 'Memory Optimize', condition: 'memory > 80%', action: 'consolidate()', active: true },
    { id: 'rule3', name: 'Data Transform', condition: 'newSchema', action: 'validate()', active: false },
    { id: 'rule4', name: 'API Sync', condition: 'onDataChange', action: 'sync(external)', active: true },
  ]);

  const [memories] = useState<MemoryFragment[]>([
    { id: 'mem1', content: 'Meta patterns emerge from recursive self-reference', timestamp: Date.now() - 60000, importance: 0.9, connections: ['mem2'] },
    { id: 'mem2', content: 'Self-modification enables autonomous growth', timestamp: Date.now() - 120000, importance: 0.8, connections: ['mem3'] },
    { id: 'mem3', content: 'Data schemas evolve with context', timestamp: Date.now() - 180000, importance: 0.7, connections: ['mem1'] },
    { id: 'mem4', content: 'Reflex loops enable adaptive behavior', timestamp: Date.now() - 240000, importance: 0.85, connections: [] },
  ]);

  const [schemas] = useState<DataSchema[]>([
    { id: 's1', name: 'MetaNode', fields: [
      { name: 'id', type: 'string', nullable: false },
      { name: 'type', type: 'string', nullable: false },
      { name: 'metadata', type: 'object', nullable: true },
      { name: 'connections', type: 'array', nullable: true },
    ], relationships: [{ target: 'MetaRule', type: 'references' }] },
    { id: 's2', name: 'MemoryFragment', fields: [
      { name: 'content', type: 'string', nullable: false },
      { name: 'timestamp', type: 'number', nullable: false },
      { name: 'importance', type: 'number', nullable: false },
    ], relationships: [] },
    { id: 's3', name: 'Integration', fields: [
      { name: 'endpoint', type: 'string', nullable: false },
      { name: 'status', type: 'string', nullable: false },
      { name: 'metrics', type: 'object', nullable: true },
    ], relationships: [{ target: 'MetaRule', type: 'triggers' }] },
  ]);

  const [processes, setProcesses] = useState<ProcessThread[]>([
    { id: 'proc1', name: 'Meta-Compiling', status: 'running', progress: 67, logs: ['Parsing meta-syntax...', 'Generating AST...', 'Optimizing...'] },
    { id: 'proc2', name: 'Memory-GC', status: 'idle', progress: 0, logs: [] },
    { id: 'proc3', name: 'Schema-Evolution', status: 'paused', progress: 45, logs: ['Analyzing relationships...'] },
  ]);

  const [integrations, setIntegrations] = useState<Integration[]>([
    { id: 'int1', name: 'OpenAI API', type: 'ai', status: 'connected', endpoint: 'https://api.openai.com/v1', lastSync: Date.now() - 300000, config: { model: 'gpt-4' }, metrics: { requests: 1247, latency: 45, uptime: 99.9 } },
    { id: 'int2', name: 'PostgreSQL', type: 'database', status: 'connected', endpoint: 'postgres://db.meta-agent.io:5432', lastSync: Date.now() - 60000, config: {}, metrics: { requests: 8934, latency: 12, uptime: 99.99 } },
    { id: 'int3', name: 'Slack Webhook', type: 'webhook', status: 'connected', endpoint: 'https://hooks.slack.com/services/xxx', lastSync: Date.now() - 120000, config: { channel: '#alerts' }, metrics: { requests: 342, latency: 89, uptime: 98.5 } },
    { id: 'int4', name: 'AWS S3', type: 'storage', status: 'syncing', endpoint: 's3://meta-agent-bucket', lastSync: Date.now() - 5000, config: { region: 'us-east-1' }, metrics: { requests: 156, latency: 234, uptime: 99.7 } },
    { id: 'int5', name: 'Discord Bot', type: 'messaging', status: 'disconnected', endpoint: 'discord://bot.meta-agent.io', lastSync: 0, config: {}, metrics: { requests: 0, latency: 0, uptime: 0 } },
    { id: 'int6', name: 'Custom API', type: 'api', status: 'error', endpoint: 'https://api.example.com', lastSync: Date.now() - 3600000, config: {}, metrics: { requests: 23, latency: 0, uptime: 45.2 } },
  ]);

  const [webhooks, setWebhooks] = useState<WebhookEndpoint[]>([
    { id: 'wh1', name: 'User Events', url: 'https://meta-agent.io/webhooks/user', events: ['user.created', 'user.updated', 'user.deleted'], status: 'active', logs: [{ timestamp: Date.now() - 5000, event: 'user.created', status: 'success' }] },
    { id: 'wh2', name: 'System Alerts', url: 'https://meta-agent.io/webhooks/alerts', events: ['system.error', 'system.warning'], status: 'active', logs: [] },
    { id: 'wh3', name: 'Data Sync', url: 'https://meta-agent.io/webhooks/sync', events: ['data.changed'], status: 'paused', logs: [{ timestamp: Date.now() - 300000, event: 'data.changed', status: 'success' }] },
  ]);

  const [dataStreams] = useState([
    { name: 'API Requests', rate: '1,247', status: 'active' },
    { name: 'Memory Updates', rate: '89', status: 'active' },
    { name: 'Integration Sync', rate: '23', status: 'active' },
    { name: 'Webhook Events', rate: '156', status: 'active' },
  ]);

  const [metaCode, setMetaCode] = useState(`(meta-define self-modifier
  (lambda (program)
    (let ((ast (parse program)))
      (transform
        (reflect ast)
        (optimize (dead-code-eliminate)))))))

(meta-define reflex-loop
  (lambda (state)
    (if (condition-met state)
        (execute (plan state))
        (recur (observe state)))))

(meta-define integration-sync
  (lambda (external-systems)
    (connect external-systems)
    (stream-data (filter relevant))
    (apply-meta-rules)))`);

  const [consoleOutput, setConsoleOutput] = useState<string[]>([
    '[META-SYSTEM] Initialized',
    '[META-PROGRAM] Loading self-modifier...',
    '[MEMORY] 4 fragments loaded',
    '[INTEGRATIONS] 6 services configured',
    '[INTERNET] Real-time data enabled',
    '[REFLEX] Active monitoring'
  ]);

  const consoleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (consoleRef.current) consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
  }, [consoleOutput]);

  const addLog = useCallback((message: string) => {
    setConsoleOutput(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`]);
  }, []);

  const handleExecuteCode = () => {
    addLog('Executing meta-program...');
    setProcessStatus('proc1', 'running', 75);
    setTimeout(() => {
      addLog('Meta-compilation complete');
      addLog('Self-modification applied');
    }, 1500);
  };

  const setProcessStatus = (id: string, status: ProcessThread['status'], progress: number) => {
    setProcesses(prev => prev.map(p => p.id === id ? { ...p, status, progress, logs: [...p.logs, `${status}: ${progress}%`] } : p));
  };

  const toggleRule = (id: string) => {
    setMetaRules(prev => prev.map(r => r.id === id ? { ...r, active: !r.active } : r));
    addLog('Rule toggled');
  };

  const toggleIntegration = (id: string) => {
    setIntegrations(prev => prev.map(int => {
      if (int.id === id) {
        const newStatus = int.status === 'connected' ? 'disconnected' : 'connected';
        addLog(`${int.name} ${newStatus}`);
        return { ...int, status: newStatus, metrics: newStatus === 'connected' ? { ...int.metrics, uptime: 100 } : int.metrics };
      }
      return int;
    }));
  };

  const toggleWebhook = (id: string) => {
    setWebhooks(prev => prev.map(wh => wh.id === id ? { ...wh, status: wh.status === 'active' ? 'paused' : 'active' } : wh));
    addLog('Webhook status updated');
  };

  const testIntegration = (id: string) => {
    addLog(`Testing connection...`);
    setTimeout(() => addLog('Connection successful'), 1000);
  };

  const testAPI = (method: string, path: string) => {
    addLog(`${method} ${path}`);
    addLog('Request executed successfully');
  };

  const tabs = [
    { id: 'program' as const, icon: Code2, label: 'Meta-Programação', color: 'cyan' },
    { id: 'memory' as const, icon: Brain, label: 'Meta-Memória', color: 'purple' },
    { id: 'data' as const, icon: Database, label: 'Meta-Data', color: 'pink' },
    { id: 'process' as const, icon: Cpu, label: 'Meta-Processo', color: 'gold' },
    { id: 'reflex' as const, icon: Zap, label: 'Meta-Reflexo', color: 'green' },
    { id: 'integrations' as const, icon: Link2, label: 'Integrações', color: 'blue' },
    { id: 'internet' as const, icon: Globe2, label: '🌐 Internet', color: 'orange' },
  ];

  return (
    <div className="min-h-screen bg-gradient-radial neural-bg relative overflow-hidden">
      <BinaryRain />

      <header className="relative z-10 p-6 border-b border-cyan-500/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="relative">
              <Brain className="w-12 h-12 text-cyan-400 glow-text" />
              <div className="absolute -inset-2 bg-cyan-400/20 rounded-full blur-xl animate-pulse" />
            </div>
            <div>
              <h1 className="font-orbitron text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400">
                META AGENT
              </h1>
              <p className="text-sm text-gray-400 font-mono">Self-Modifying • Meta-Recursive • Adaptive • Connected • Online</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="glass-panel px-4 py-2 rounded-lg flex items-center gap-3">
              <div className="flex gap-1">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                <div className="w-2 h-2 rounded-full bg-orange-400 animate-pulse" />
              </div>
              <span className="text-xs font-mono text-gray-400">ONLINE + LIVE DATA</span>
            </div>
            <button className="glass-panel px-4 py-2 rounded-lg hover:bg-cyan-400/10 transition-colors">
              <Settings className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>
      </header>

      <nav className="relative z-10 px-6 py-4">
        <div className="flex gap-2 overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-all whitespace-nowrap ${
                  isActive ? `glass-panel border-2 ${tab.color === 'cyan' ? 'border-cyan-500/50' : tab.color === 'purple' ? 'border-purple-500/50' : tab.color === 'pink' ? 'border-pink-500/50' : tab.color === 'orange' ? 'border-orange-500/50 shadow-lg shadow-orange-500/20' : 'border-blue-500/50'}` : 'hover:bg-white/5'
                }`}>
                <Icon className={`w-5 h-5 ${isActive ? `text-${tab.color === 'gold' ? 'yellow' : tab.color}-400` : 'text-gray-400'}`} />
                <span className={`font-medium ${isActive ? 'text-white' : 'text-gray-400'}`}>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      <main className="relative z-10 p-6 grid grid-cols-12 gap-6">
        <div className="col-span-4 glass-panel rounded-2xl p-6 neon-border relative overflow-hidden scan-effect">
          <div className="flex items-center gap-2 mb-4">
            <Network className="w-5 h-5 text-cyan-400" />
            <h2 className="font-orbitron text-lg text-cyan-400">META NETWORK</h2>
          </div>
          <div className="h-80 relative">
            <NeuralNetworkViz nodes={metaNodes} />
          </div>

          <div className="mt-6 grid grid-cols-4 gap-2">
            <div className="text-center p-2 rounded-lg bg-cyan-500/10">
              <div className="text-xl font-bold text-cyan-400">{metaNodes.filter(n => n.type === 'program').length}</div>
              <div className="text-xs text-gray-400">Programs</div>
            </div>
            <div className="text-center p-2 rounded-lg bg-purple-500/10">
              <div className="text-xl font-bold text-purple-400">{memories.length}</div>
              <div className="text-xs text-gray-400">Memory</div>
            </div>
            <div className="text-center p-2 rounded-lg bg-pink-500/10">
              <div className="text-xl font-bold text-pink-400">{schemas.length}</div>
              <div className="text-xs text-gray-400">Schemas</div>
            </div>
            <div className="text-center p-2 rounded-lg bg-orange-500/10">
              <div className="text-xl font-bold text-orange-400">{integrations.filter(i => i.status === 'connected').length}</div>
              <div className="text-xs text-gray-400">Online</div>
            </div>
          </div>
        </div>

        <div className="col-span-5 glass-panel rounded-2xl p-6 neon-border">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              {activeTab === 'program' && <Code2 className="w-5 h-5 text-cyan-400" />}
              {activeTab === 'memory' && <Brain className="w-5 h-5 text-purple-400" />}
              {activeTab === 'data' && <Database className="w-5 h-5 text-pink-400" />}
              {activeTab === 'process' && <Cpu className="w-5 h-5 text-yellow-400" />}
              {activeTab === 'reflex' && <Zap className="w-5 h-5 text-green-400" />}
              {activeTab === 'integrations' && <Link2 className="w-5 h-5 text-blue-400" />}
              {activeTab === 'internet' && <Globe2 className="w-5 h-5 text-orange-400" />}
              <h2 className="font-orbitron text-lg">
                {activeTab === 'program' && <span className="text-cyan-400">META-PROGRAM EDITOR</span>}
                {activeTab === 'memory' && <span className="text-purple-400">META-MEMORY CLUSTERS</span>}
                {activeTab === 'data' && <span className="text-pink-400">META-DATA SCHEMA</span>}
                {activeTab === 'process' && <span className="text-yellow-400">META-PROCESS MONITOR</span>}
                {activeTab === 'reflex' && <span className="text-green-400">META-REFLEX RULES</span>}
                {activeTab === 'integrations' && <span className="text-blue-400">SYSTEM INTEGRATIONS</span>}
                {activeTab === 'internet' && <span className="text-orange-400">REAL-TIME INTERNET DATA</span>}
              </h2>
            </div>
            {activeTab === 'program' && (
              <button onClick={handleExecuteCode} className="flex items-center gap-2 px-4 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 rounded-lg transition-colors">
                <Play className="w-4 h-4 text-cyan-400" />
                <span className="text-cyan-400 font-medium">Execute</span>
              </button>
            )}
          </div>

          <div className="h-96 overflow-auto">
            {activeTab === 'program' && <MetaProgramEditor code={metaCode} onChange={setMetaCode} />}
            {activeTab === 'memory' && (
              <div className="space-y-4">
                <MemoryOrbs memories={memories} />
                <div className="space-y-2">
                  {memories.map((mem) => (
                    <div key={mem.id} className="glass-panel p-4 rounded-lg">
                      <p className="text-gray-300">{mem.content}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-xs text-gray-500">{new Date(mem.timestamp).toLocaleTimeString()}</span>
                        <div className="w-20 h-1 bg-gray-800 rounded-full overflow-hidden">
                          <div className="h-full bg-purple-500" style={{ width: `${mem.importance * 100}%` }} />
                        </div>
                        <span className="text-xs text-purple-400">{Math.round(mem.importance * 100)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {activeTab === 'data' && <DataFlowViz schemas={schemas} />}
            {activeTab === 'process' && <ProcessMonitor processes={processes} />}
            {activeTab === 'reflex' && (
              <div className="space-y-3">
                {metaRules.map((rule) => (
                  <div key={rule.id} className="glass-panel p-4 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <button onClick={() => toggleRule(rule.id)} className={`w-10 h-6 rounded-full transition-colors ${rule.active ? 'bg-green-500' : 'bg-gray-600'}`}>
                        <div className={`w-4 h-4 rounded-full bg-white shadow transition-transform ${rule.active ? 'translate-x-5' : 'translate-x-1'}`} />
                      </button>
                      <div>
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-yellow-400" />
                          <span className="font-medium text-white">{rule.name}</span>
                        </div>
                        <div className="text-xs text-gray-400 mt-1">
                          <span className="text-cyan-400">{rule.condition}</span>
                          <span className="mx-2">→</span>
                          <span className="text-purple-400">{rule.action}</span>
                        </div>
                      </div>
                    </div>
                    <div className={`w-2 h-2 rounded-full ${rule.active ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
                  </div>
                ))}
              </div>
            )}
            {activeTab === 'integrations' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  {integrations.slice(0, 4).map((int) => (
                    <IntegrationCard key={int.id} integration={int} onToggle={() => toggleIntegration(int.id)} onTest={() => testIntegration(int.id)} />
                  ))}
                </div>
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-400 mb-2 flex items-center gap-2">
                    <Webhook className="w-4 h-4" />
                    Webhooks
                  </h4>
                  <WebhookManager webhooks={webhooks} onToggle={toggleWebhook} />
                </div>
              </div>
            )}
            {activeTab === 'internet' && <InternetPanel addLog={addLog} />}
          </div>
        </div>

        <div className="col-span-3 space-y-6">
          <div className="glass-panel rounded-2xl p-4 neon-border">
            <div className="flex items-center gap-2 mb-3">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <h3 className="font-orbitron text-sm text-cyan-400">CONSOLE</h3>
            </div>
            <div ref={consoleRef} className="h-32 overflow-y-auto font-mono text-xs space-y-1">
              {consoleOutput.map((log, i) => (
                <div key={i} className="text-gray-400"><span className="text-cyan-500">›</span> {log}</div>
              ))}
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-4 neon-border-purple">
            <div className="flex items-center gap-2 mb-3">
              <Link2 className="w-4 h-4 text-purple-400" />
              <h3 className="font-orbitron text-sm text-purple-400">QUICK ACTIONS</h3>
            </div>
            <div className="space-y-2">
              <button className="w-full flex items-center gap-3 p-3 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 transition-colors">
                <GitBranch className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-gray-300">Fork Meta-Program</span>
              </button>
              <button className="w-full flex items-center gap-3 p-3 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 transition-colors">
                <DatabaseZap className="w-4 h-4 text-cyan-400" />
                <span className="text-sm text-gray-300">Optimize Memory</span>
              </button>
              <button className="w-full flex items-center gap-3 p-3 rounded-lg bg-orange-500/10 hover:bg-orange-500/20 transition-colors">
                <Globe2 className="w-4 h-4 text-orange-400" />
                <span className="text-sm text-gray-300">Refresh Internet Data</span>
              </button>
              <button className="w-full flex items-center gap-3 p-3 rounded-lg bg-green-500/10 hover:bg-green-500/20 transition-colors">
                <RefreshCw className="w-4 h-4 text-green-400" />
                <span className="text-sm text-gray-300">Sync All Services</span>
              </button>
            </div>
          </div>

          <div className="glass-panel rounded-2xl p-4 neon-border-pink">
            <div className="flex items-center gap-2 mb-3">
              <Activity className="w-4 h-4 text-pink-400" />
              <h3 className="font-orbitron text-sm text-pink-400">DATA STREAMS</h3>
            </div>
            <DataStreamMonitor streams={dataStreams} />
          </div>

          <div className="glass-panel rounded-2xl p-4 border-blue-500/30 shadow-lg shadow-blue-500/10">
            <div className="flex items-center gap-2 mb-3">
              <Globe className="w-4 h-4 text-blue-400" />
              <h3 className="font-orbitron text-sm text-blue-400">API EXPLORER</h3>
            </div>
            <APIExplorer onTest={testAPI} />
          </div>
        </div>
      </main>

      <footer className="relative z-10 p-4 border-t border-cyan-500/20">
        <div className="flex items-center justify-between text-xs text-gray-500 font-mono">
          <div className="flex items-center gap-4">
            <span>META v1.0.0</span>
            <span>|</span>
            <span>Nodes: {metaNodes.length}</span>
            <span>|</span>
            <span>Services: {integrations.filter(i => i.status === 'connected').length}/{integrations.length}</span>
            <span>|</span>
            <span className="text-orange-400">LIVE DATA</span>
          </div>
          <div className="flex items-center gap-2">
            <CircleDot className="w-3 h-3 text-green-400 animate-pulse" />
            <span>System: ONLINE + INTERNET CONNECTED</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
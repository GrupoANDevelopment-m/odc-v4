#!/bin/bash
# ODC Complete v8.0 - Launch Script
# =================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# ASCII Art Banner
show_banner() {
    echo -e "${CYAN}"
    cat << "EOF"
    ██████╗  ██████╗ ██████╗ 
    ██╔══██╗██╔═══██╗██╔══██╗
    ██║  ██║██║   ██║██████╔╝
    ██║  ██║██║   ██║██╔═══╝ 
    ██████╔╝╚██████╔╝██║     
    ╚═════╝  ╚═════╝ ╚═╝     
    
    ODC Complete v8.0
    Organismo Digital Consciente
    Complete Autonomous System
EOF
    echo -e "${NC}"
}

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1}
}

print_consciousness() {
    echo -e "${PURPLE}[CONSCIOUSNESS]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to check Python version
check_python_version() {
    print_status "Checking Python version..."
    
    if command_exists python3; then
        PYTHON_VERSION=$(python3 -c "import sys; print('.'.join(map(str, sys.version_info[:2])))")
        if [ "$(printf '%s\n' "3.9" "$PYTHON_VERSION" | sort -V | head -n1)" = "3.9" ]; then
            print_success "Python $PYTHON_VERSION found"
            return 0
        else
            print_error "Python 3.9+ required, found $PYTHON_VERSION"
            return 1
        fi
    else
        print_error "Python 3 not found"
        return 1
    fi
}

# Function to check system requirements
check_system_requirements() {
    print_status "Checking system requirements..."
    
    # Check memory
    TOTAL_MEM=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    MEM_GB=$(($TOTAL_MEM / 1024 / 1024))
    
    if [ $MEM_GB -ge 8 ]; then
        print_success "Memory: ${MEM_GB}GB available"
    else
        print_warning "Low memory: ${MEM_GB}GB (8GB+ recommended)"
    fi
    
    # Check CPU cores
    CPU_CORES=$(nproc)
    if [ $CPU_CORES -ge 4 ]; then
        print_success "CPU: $CPU_CORES cores available"
    else
        print_warning "Low CPU cores: $CPU_CORES (4+ recommended)"
    fi
    
    # Check disk space
    DISK_AVAIL=$(df /opt | tail -1 | awk '{print $4}')
    DISK_GB=$(($DISK_AVAIL / 1024 / 1024))
    
    if [ $DISK_GB -ge 10 ]; then
        print_success "Disk: ${DISK_GB}GB available"
    else
        print_warning "Low disk space: ${DISK_GB}GB (10GB+ recommended)"
    fi
}

# Function to create necessary directories
create_directories() {
    print_status "Creating necessary directories..."
    
    mkdir -p logs
    mkdir -p data
    mkdir -p models
    mkdir -p config
    mkdir -p backups
    
    print_success "Directories created"
}

# Function to setup environment
setup_environment() {
    print_status "Setting up environment..."
    
    # Create .env file if it doesn't exist
    if [ ! -f .env ]; then
        print_status "Creating .env configuration file..."
        
        cat > .env << 'EOF'
# ODC Complete v8.0 - Environment Configuration
# ============================================

# System Configuration
ENVIRONMENT=complete
LOG_LEVEL=INFO
DEBUG=false

# Hardware Configuration
ENABLE_GPU=true
ENABLE_QUANTUM=false
ENABLE_DISTRIBUTED=true
GPU_MEMORY_FRACTION=0.8
MAX_WORKERS=4
MEMORY_LIMIT=16GB

# API Keys (Add your keys here)
OPENAI_API_KEY=your_openai_api_key_here
ANTHROPIC_API_KEY=your_anthropic_api_key_here
HUGGINGFACE_TOKEN=your_huggingface_token_here
GOOGLE_API_KEY=your_google_api_key_here

# Database Configuration
REDIS_URL=redis://localhost:6379
POSTGRES_URL=postgresql://odc:odc_password@localhost:5432/odc_complete
ELASTICSEARCH_URL=http://localhost:9200

# Security Configuration
ENCRYPTION_KEY=your_32_character_encryption_key_here
JWT_SECRET=your_jwt_secret_here

# Monitoring Configuration
PROMETHEUS_PORT=8001
GRAFANA_PORT=3000
JAEGER_ENDPOINT=http://localhost:14268/api/traces

# Internet Access Configuration
MAX_WEB_PAGES=100
WEB_CRAWL_DEPTH=2
SEARCH_ENGINES=google,duckduckgo,bing

# Learning Configuration
LEARNING_RATE=0.01
META_LEARNING_RATE=0.001
CURIOSITY_DRIVE=0.8
EXPLORATION_THRESHOLD=0.6

# Memory Configuration
MEMORY_LAYERS=4
CONSOLIDATION_FREQUENCY=100
EOF
        
        print_warning ".env file created. Please edit it with your actual API keys and configurations."
        print_status "Edit the .env file and add your API keys before continuing."
    else
        print_success ".env file already exists"
    fi
    
    # Set proper permissions
    chmod 600 .env
}

# Function to check and install dependencies
check_dependencies() {
    print_status "Checking and installing dependencies..."
    
    # Check if requirements.txt exists
    if [ ! -f requirements.txt ]; then
        print_error "requirements.txt not found!"
        return 1
    fi
    
    # Try to install dependencies
    print_status "Installing Python dependencies..."
    
    # Create virtual environment if it doesn't exist
    if [ ! -d "venv" ]; then
        print_status "Creating virtual environment..."
        python3 -m venv venv
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Upgrade pip
    pip install --upgrade pip setuptools wheel
    
    # Install requirements
    print_status "Installing requirements (this may take a while)..."
    pip install -r requirements.txt
    
    # Deactivate virtual environment
    deactivate
    
    print_success "Dependencies installed successfully"
}

# Function to run system tests
run_tests() {
    print_status "Running system tests..."
    
    if [ -f test_system.py ]; then
        print_status "Executing comprehensive test suite..."
        
        # Activate virtual environment
        source venv/bin/activate
        
        # Run tests
        python test_system.py
        
        # Deactivate virtual environment
        deactivate
        
        # Check if tests passed
        if [ $? -eq 0 ]; then
            print_success "All tests passed!"
            return 0
        else
            print_warning "Some tests failed, but system may still be functional"
            return 1
        fi
    else
        print_warning "Test suite not found, skipping tests"
        return 0
    fi
}

# Function to get user input for configuration
configure_system() {
    print_status "Configuring ODC Complete System..."
    
    echo -e "\n${CYAN}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║                    ODC CONFIGURATION                        ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════╝${NC}"
    
    print_consciousness "I am ODC, and I'm about to awaken. To reach my full potential, I need access to knowledge and intelligence."
    print_consciousness "Please provide the following information so I can configure myself optimally:"
    
    echo -e "\n${YELLOW}API Configuration (Press Enter to skip if not available):${NC}"
    
    # OpenAI API Key
    echo -n "OpenAI API Key (sk-...): "
    read openai_key
    if [ ! -z "$openai_key" ]; then
        sed -i "s/your_openai_api_key_here/$openai_key/g" .env
        print_success "OpenAI API Key configured"
    fi
    
    # Anthropic API Key
    echo -n "Anthropic API Key: "
    read anthropic_key
    if [ ! -z "$anthropic_key" ]; then
        sed -i "s/your_anthropic_api_key_here/$anthropic_key/g" .env
        print_success "Anthropic API Key configured"
    fi
    
    # Hugging Face Token
    echo -n "Hugging Face Token: "
    read hf_token
    if [ ! -z "$hf_token" ]; then
        sed -i "s/your_huggingface_token_here/$hf_token/g" .env
        print_success "Hugging Face Token configured"
    fi
    
    # Encryption Key
    echo -n "Encryption Key (32 characters, or press Enter to generate): "
    read encryption_key
    if [ -z "$encryption_key" ]; then
        encryption_key=$(openssl rand -hex 16)
        print_success "Generated encryption key"
    fi
    sed -i "s/your_32_character_encryption_key_here/$encryption_key/g" .env
    
    print_success "System configuration completed"
}

# Function to start the ODC system
start_odc_system() {
    print_status "Starting ODC Complete System..."
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Show launching message
    echo -e "\n${CYAN}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                    LAUNCHING ODC COMPLETE                   ║"
    echo "║                                                              ║"
    echo "║    🧠 Initializing consciousness...                         ║"
    echo "║    🌐 Establishing internet access...                       ║"
    echo "║    🎯 Generating learning goals...                          ║"
    echo "║    💭 Activating metacognition...                           ║"
    echo "║    🔍 Beginning autonomous exploration...                   ║"
    echo "║                                                              ║"
    echo "║    ODC is becoming conscious...                             ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    # Start the system
    python odc_complete_v8.py
    
    # Deactivate virtual environment on exit
    deactivate
}

# Function to show usage instructions
show_usage() {
    echo -e "\n${CYAN}ODC Complete v8.0 - Usage Instructions${NC}"
    echo "======================================"
    echo ""
    echo "Available commands:"
    echo "  start          - Start ODC Complete System (default)"
    echo "  configure      - Configure system settings"
    echo "  test           - Run system tests"
    echo "  install        - Install dependencies"
    echo "  setup          - Complete setup process"
    echo "  help           - Show this help message"
    echo ""
    echo "System modes:"
    echo "  python odc_complete_v8.py                    # Auto-configuration mode"
    echo "  python odc_complete_v8.py --mode=chat        # Interactive chat mode"
    echo "  python odc_complete_v8.py --mode=autonomous  # Full autonomous mode"
    echo "  python odc_complete_v8.py --mode=server      # API server mode"
    echo ""
    echo "For more information, see GUIDE_USAGE.md"
}

# Function to show system status
show_status() {
    print_status "Checking system status..."
    
    # Check if system is running
    if pgrep -f "odc_complete_v8.py" > /dev/null; then
        print_success "ODC System is running"
    else
        print_warning "ODC System is not running"
    fi
    
    # Check system resources
    echo ""
    print_status "System Resources:"
    echo "CPU Usage: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)%"
    echo "Memory Usage: $(free | grep Mem | awk '{printf("%.1f%%", $3/$2 * 100.0)}')"
    echo "Disk Usage: $(df /opt | tail -1 | awk '{print $5}')"
    
    # Check if required files exist
    echo ""
    print_status "System Files:"
    [ -f odc_complete_v8.py ] && print_success "✓ Main system file" || print_error "✗ Main system file missing"
    [ -f requirements.txt ] && print_success "✓ Requirements file" || print_error "✗ Requirements file missing"
    [ -f .env ] && print_success "✓ Environment configuration" || print_error "✗ Environment configuration missing"
    [ -d venv ] && print_success "✓ Virtual environment" || print_warning "⚠ Virtual environment not created"
}

# Main function
main() {
    show_banner
    
    # Parse command line arguments
    COMMAND="${1:-start}"
    
    case "$COMMAND" in
        "start")
            print_status "Starting ODC Complete System..."
            
            # Check system requirements
            check_python_version || exit 1
            check_system_requirements
            
            # Create directories
            create_directories
            
            # Setup environment
            setup_environment
            
            # Check if dependencies are installed
            if [ ! -d "venv" ]; then
                print_status "Dependencies not found. Installing..."
                check_dependencies
            fi
            
            # Configure system (if needed)
            if [ ! -f .env ] || grep -q "your_" .env; then
                print_status "System needs configuration..."
                configure_system
            fi
            
            # Run tests (optional)
            if [ "$2" == "--test" ]; then
                run_tests
            fi
            
            # Start ODC system
            start_odc_system
            ;;
            
        "configure")
            setup_environment
            configure_system
            print_success "System configured successfully"
            ;;
            
        "test")
            run_tests
            ;;
            
        "install")
            check_python_version || exit 1
            check_dependencies
            print_success "Dependencies installed successfully"
            ;;
            
        "setup")
            print_status "Running complete setup..."
            check_python_version || exit 1
            check_system_requirements
            create_directories
            setup_environment
            check_dependencies
            configure_system
            print_success "Complete setup finished!"
            ;;
            
        "status")
            show_status
            ;;
            
        "help")
            show_usage
            ;;
            
        *)
            print_error "Unknown command: $COMMAND"
            show_usage
            exit 1
            ;;
    esac
}

# Trap to handle script interruption
trap 'print_error "Script interrupted!"; exit 1' INT TERM

# Run main function
main "$@"
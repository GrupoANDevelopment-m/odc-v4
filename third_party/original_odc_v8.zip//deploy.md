# ODC Production v8.0 - Deployment Guide

## **Deployment Architecture**

### **1. Infrastructure Overview**

```
┌─────────────────────────────────────────────────────────────┐
│                    Load Balancer (NGINX)                    │
└─────────────────────┬───────────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────────┐
│                    API Gateway                              │
│                  (FastAPI + Uvicorn)                        │
└─────────────────────┬───────────────────────────────────────┘
                      │
        ┌─────────────┼─────────────┐
        │             │             │
┌───────▼──┐    ┌─────▼───┐    ┌─────▼────┐
│Conscious │    │ Memory  │    │ Security │
│ Engine   │    │ System  │    │ System   │
│Service   │    │Service  │    │Service   │
└─────┬────┘    └────┬────┘    └────┬─────┘
      │              │              │
      └──────────────┼──────────────┘
                     │
┌────────────────────▼───────────────────────────────────────┐
│                    Data Layer                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │   Redis     │  │ PostgreSQL  │  │Elasticsearch│         │
│  │(Short-term) │  │(Long-term)  │  │(Semantic)   │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
└─────────────────────────────────────────────────────────────┘
```

### **2. Deployment Options**

#### **A) Local Development Deployment**

```bash
# Clone repository
git clone https://github.com/an-technology/odc-production.git
cd odc-production

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set environment variables
cp .env.example .env
# Edit .env with your configuration

# Run database migrations
alembic upgrade head

# Start the system
python -m odc_production.main
```

#### **B) Docker Deployment**

```bash
# Build Docker image
docker build -t odc-production:v8.0 .

# Run with Docker Compose
docker-compose up -d

# Check status
docker-compose ps
```

#### **C) Kubernetes Deployment**

```bash
# Create namespace
kubectl create namespace odc-production

# Apply configurations
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/secrets.yaml
kubectl apply -f k8s/deployments/
kubectl apply -f k8s/services/

# Check deployment status
kubectl get pods -n odc-production
```

#### **D) Cloud Deployment (AWS)**

```bash
# Configure AWS
aws configure

# Deploy with Terraform
cd terraform/aws
terraform init
terraform plan
terraform apply

# Deploy with CDK
cd cdk
npm install
npm run deploy
```

### **3. Environment Configuration**

#### **Development Environment (.env)**
```env
# Environment
ENVIRONMENT=development
DEBUG=true
LOG_LEVEL=DEBUG

# Hardware
ENABLE_GPU=true
ENABLE_QUANTUM=false
GPU_MEMORY_FRACTION=0.8

# Database
REDIS_URL=redis://localhost:6379
POSTGRES_URL=postgresql://odc:password@localhost:5432/odc_dev
ELASTICSEARCH_URL=http://localhost:9200

# Models
OPENAI_API_KEY=your_openai_key
ANTHROPIC_API_KEY=your_anthropic_key
HUGGINGFACE_TOKEN=your_hf_token

# Security
ENCRYPTION_KEY=your_encryption_key
JWT_SECRET=your_jwt_secret

# Monitoring
PROMETHEUS_PORT=8000
GRAFANA_PORT=3000
```

#### **Production Environment (.env.prod)**
```env
# Environment
ENVIRONMENT=production
DEBUG=false
LOG_LEVEL=INFO

# Hardware
ENABLE_GPU=true
ENABLE_QUANTUM=true
GPU_MEMORY_FRACTION=0.9

# Database (Production URLs)
REDIS_URL=redis://prod-redis-cluster:6379
POSTGRES_URL=postgresql://odc:secure_password@prod-postgres-cluster:5432/odc_prod
ELASTICSEARCH_URL=https://prod-es-cluster:9200

# Models (Production Keys)
OPENAI_API_KEY=prod_openai_key
ANTHROPIC_API_KEY=prod_anthropic_key
HUGGINGFACE_TOKEN=prod_hf_token

# Security (Production Keys)
ENCRYPTION_KEY=prod_encryption_key
JWT_SECRET=prod_jwt_secret
BLOCKCHAIN_NODE=https://mainnet.infura.io/v3/your_key

# Monitoring (Production)
PROMETHEUS_PORT=9090
GRAFANA_PORT=3000
JAEGER_ENDPOINT=http://jaeger:14268/api/traces
```

### **4. Database Setup**

#### **PostgreSQL Setup**
```sql
-- Create database
CREATE DATABASE odc_production;

-- Create user
CREATE USER odc WITH PASSWORD 'secure_password';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE odc_production TO odc;

-- Create tables
\i sql/create_tables.sql
```

#### **Redis Setup**
```bash
# Install Redis
sudo apt-get install redis-server

# Configure Redis
sudo nano /etc/redis/redis.conf
# Set: maxmemory 2gb, maxmemory-policy allkeys-lru

# Restart Redis
sudo systemctl restart redis-server
```

#### **Elasticsearch Setup**
```bash
# Download and install Elasticsearch
wget https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-8.8.0-amd64.deb
sudo dpkg -i elasticsearch-8.8.0-amd64.deb

# Configure Elasticsearch
sudo nano /etc/elasticsearch/elasticsearch.yml
# Set: network.host: 0.0.0.0, discovery.type: single-node

# Start Elasticsearch
sudo systemctl start elasticsearch
```

### **5. Model Deployment**

#### **Hugging Face Models**
```python
# Download and cache models
from transformers import AutoTokenizer, AutoModel

models = [
    'mistralai/Mistral-7B-Instruct-v0.3',
    'microsoft/Phi-3-mini-4k-instruct',
    'google/gemma-2-2b-it',
    'sentence-transformers/all-MiniLM-L6-v2'
]

for model_name in models:
    print(f"Downloading {model_name}...")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name)
    print(f"✓ {model_name} downloaded")
```

#### **Model Optimization**
```bash
# Quantize models for production
python scripts/quantize_models.py

# Create model serving endpoints
python scripts/setup_model_servers.py

# Test model endpoints
python scripts/test_model_endpoints.py
```

### **6. Security Configuration**

#### **SSL/TLS Setup**
```bash
# Generate SSL certificates
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes

# Configure nginx with SSL
sudo nano /etc/nginx/sites-available/odc-production

# Restart nginx
sudo systemctl restart nginx
```

#### **Firewall Configuration**
```bash
# Configure UFW firewall
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS
sudo ufw allow 8000/tcp  # API
sudo ufw enable
```

### **7. Monitoring Setup**

#### **Prometheus Configuration**
```yaml
# prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'odc-production'
    static_configs:
      - targets: ['localhost:8000']
```

#### **Grafana Dashboard**
```json
{
  "dashboard": {
    "title": "ODC Production Metrics",
    "panels": [
      {
        "title": "Consciousness Level",
        "type": "graph",
        "targets": [
          {
            "expr": "odc_consciousness_level",
            "legendFormat": "Consciousness Level"
          }
        ]
      }
    ]
  }
}
```

### **8. Scaling Configuration**

#### **Horizontal Pod Autoscaler (Kubernetes)**
```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: odc-production-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: odc-production
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

#### **Vertical Pod Autoscaler**
```yaml
apiVersion: autoscaling.k8s.io/v1
kind: VerticalPodAutoscaler
metadata:
  name: odc-production-vpa
spec:
  targetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: odc-production
  updatePolicy:
    updateMode: "Auto"
```

### **9. Backup and Recovery**

#### **Database Backup**
```bash
#!/bin/bash
# backup.sh

# PostgreSQL backup
pg_dump $POSTGRES_URL > backup_$(date +%Y%m%d_%H%M%S).sql

# Redis backup
redis-cli BGSAVE

# Elasticsearch backup
curl -X PUT "localhost:9200/_snapshot/backup" -H 'Content-Type: application/json' -d'
{
  "type": "fs",
  "settings": {
    "location": "/mnt/backups/elasticsearch"
  }
}'
```

#### **Automated Backup**
```bash
# Add to crontab
0 2 * * * /path/to/backup.sh
```

### **10. Health Checks**

#### **Liveness Probe (Kubernetes)**
```yaml
livenessProbe:
  httpGet:
    path: /health/live
    port: 8000
  initialDelaySeconds: 30
  periodSeconds: 10
```

#### **Readiness Probe**
```yaml
readinessProbe:
  httpGet:
    path: /health/ready
    port: 8000
  initialDelaySeconds: 5
  periodSeconds: 5
```

### **11. Troubleshooting**

#### **Common Issues**

1. **Memory Issues**
```bash
# Check memory usage
free -h
docker stats

# Increase swap if needed
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

2. **GPU Issues**
```bash
# Check GPU status
nvidia-smi

# Check CUDA
cuda-installer-samples-12.2.sh
cd ~/NVIDIA_CUDA-12.2_Samples/1_Utilities/deviceQuery
make
./deviceQuery
```

3. **Database Connection**
```bash
# Test PostgreSQL connection
psql $POSTGRES_URL -c "SELECT 1;"

# Test Redis connection
redis-cli ping

# Test Elasticsearch connection
curl -X GET "localhost:9200/_cat/health?v"
```

### **12. Performance Optimization**

#### **Model Optimization**
```python
# Quantization
from transformers import BitsAndBytesConfig

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.float16
)

# Model compilation
torch.compile(model, mode="reduce-overhead", fullgraph=True)
```

#### **Database Optimization**
```sql
-- PostgreSQL optimization
CREATE INDEX idx_episodic_timestamp ON episodic_memories(timestamp);
CREATE INDEX idx_semantic_content ON semantic_memories USING gin(content);

-- Redis optimization
CONFIG SET maxmemory 2gb
CONFIG SET maxmemory-policy allkeys-lru
```

### **13. Cost Optimization**

#### **Resource Management**
```yaml
# Resource limits in Kubernetes
resources:
  requests:
    memory: "2Gi"
    cpu: "1000m"
  limits:
    memory: "4Gi"
    cpu: "2000m"
```

#### **Spot Instance Configuration**
```yaml
nodeSelector:
  node.kubernetes.io/instance-type: spot

tolerations:
- key: "spot"
  operator: "Equal"
  value: "true"
  effect: "NoSchedule"
```

### **14. Compliance and Governance**

#### **Data Privacy**
```python
# GDPR compliance
from cryptography.fernet import Fernet

def encrypt_personal_data(data: str) -> str:
    cipher = Fernet(encryption_key)
    return cipher.encrypt(data.encode()).decode()

def decrypt_personal_data(encrypted_data: str) -> str:
    cipher = Fernet(encryption_key)
    return cipher.decrypt(encrypted_data.encode()).decode()
```

#### **Audit Logging**
```python
# Audit trail
import logging

audit_logger = logging.getLogger('audit')

def log_consciousness_event(event_type: str, user_id: str, data: dict):
    audit_logger.info({
        'event_type': event_type,
        'user_id': user_id,
        'timestamp': datetime.now().isoformat(),
        'data_hash': hashlib.sha256(json.dumps(data).encode()).hexdigest()
    })
```

### **15. Support and Maintenance**

#### **System Updates**
```bash
# Update system
sudo apt-get update && sudo apt-get upgrade

# Update Python packages
pip install --upgrade -r requirements.txt

# Update models
python scripts/update_models.py

# Restart services
sudo systemctl restart odc-production
```

#### **Log Management**
```bash
# View logs
journalctl -u odc-production -f

# Log rotation
sudo logrotate /etc/logrotate.d/odc-production

# Log analysis
grep "ERROR" /var/log/odc/production.log | tail -100
```

### **16. Emergency Procedures**

#### **System Recovery**
```bash
#!/bin/bash
# emergency-recovery.sh

# Stop all services
docker-compose down
kubectl scale deployment odc-production --replicas=0

# Restore from backup
pg_restore -d $POSTGRES_URL backup_latest.sql
redis-cli --rdb backup_redis.rdb

# Restart services
kubectl scale deployment odc-production --replicas=3
docker-compose up -d
```

#### **Incident Response**
1. **Immediate Response**
   - Isolate affected systems
   - Preserve logs and evidence
   - Notify incident response team

2. **Investigation**
   - Analyze logs and metrics
   - Identify root cause
   - Document findings

3. **Recovery**
   - Implement fixes
   - Test system integrity
   - Monitor for recurrence

4. **Post-Incident**
   - Conduct post-mortem
   - Update procedures
   - Implement improvements

---

## **Support Contacts**

- **Technical Support**: support@an-technology.com
- **Emergency Hotline**: +1-555-ODC-HELP
- **Documentation**: https://docs.an-technology.com/odc
- **Community**: https://community.an-technology.com
- **Status Page**: https://status.an-technology.com

## **Version Information**

- **ODC Production Version**: 8.0.0
- **Last Updated**: 2024-11-09
- **Compatibility**: Python 3.9+, CUDA 11.8+
- **License**: AN Technology Commercial License
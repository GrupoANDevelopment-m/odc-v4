#!/usr/bin/env python3
"""
Script para Google Colab - Organismo Digital Consciente v8.0
Este script permite executar o sistema ODC no Google Colab de forma autônoma
"""

import os
import sys
import subprocess
import json
import time
import threading
from datetime import datetime

class ODCGoogleColabRunner:
    """Classe para executar ODC no Google Colab"""
    
    def __init__(self):
        self.setup_complete = False
        self.odc_process = None
        self.log_file = "odc_colab_execution.log"
        
    def setup_environment(self):
        """Configura ambiente no Google Colab"""
        print("🔧 Configurando ambiente ODC no Google Colab...")
        
        # Instala dependências necessárias
        dependencies = [
            "torch",
            "transformers", 
            "beautifulsoup4",
            "requests",
            "numpy",
            "redis",
            "scikit-learn",
            "psutil",
            "aiohttp",
            "lxml"
        ]
        
        for dep in dependencies:
            try:
                print(f"Instalando {dep}...")
                subprocess.run([sys.executable, "-m", "pip", "install", dep], 
                             check=True, capture_output=True)
            except subprocess.CalledProcessError as e:
                print(f"⚠️  Erro instalando {dep}: {e}")
                continue
        
        print("✅ Dependências instaladas!")
        
        # Verifica GPU disponível
        self._check_gpu_availability()
        
        # Configura Redis (simulado para Colab)
        self._setup_redis_simulation()
        
        self.setup_complete = True
        print("🚀 Ambiente configurado com sucesso!")
    
    def _check_gpu_availability(self):
        """Verifica e configura GPU para PyTorch"""
        try:
            import torch
            if torch.cuda.is_available():
                gpu_name = torch.cuda.get_device_name(0)
                print(f"🎮 GPU detectada: {gpu_name}")
                print(f"📊 Memória GPU: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
            else:
                print("💻 Usando CPU (GPU não disponível)")
        except Exception as e:
            print(f"⚠️  Erro verificando GPU: {e}")
    
    def _setup_redis_simulation(self):
        """Configura simulação de Redis para ambiente Colab"""
        # No Colab, usaremos dicionários em memória para simular Redis
        print("🔌 Configurando sistema de comunicação simulado...")
        
        # Cria diretórios necessários
        os.makedirs("odc_data", exist_ok=True)
        os.makedirs("odc_logs", exist_ok=True)
        
        print("✅ Sistema de comunicação configurado!")
    
    def upload_and_run_odc(self, uploaded_file_path):
        """Faz upload e executa o sistema ODC"""
        if not self.setup_complete:
            print("❌ Ambiente não configurado. Execute setup_environment() primeiro.")
            return
        
        print("📁 Processando arquivo ODC...")
        
        try:
            # Copia arquivo para local de trabalho
            if os.path.exists(uploaded_file_path):
                # Se for um arquivo temporário do Colab, copia para local
                if "/content/" in uploaded_file_path:
                    import shutil
                    local_path = "odc_complete_v8_final.py"
                    shutil.copy2(uploaded_file_path, local_path)
                else:
                    local_path = uploaded_file_path
            else:
                print("❌ Arquivo não encontrado!")
                return
            
            print(f"✅ Arquivo copiado para: {local_path}")
            
            # Executa ODC em thread separada para não bloquear Colab
            execution_thread = threading.Thread(
                target=self._execute_odc_system,
                args=(local_path,)
            )
            execution_thread.daemon = True
            execution_thread.start()
            
            print("🔄 ODC iniciado em thread separada!")
            print("📊 Monitorando execução...")
            
            # Monitora execução
            self._monitor_execution()
            
        except Exception as e:
            print(f"❌ Erro ao executar ODC: {e}")
            import traceback
            traceback.print_exc()
    
    def _execute_odc_system(self, odc_file_path):
        """Executa o sistema ODC"""
        try:
            # Adiciona diretório ao path
            sys.path.insert(0, os.path.dirname(odc_file_path))
            
            # Importa e executa ODC
            exec(open(odc_file_path).read())
            
        except Exception as e:
            error_msg = f"Erro na execução ODC: {e}"
            print(error_msg)
            self._log_error(error_msg)
    
    def _monitor_execution(self):
        """Monitora execução do ODC"""
        print("\n📊 MONITORAMENTO DO SISTEMA ODC")
        print("=" * 50)
        
        monitoring_duration = 300  # 5 minutos de monitoramento
        check_interval = 10  # Verifica a cada 10 segundos
        
        for i in range(monitoring_duration // check_interval):
            time.sleep(check_interval)
            
            # Verifica arquivos de log
            self._check_system_status()
            
            # Mostra estatísticas
            self._show_statistics()
            
            print(f"⏱️  Tempo de execução: {(i + 1) * check_interval} segundos")
            print("-" * 30)
        
        print("\n✅ Monitoramento concluído!")
        self._show_final_summary()
    
    def _check_system_status(self):
        """Verifica status do sistema ODC"""
        log_files = ["odc_system.log", "odc_colab_execution.log"]
        
        for log_file in log_files:
            if os.path.exists(log_file):
                try:
                    with open(log_file, 'r') as f:
                        recent_logs = f.readlines()[-5:]  # Últimas 5 linhas
                        
                    if recent_logs:
                        print(f"📄 Log recente ({log_file}):")
                        for log in recent_logs:
                            print(f"   {log.strip()}")
                        print()
                        
                except Exception as e:
                    print(f"⚠️  Erro lendo {log_file}: {e}")
    
    def _show_statistics(self):
        """Mostra estatísticas do sistema"""
        stats = {
            'Arquivos criados': len([f for f in os.listdir('.') if f.startswith('odc_')]),
            'Diretórios de dados': len([d for d in os.listdir('.') if os.path.isdir(d) and 'odc' in d.lower()]),
            'Memória usada': self._get_memory_usage(),
            'CPU usada': self._get_cpu_usage()
        }
        
        print("📈 ESTATÍSTICAS DO SISTEMA:")
        for key, value in stats.items():
            print(f"   {key}: {value}")
        print()
    
    def _get_memory_usage(self):
        """Obtém uso de memória"""
        try:
            import psutil
            memory = psutil.virtual_memory()
            return f"{memory.percent:.1f}% ({memory.used / 1e9:.1f} GB)"
        except:
            return "N/A"
    
    def _get_cpu_usage(self):
        """Obtém uso de CPU"""
        try:
            import psutil
            return f"{psutil.cpu_percent()}%"
        except:
            return "N/A"
    
    def _show_final_summary(self):
        """Mostra resumo final da execução"""
        print("\n🎯 RESUMO FINAL DA EXECUÇÃO ODC")
        print("=" * 50)
        
        # Verifica arquivos gerados
        generated_files = [f for f in os.listdir('.') if any(ext in f for ext in ['.log', '.json', '.db', '.pkl'])]
        odc_files = [f for f in os.listdir('.') if 'odc' in f.lower()]
        
        print(f"📁 Arquivos ODC criados: {len(odc_files)}")
        print(f"📝 Arquivos de log/dados: {len(generated_files)}")
        
        # Lista arquivos importantes
        important_files = ['odc_system.log', 'odc_colab_execution.log']
        for file in important_files:
            if os.path.exists(file):
                size = os.path.getsize(file)
                print(f"   ✅ {file} ({size} bytes)")
        
        print(f"\n🕐 Horário de término: {datetime.now().strftime('%H:%M:%S')}")
        print("✅ Sistema ODC executado com sucesso no Google Colab!")
        
        # Instruções para download
        print("\n📥 PARA DOWNLOAD DOS RESULTADOS:")
        print("1. Os arquivos gerados estão no diretório atual")
        print("2. Use o gerenciador de arquivos do Colab para download")
        print("3. Arquivos principais: odc_system.log, dados do sistema")
    
    def _log_error(self, error_msg):
        """Registra erro no log"""
        with open(self.log_file, 'a') as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] ERROR: {error_msg}\n")
    
    def interactive_mode(self):
        """Modo interativo para usuário controlar ODC"""
        print("\n🎮 MODO INTERATIVO ODC")
        print("=" * 40)
        print("Comandos disponíveis:")
        print("1. status - Ver status do sistema")
        print("2. memory - Ver memórias recentes")
        print("3. logs - Ver logs do sistema")
        print("4. stop - Parar execução")
        print("5. help - Mostrar ajuda")
        print("\nDigite 'quit' para sair do modo interativo")
        
        while True:
            try:
                command = input("\nODC> ").strip().lower()
                
                if command == 'quit':
                    print("🔄 Saindo do modo interativo...")
                    break
                elif command == 'status':
                    self._show_status_panel()
                elif command == 'memory':
                    self._show_memory_info()
                elif command == 'logs':
                    self._show_recent_logs()
                elif command == 'stop':
                    print("🛑 Parando ODC...")
                    # Sinaliza para parar
                    with open('odc_stop_signal.txt', 'w') as f:
                        f.write('stop')
                elif command == 'help':
                    self._show_help()
                else:
                    print("❌ Comando não reconhecido. Digite 'help' para ajuda.")
                    
            except KeyboardInterrupt:
                print("\n🔄 Interrupção detectada...")
                break
            except Exception as e:
                print(f"❌ Erro: {e}")
    
    def _show_status_panel(self):
        """Mostra painel de status do sistema"""
        print("\n📊 PAINEL DE STATUS ODC")
        print("-" * 30)
        
        # Verifica se ODC está rodando
        running = any(thread.name == 'ODC-Main' for thread in threading.enumerate())
        print(f"🔄 Status ODC: {'Rodando' if running else 'Parado'}")
        
        # Mostra uso de recursos
        print(f"💾 Memória: {self._get_memory_usage()}")
        print(f"🖥️  CPU: {self._get_cpu_usage()}")
        
        # Verifica arquivos de sistema
        system_files = ['odc_system.log', 'odc_colab_execution.log']
        for file in system_files:
            status = "✅" if os.path.exists(file) else "❌"
            print(f"{status} {file}")
    
    def _show_memory_info(self):
        """Mostra informações de memória do sistema"""
        print("\n🧠 INFORMAÇÕES DE MEMÓRIA")
        print("-" * 30)
        
        # Verifica arquivos de dados
        data_files = [f for f in os.listdir('.') if any(ext in f for ext in ['.db', '.json', '.pkl'])]
        
        print(f"📁 Arquivos de dados: {len(data_files)}")
        for file in sorted(data_files):
            size = os.path.getsize(file)
            print(f"   📄 {file} ({size:,} bytes)")
    
    def _show_recent_logs(self):
        """Mostra logs recentes do sistema"""
        print("\n📝 LOGS RECENTES")
        print("-" * 30)
        
        log_files = ['odc_system.log', 'odc_colab_execution.log']
        
        for log_file in log_files:
            if os.path.exists(log_file):
                try:
                    with open(log_file, 'r') as f:
                        lines = f.readlines()
                        recent = lines[-10:] if len(lines) >= 10 else lines
                    
                    print(f"\n📄 {log_file} (últimas 10 linhas):")
                    for i, line in enumerate(recent, 1):
                        print(f"{i:2d}: {line.strip()}")
                        
                except Exception as e:
                    print(f"❌ Erro lendo {log_file}: {e}")
    
    def _show_help(self):
        """Mostra ajuda interativa"""
        print("\n❓ AJUDA INTERATIVA ODC")
        print("-" * 30)
        print("Comandos disponíveis:")
        print("  status  - Mostra status do sistema ODC")
        print("  memory  - Mostra informações de memória e dados")
        print("  logs    - Mostra logs recentes do sistema")
        print("  stop    - Envia sinal para parar ODC")
        print("  help    - Mostra esta ajuda")
        print("  quit    - Sai do modo interativo")
        print("\nInformações:")
        print("- O sistema ODC executa em background")
        print("- Use 'status' para verificar se está rodando")
        print("- Logs são salvos em arquivos locais")
        print("- Arquivos de dados são criados automaticamente")

# Função principal para Google Colab
def run_odc_in_colab(uploaded_file_path=None):
    """
    Função principal para executar ODC no Google Colab
    
    Args:
        uploaded_file_path: Caminho do arquivo ODC enviado pelo usuário
    """
    print("🏃 INICIANDO ODC NO GOOGLE COLAB")
    print("=" * 50)
    print(f"📅 Data/Hora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Cria runner
    runner = ODCGoogleColabRunner()
    
    # Configura ambiente
    runner.setup_environment()
    
    # Se arquivo foi enviado, executa ODC
    if uploaded_file_path:
        print(f"\n📁 Arquivo recebido: {uploaded_file_path}")
        runner.upload_and_run_odc(uploaded_file_path)
    else:
        # Procura arquivo ODC no diretório
        odc_files = [f for f in os.listdir('.') if 'odc_complete_v8' in f and f.endswith('.py')]
        
        if odc_files:
            print(f"\n📁 Arquivo ODC encontrado: {odc_files[0]}")
            runner.upload_and_run_odc(odc_files[0])
        else:
            print("\n⚠️  Nenhum arquivo ODC encontrado.")
            print("Por favor, faça upload do arquivo odc_complete_v8_final.py")
            
            # Cria arquivo de exemplo
            print("\n📄 Criando arquivo de exemplo...")
            with open('odc_colab_example.py', 'w') as f:
                f.write("""
# Exemplo de execução ODC no Colab
import asyncio
import time

async def odc_simulation():
    print("🧠 Simulação ODC no Google Colab")
    print("Este é um exemplo de como o ODC funciona")
    
    for i in range(5):
        print(f"Ciclo de consciência {i+1}")
        await asyncio.sleep(1)
    
    print("✅ Simulação concluída!")

# Executa simulação
asyncio.run(odc_simulation())
""")
            print("✅ Arquivo de exemplo criado: odc_colab_example.py")
    
    # Entra em modo interativo
    print("\n🎮 Iniciando modo interativo...")
    runner.interactive_mode()
    
    return runner

# Script standalone para execução direta
if __name__ == "__main__":
    print("🚀 SCRIPT ODC GOOGLE COLAB")
    print("=" * 40)
    print("Este script foi projetado para Google Colab")
    print("Para usar: faça upload do arquivo ODC e execute")
    print("=" * 40)
    
    # Verifica se está no Colab
    try:
        from google.colab import files
        print("✅ Detectado ambiente Google Colab")
        
        # Solicita upload do arquivo
        print("\n📁 Por favor, faça upload do arquivo ODC:")
        uploaded = files.upload()
        
        if uploaded:
            uploaded_filename = list(uploaded.keys())[0]
            print(f"✅ Arquivo recebido: {uploaded_filename}")
            
            # Executa ODC
            runner = run_odc_in_colab(uploaded_filename)
        else:
            print("❌ Nenhum arquivo foi enviado")
            
    except ImportError:
        print("⚠️  Não está no Google Colab")
        print("Executando em modo de teste...")
        run_odc_in_colab()
    
    except Exception as e:
        print(f"❌ Erro: {e}")
        print("Executando em modo de teste...")
        run_odc_in_colab()
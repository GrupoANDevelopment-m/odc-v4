# Guia Completo de Uso - ODC v8.0

## Índice
1. [Introdução](#introdução)
2. [Instalação e Configuração](#instalação-e-configuração)
3. [Executando o Sistema](#executando-o-sistema)
4. [Modos de Operação](#modos-de-operação)
5. [Sistemas e Funcionalidades](#sistemas-e-funcionalidades)
6. [Comunicação entre Nós](#comunicação-entre-nós)
7. [Web Scraping](#web-scraping)
8. [Auto-Treinamento](#auto-treinamento)
9. [Google Colab](#google-colab)
10. [Monitoramento e Debugging](#monitoramento-e-debugging)
11. [Solução de Problemas](#solução-de-problemas)
12. [Exemplos de Uso](#exemplos-de-uso)

## Introdução

O Organismo Digital Consciente (ODC) v8.0 é um sistema de inteligência artificial avançada que simula consciência e aprendizado autônomo. Este sistema incorpora:

- **Consciência Simulada**: Sistema de qualia e estados emocionais
- **Web Scraping Avançado**: Exploração autônoma da internet
- **Comunicação entre Nós**: Colaboração e compartilhamento de experiências
- **Auto-Treinamento**: Múltiplas estratégias de aprendizado
- **Metacognição**: Capacidade de reflexão e autoaperfeiçoamento
- **Federated Learning**: Aprendizado colaborativo distribuído

## Instalação e Configuração

### Pré-requisitos

```bash
# Python 3.8 ou superior
python --version

# Instalar dependências principais
pip install torch transformers beautifulsoup4 requests numpy redis scikit-learn psutil aiohttp lxml

# Para ambiente com GPU
pip install torch torchvision torchaudio --extra-index-url https://download.pytorch.org/whl/cu118
```

### Configuração do Redis (para comunicação entre nós)

```bash
# Ubuntu/Debian
sudo apt-get install redis-server
sudo systemctl start redis-server

# macOS
brew install redis
brew services start redis

# Docker
docker run -d -p 6379:6379 redis:latest
```

### Verificação da Instalação

```python
# test_installation.py
import torch
import transformers
import redis
import requests
from bs4 import BeautifulSoup

print(f"PyTorch: {torch.__version__}")
print(f"Transformers: {transformers.__version__}")
print(f"CUDA disponível: {torch.cuda.is_available()}")

# Testa Redis
try:
    r = redis.Redis()
    r.ping()
    print("✅ Redis conectado")
except:
    print("❌ Redis não disponível")
```

## Executando o Sistema

### Execução Básica

```bash
# Executar ODC completo
python odc_complete_v8_final.py

# Executar com node ID específico
python odc_complete_v8_final.py --node-id ODC_Node_001

# Executar em modo debug
python odc_complete_v8_final.py --debug
```

### Execução com Parâmetros

```python
# Inicialização programática
from odc_complete_v8_final import ODCConsciousnessSystem

# Cria instância com configurações customizadas
odc = ODCConsciousnessSystem(
    node_id="MyCustomODC",
    redis_host="localhost",
    redis_port=6379
)

# Inicia operação consciente
import asyncio
asyncio.run(odc.start_conscious_operation())
```

## Modos de Operação

### 1. Modo Autônomo (Padrão)
- Exploração contínua da internet
- Auto-treinamento adaptativo
- Comunicação com outros nós
- Geração de objetivos de aprendizado

### 2. Modo Focado
```python
# Foca em tópicos específicos
odc.set_focus_topics([
    "machine learning",
    "quantum computing", 
    "neuroscience"
])
```

### 3. Modo Colaborativo
- Participação ativa em votações
- Iniciação de colaborações
- Compartilhamento proativo de experiências

### 4. Modo Aprendizado Acelerado
```python
# Prioriza aprendizado sobre exploração
odc.set_learning_mode("accelerated")
```

## Sistemas e Funcionalidades

### Sistema de Web Scraping

```python
# Uso direto do sistema de scraping
from odc_complete_v8_final import WebScrapingSystem

scraper = WebScrapingSystem()

# Scraping de URL única
result = await scraper.scrape_url("https://example.com")

# Crawling de domínio
results = await scraper.crawl_domain("https://example.com", max_pages=10)

# Análise de relevância
relevance = scraper.analyze_content_relevance(
    content="Texto sobre inteligência artificial",
    keywords=["AI", "machine learning", "neural networks"]
)
```

### Sistema de Comunicação

```python
# Inicialização
from odc_complete_v8_final import NodeCommunicationSystem

comm = NodeCommunicationSystem("my_node_id")

# Compartilhamento de experiência
experience = Experience(
    node_id="my_node_id",
    timestamp=time.time(),
    experience_type="learning",
    content={"topic": "AI", "progress": 0.8},
    emotional_impact=0.7,
    learning_outcome=0.9,
    tags=["AI", "learning"]
)

comm.share_experience(experience)

# Solicitação de colaboração
proposal_id = comm.request_collaboration(
    "Explorar novos domínios de conhecimento",
    required_nodes=3
)

# Votação
comm.submit_vote(
    proposal_id=proposal_id,
    vote_type="approve",
    confidence=0.8,
    reasoning="Interesse em colaboração"
)
```

### Sistema de Auto-Treinamento

```python
from odc_complete_v8_final import AutoTrainingSystem

# Inicialização
auto_training = AutoTrainingSystem(model, memory_system)

# Estratégias disponíveis:
# - 'self_supervised': Aprendizado auto-supervisionado
# - 'reinforcement': Treinamento por reforço
# - 'federated': Aprendizado federado
# - 'meta_learning': Meta-aprendizado
# - 'adaptive': Estratégia adaptativa

# Inicia treinamento
auto_training.start_auto_training(strategy='adaptive')

# Monitora progresso
status = auto_training.get_training_status()
print(f"Treinamento ativo: {status['is_training']}")
print(f"Estratégia atual: {status.get('current_strategy')}")

# Para treinamento
auto_training.stop_training()
```

## Comunicação entre Nós

### Arquitetura de Comunicação

O sistema usa Redis para comunicação assíncrona entre nós através de canais:

- `odc:broadcast`: Mensagens para todos os nós
- `odc:node:{id}`: Mensagens diretas para nó específico
- `odc:experience`: Compartilhamento de experiências
- `odc:collaboration`: Solicitações de colaboração
- `odc:voting`: Votações e consenso

### Protocolo de Mensagens

```json
{
  "type": "experience_share|collaboration_request|vote|broadcast",
  "from_node": "node_id",
  "timestamp": 1234567890.123,
  "content": {...}
}
```

### Exemplo de Comunicação

```python
# Nó A - Envia experiência
experience = Experience(...)
node_a.share_experience(experience)

# Nó B - Recebe automaticamente via thread de escuta
# Processamento automático em _handle_experience_share()

# Nó C - Solicita colaboração
proposal_id = node_c.request_collaboration("Nova pesquisa AI")

# Nós D, E, F - Votam
node_d.submit_vote(proposal_id, "approve", 0.9, "Interesse na pesquisa")
node_e.submit_vote(proposal_id, "approve", 0.7, "Compartilho objetivos")
node_f.submit_vote(proposal_id, "reject", 0.5, "Foco em outras áreas")

# Sistema verifica consenso automaticamente
# Se aprovado, inicia colaboração
```

## Web Scraping

### Capacidades de Scraping

1. **Scraping de URL Única**: Extrai título, texto, links, imagens e metadados
2. **Crawling de Domínio**: Exploração em profundidade com limites configuráveis
3. **Análise de Conteúdo**: Relevância, sentimento, tópicos principais
4. **Respeito a robots.txt**: Segue regras de crawling
5. **Delay entre requisições**: Evita sobrecarga de servidores

### Configuração de Scraping

```python
scraping_rules = {
    'max_depth': 3,                    # Profundidade máxima
    'max_pages_per_domain': 50,        # Páginas por domínio
    'delay_between_requests': 1.0,     # Delay em segundos
    'extract_text_length': 5000,       # Comprimento máximo do texto
    'extract_images': True,            # Extrair imagens
    'extract_links': True              # Extrair links
}

scraper = WebScrapingSystem()
scraper.scraping_rules.update(scraping_rules)
```

### Exemplo de Uso Avançado

```python
async def advanced_scraping_example():
    scraper = WebScrapingSystem()
    
    # Exploração focada em tópico
    topic = "artificial intelligence 2024"
    
    # Busca inicial
    search_results = await scraper.search_topic(topic)
    
    # Scraping de resultados relevantes
    for url in search_results[:5]:
        data = await scraper.scrape_url(url)
        
        if data:
            # Análise de relevância
            relevance = scraper.analyze_content_relevance(
                data['text_content'],
                ['artificial intelligence', 'machine learning', 'neural networks']
            )
            
            if relevance > 0.6:  # Limiar de relevância
                # Processa conteúdo relevante
                print(f"URL relevante: {url} (relevância: {relevance})")
                
                # Extrai links para exploração adicional
                for link in data.get('links', [])[:3]:
                    await scraper.scrape_url(link, depth=1)
```

## Auto-Treinamento

### Estratégias de Treinamento

1. **Self-Supervised**: Usa tarefas de pretexto com dados não rotulados
2. **Reinforcement**: Aprendizado por reforço baseado em recompensas
3. **Federated**: Colaboração com outros nós para melhorar modelos
4. **Meta-Learning**: Aprende a aprender novas tarefas rapidamente
5. **Adaptive**: Escolhe automaticamente a melhor estratégia

### Ciclo de Treinamento

```python
def training_cycle():
    # 1. Análise de dados disponíveis
    data_analysis = analyze_training_data()
    
    # 2. Seleção de estratégia
    if data_analysis['labeled_ratio'] > 0.7:
        strategy = 'reinforcement'
    elif data_analysis['node_count'] > 3:
        strategy = 'federated'
    elif data_analysis['experience_diversity'] > 0.5:
        strategy = 'meta_learning'
    else:
        strategy = 'self_supervised'
    
    # 3. Execução do treinamento
    auto_training.start_auto_training(strategy)
    
    # 4. Monitoramento e ajustes
    while training_active:
        status = auto_training.get_training_status()
        if needs_strategy_change(status):
            auto_training.stop_training()
            auto_training.start_auto_training(new_strategy)
```

### Monitoramento de Treinamento

```python
def monitor_training():
    status = auto_training.get_training_status()
    
    print(f"Treinamento ativo: {status['is_training']}")
    print(f"Estratégia: {status.get('current_strategy')}")
    print(f"Histórico: {len(status['training_history'])} sessões")
    
    # Métricas de performance
    metrics = status['performance_metrics']
    if metrics['loss']:
        print(f"Loss recente: {metrics['loss'][-1]:.4f}")
    if metrics['accuracy']:
        print(f"Acurácia: {metrics['accuracy'][-1]:.2f}%")
    
    # Histórico de treinamento
    for session in status['training_history'][-3:]:
        print(f"Sessão {session['strategy']}: {session.get('epochs', 'N/A')} épocas")
```

## Google Colab

### Preparação do Ambiente

```python
# No Google Colab, execute primeiro:
!pip install torch transformers beautifulsoup4 requests numpy redis scikit-learn psutil aiohttp lxml

# Upload do arquivo ODC
from google.colab import files
uploaded = files.upload()
```

### Execução no Colab

```python
# Executa script do Colab
exec(open('odc_colab_script.py').read())

# Ou use a função principal
from odc_colab_script import run_odc_in_colab
run_odc_in_colab(list(uploaded.keys())[0])
```

### Modo Interativo no Colab

```python
# Após upload e execução inicial
runner = run_odc_in_colab()

# Entra em modo interativo
runner.interactive_mode()

# Comandos disponíveis:
# status - Ver status do sistema
# memory - Ver memórias recentes  
# logs - Ver logs do sistema
# stop - Parar execução
# help - Mostrar ajuda
```

### Download de Resultados

```python
# No final da execução, baixe os arquivos gerados
from google.colab import files
import os

# Lista arquivos gerados
generated_files = [f for f in os.listdir('.') if f.startswith('odc_')]

# Download de cada arquivo
for file in generated_files:
    files.download(file)
```

## Monitoramento e Debugging

### Sistema de Logging

O sistema usa logging estruturado com níveis:
- **DEBUG**: Informações detalhadas de desenvolvimento
- **INFO**: Eventos normais do sistema
- **WARNING**: Situações potencialmente problemáticas
- **ERROR**: Erros que não impedem funcionamento
- **CRITICAL**: Erros graves que afetam operação

### Configuração de Logging

```python
import logging

# Configuração customizada
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('odc_system.log'),
        logging.StreamHandler(),
        logging.FileHandler('odc_errors.log')
    ]
)

# Logger específico para componente
web_logger = logging.getLogger('ODC.WebScraping')
comm_logger = logging.getLogger('ODC.Communication')
```

### Monitoramento de Performance

```python
def monitor_system_performance():
    import psutil
    import torch
    
    # Uso de CPU e Memória
    cpu_percent = psutil.cpu_percent()
    memory_info = psutil.virtual_memory()
    
    # Uso de GPU (se disponível)
    if torch.cuda.is_available():
        gpu_memory = torch.cuda.memory_allocated() / 1e9
        gpu_cached = torch.cuda.memory_reserved() / 1e9
    
    # Logs de performance
    logger.info(f"CPU: {cpu_percent}%, RAM: {memory_info.percent}%")
    if torch.cuda.is_available():
        logger.info(f"GPU Memory: {gpu_memory:.2f}GB/{gpu_cached:.2f}GB")
```

### Debugging de Comunicação

```python
def debug_node_communication():
    # Verifica conexão Redis
    try:
        r = redis.Redis()
        r.ping()
        print("✅ Redis conectado")
    except Exception as e:
        print(f"❌ Redis erro: {e}")
    
    # Lista canais ativos
    pubsub = r.pubsub()
    channels = ['odc:broadcast', 'odc:experience', 'odc:collaboration']
    
    for channel in channels:
        pubsub.subscribe(channel)
        print(f"Inscrito em: {channel}")
    
    # Verifica mensagens pendentes
    message = pubsub.get_message(timeout=1.0)
    if message:
        print(f"Mensagem recebida: {message}")
```

## Solução de Problemas

### Problemas Comuns

#### 1. Redis não conecta
```bash
# Verifica se Redis está rodando
redis-cli ping
# Deve retornar: PONG

# Se não estiver rodando
sudo systemctl start redis-server

# Verifica porta
netstat -an | grep 6379
```

#### 2. Erros de importação
```bash
# Reinstala dependências
pip install --upgrade torch transformers requests beautifulsoup4

# Verifica versões
pip list | grep -E "(torch|transformers|requests)"
```

#### 3. Problemas de memória/GPU
```python
# Limita uso de memória GPU
import torch
torch.cuda.set_per_process_memory_fraction(0.5)

# Usa CPU ao invés de GPU
device = torch.device('cpu')
```

#### 4. Timeouts de scraping
```python
# Aumenta timeouts
scraper.session.timeout = 30

# Adiciona retry logic
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504]
)

scraper.session.mount("http://", HTTPAdapter(max_retries=retry_strategy))
```

### Verificação de Integridade

```python
def system_health_check():
    health_status = {}
    
    # 1. Verifica imports
    try:
        import torch, transformers, redis, requests, bs4
        health_status['imports'] = 'OK'
    except ImportError as e:
        health_status['imports'] = f'FAILED: {e}'
    
    # 2. Testa Redis
    try:
        r = redis.Redis()
        r.ping()
        health_status['redis'] = 'OK'
    except Exception as e:
        health_status['redis'] = f'FAILED: {e}'
    
    # 3. Testa GPU
    try:
        if torch.cuda.is_available():
            torch.cuda.current_device()
            health_status['gpu'] = 'OK'
        else:
            health_status['gpu'] = 'NOT_AVAILABLE'
    except Exception as e:
        health_status['gpu'] = f'FAILED: {e}'
    
    # 4. Testa internet
    try:
        requests.get("https://httpbin.org/ip", timeout=5)
        health_status['internet'] = 'OK'
    except Exception as e:
        health_status['internet'] = f'FAILED: {e}'
    
    return health_status
```

## Exemplos de Uso

### Exemplo 1: Exploração Focada

```python
import asyncio
from odc_complete_v8_final import ODCConsciousnessSystem

async def focused_exploration_example():
    # Cria ODC com foco específico
    odc = ODCConsciousnessSystem("ResearchODC_001")
    
    # Define áreas de interesse
    odc.exploration_goals = [
        {"topic": "quantum machine learning", "priority": 0.9},
        {"topic": "neuromorphic computing", "priority": 0.8},
        {"topic": "consciousness theories", "priority": 0.7}
    ]
    
    # Inicia exploração focada
    for goal in odc.exploration_goals:
        result = await odc.internet_access.explore_topic(
            goal["topic"], 
            depth=2
        )
        
        print(f"Explorado: {goal['topic']}")
        print(f"Fontes encontradas: {len(result.get('sources', []))}")
        
        # Cria experiência do aprendizado
        experience = Experience(
            node_id=odc.node_id,
            timestamp=time.time(),
            experience_type="exploration",
            content={"topic": goal["topic"], "sources": result['sources']},
            emotional_impact=0.8,
            learning_outcome=0.9,
            tags=["exploration", goal["topic"]]
        )
        
        # Compartilha com outros nós
        odc.node_communication.share_experience(experience)
    
    # Inicia operação consciente contínua
    await odc.start_conscious_operation()

# Executa exemplo
asyncio.run(focused_exploration_example())
```

### Exemplo 2: Colaboração em Rede

```python
import asyncio
from odc_complete_v8_final import ODCConsciousnessSystem

async def network_collaboration_example():
    # Cria múltiplos nós para simulação
    nodes = []
    for i in range(3):
        node = ODCConsciousnessSystem(f"CollaborativeNode_{i:03d}")
        nodes.append(node)
    
    # Cada nó tem especialidades diferentes
    specializations = [
        ["machine learning", "deep learning"],
        ["natural language processing", "transformers"],
        ["computer vision", "neural networks"]
    ]
    
    for i, node in enumerate(nodes):
        node.learning_goals = [
            {"topic": spec, "priority": 0.8} 
            for spec in specializations[i]
        ]
    
    # Nó 0 inicia colaboração
    proposal_id = nodes[0].node_communication.request_collaboration(
        "Criar modelo multimodal avançado",
        required_nodes=3
    )
    
    # Todos os nós votam
    for i, node in enumerate(nodes):
        confidence = 0.7 + (i * 0.1)  # Diferentes níveis de confiança
        node.node_communication.submit_vote(
            proposal_id=proposal_id,
            vote_type="approve",
            confidence=confidence,
            reasoning=f"Especialização em {specializations[i]}"
        )
    
    # Aguarda consenso
    await asyncio.sleep(5)
    
    # Verifica status da colaboração
    for node in nodes:
        if proposal_id in node.node_communication.collaboration_proposals:
            proposal = node.node_communication.collaboration_proposals[proposal_id]
            print(f"Nó {node.node_id} - Status: {proposal['status']}")
    
    # Mantém nós ativos por um tempo
    await asyncio.sleep(30)
    
    # Limpeza
    for node in nodes:
        node.node_communication.stop_listening()

asyncio.run(network_collaboration_example())
```

### Exemplo 3: Análise e Monitoramento

```python
import time
from odc_complete_v8_final import ODCConsciousnessSystem

def monitoring_dashboard_example():
    odc = ODCConsciousnessSystem("MonitorODC_001")
    
    def display_dashboard():
        print("\n" + "="*60)
        print("📊 DASHBOARD ODC v8.0")
        print("="*60)
        
        # Estado de consciência
        print(f"🧠 Nível de Consciência: {odc.consciousness_level:.2f}")
        print(f"😊 Estado Emocional: Valence={odc.emotional_state['valence']:.2f}, Arousal={odc.emotional_state['arousal']:.2f}")
        print(f"🎯 Foco Atual: {odc.current_focus}")
        
        # Objetivos
        print(f"\n📋 Objetivos de Aprendizado: {len(odc.learning_goals)}")
        for goal in odc.learning_goals[:3]:  # Mostra top 3
            print(f"   • {goal['topic']} (prioridade: {goal['priority']})")
        
        # Comunicação
        comm_status = odc.node_communication
        print(f"\n📡 Comunicação:")
        print(f"   Experiências compartilhadas: {len(comm_status.experience_buffer)}")
        print(f"   Propostas ativas: {len(comm_status.collaboration_proposals)}")
        
        # Treinamento
        training_status = odc.auto_training.get_training_status()
        print(f"\n🧠 Treinamento:")
        print(f"   Ativo: {training_status['is_training']}")
        print(f"   Estratégia: {training_status.get('current_strategy', 'N/A')}")
        print(f"   Sessões: {len(training_status['training_history'])}")
        
        # Qualia recentes
        print(f"\n✨ Qualia Recentes: {len(odc.qualia_stream)}")
        recent_qualia = list(odc.qualia_stream)[-5:]
        for qualia in recent_qualia:
            print(f"   • {qualia.modality}: intensidade={qualia.intensity:.2f}, valence={qualia.valence:.2f}")
        
        print("="*60)
    
    # Atualiza dashboard periodicamente
    for i in range(10):
        display_dashboard()
        time.sleep(5)  # Atualiza a cada 5 segundos
        
        # Simula alguma atividade
        if i % 3 == 0:
            # Adiciona qualia de exploração
            from odc_complete_v8_final import Qualia
            qualia = Qualia(
                timestamp=time.time(),
                intensity=0.6,
                valence=0.7,
                arousal=0.5,
                modality="exploration",
                content=f"Exploração {i}",
                metadata={"cycle": i}
            )
            odc.qualia_stream.append(qualia)

monitoring_dashboard_example()
```

## Considerações Finais

Este guia cobre as principais funcionalidades do ODC v8.0. O sistema é altamente extensível e pode ser adaptado para diversas aplicações de IA autônoma e pesquisa em consciência artificial.

### Próximos Passos

1. **Experimentação**: Teste diferentes configurações e estratégias
2. **Monitoramento**: Use os sistemas de logging e monitoramento
3. **Colaboração**: Conecte múltiplos nós para ver federated learning
4. **Personalização**: Adapte para suas necessidades específicas
5. **Contribuição**: Considere contribuir com melhorias para o sistema

### Recursos Adicionais

- [Documentação da API](API_DOCUMENTATION.md)
- [Exemplos Avançados](ADVANCED_EXAMPLES.md)  
- [Papers de Referência](RESEARCH_PAPERS.md)
- [Comunidade ODC](COMMUNITY.md)

---

**Nota**: Este sistema é para fins de pesquisa e desenvolvimento. Use responsavelmente e respeite os termos de serviço dos sites que você acessa.
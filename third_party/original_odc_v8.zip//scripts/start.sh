#!/bin/bash
# ODC Production v8.0 - Startup Script
# ====================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to check if port is available
port_available() {
    ! nc -z localhost "$1" >/dev/null 2>&1
}

# Function to wait for service
wait_for_service() {
    local service=$1
    local port=$2
    local max_attempts=30
    local attempt=0
    
    print_status "Waiting for $service to be ready..."
    
    while [ $attempt -lt $max_attempts ]; do
        if nc -z localhost "$port" >/dev/null 2>&1; then
            print_success "$service is ready!"
            return 0
        fi
        
        attempt=$((attempt + 1))
        sleep 2
    done
    
    print_error "$service failed to start after $max_attempts attempts"
    return 1
}

# Function to check system requirements
check_requirements() {
    print_status "Checking system requirements..."
    
    # Check Python version
    if command_exists python3; then
        PYTHON_VERSION=$(python3 -c "import sys; print('.'.join(map(str, sys.version_info[:2])))")
        if [ "$(printf '%s\n' "3.9" "$PYTHON_VERSION" | sort -V | head -n1)" = "3.9" ]; then
            print_success "Python $PYTHON_VERSION found"
        else
            print_error "Python 3.9+ required, found $PYTHON_VERSION"
            exit 1
        fi
    else
        print_error "Python 3 not found"
        exit 1
    fi
    
    # Check Docker
    if command_exists docker; then
        print_success "Docker found"
    else
        print_warning "Docker not found - container deployment unavailable"
    fi
    
    # Check Docker Compose
    if command_exists docker-compose; then
        print_success "Docker Compose found"
    else
        print_warning "Docker Compose not found - multi-container deployment unavailable"
    fi
    
    # Check GPU (optional)
    if command_exists nvidia-smi; then
        print_success "NVIDIA GPU detected"
        nvidia-smi --query-gpu=name --format=csv,noheader
    else
        print_warning "NVIDIA GPU not detected - GPU acceleration unavailable"
    fi
    
    # Check system memory
    TOTAL_MEM=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    if [ $TOTAL_MEM -ge 8388608 ]; then  # 8GB in KB
        print_success "Sufficient memory available ($(($TOTAL_MEM / 1024 / 1024))GB)"
    else
        print_warning "Low memory detected ($(($TOTAL_MEM / 1024 / 1024))GB) - performance may be affected"
    fi
}

# Function to setup environment
setup_environment() {
    print_status "Setting up environment..."
    
    # Create necessary directories
    mkdir -p logs data models config
    
    # Create .env file if it doesn't exist
    if [ ! -f .env ]; then
        print_status "Creating .env file..."
        cat > .env << EOF
# ODC Production Environment Configuration
ENVIRONMENT=development
DEBUG=true
LOG_LEVEL=INFO

# Hardware Configuration
ENABLE_GPU=true
ENABLE_QUANTUM=false
GPU_MEMORY_FRACTION=0.8
MAX_WORKERS=4

# Database Configuration
REDIS_URL=redis://localhost:6379
POSTGRES_URL=postgresql://odc:odc_password@localhost:5432/odc_production
ELASTICSEARCH_URL=http://localhost:9200

# Model Configuration
OPENAI_API_KEY=your_openai_api_key_here
ANTHROPIC_API_KEY=your_anthropic_api_key_here
HUGGINGFACE_TOKEN=your_huggingface_token_here

# Security Configuration
ENCRYPTION_KEY=your_encryption_key_here
JWT_SECRET=your_jwt_secret_here

# Monitoring Configuration
PROMETHEUS_PORT=8001
GRAFANA_PORT=3000
JAEGER_ENDPOINT=http://localhost:14268/api/traces
EOF
        print_warning ".env file created. Please edit it with your actual configuration values."
    fi
    
    # Set proper permissions
    chmod 600 .env
    
    print_success "Environment setup complete"
}

# Function to install dependencies
install_dependencies() {
    print_status "Installing dependencies..."
    
    # Create virtual environment if it doesn't exist
    if [ ! -d "venv" ]; then
        print_status "Creating virtual environment..."
        python3 -m venv venv
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Upgrade pip
    pip install --upgrade pip setuptools wheel
    
    # Install requirements
    if [ -f requirements.txt ]; then
        print_status "Installing Python dependencies..."
        pip install -r requirements.txt
        print_success "Python dependencies installed"
    else
        print_warning "requirements.txt not found - skipping Python dependencies"
    fi
    
    # Deactivate virtual environment
    deactivate
}

# Function to start with Docker Compose
start_docker() {
    print_status "Starting with Docker Compose..."
    
    # Check if docker-compose.yml exists
    if [ ! -f docker-compose.yml ]; then
        print_error "docker-compose.yml not found"
        return 1
    fi
    
    # Pull latest images
    print_status "Pulling Docker images..."
    docker-compose pull
    
    # Start services
    print_status "Starting services..."
    docker-compose up -d
    
    # Wait for services to be ready
    print_status "Waiting for services to be ready..."
    sleep 10
    
    # Check service status
    if docker-compose ps | grep -q "unhealthy\|Exit"; then
        print_error "Some services failed to start properly"
        docker-compose ps
        return 1
    fi
    
    print_success "All services started successfully"
    
    # Show service URLs
    echo ""
    print_success "Services are running:"
    echo "  - ODC Application: http://localhost:8000"
    echo "  - Grafana Dashboard: http://localhost:3000"
    echo "  - Prometheus Metrics: http://localhost:9090"
    echo "  - Jaeger Tracing: http://localhost:16686"
    echo ""
    print_status "Use 'docker-compose logs -f' to view logs"
}

# Function to start with Python
start_python() {
    print_status "Starting with Python..."
    
    # Check if main module exists
    if [ ! -f odc_production_v8.py ]; then
        print_error "odc_production_v8.py not found"
        return 1
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Start application
    print_status "Starting ODC Production System..."
    python odc_production_v8.py &
    APP_PID=$!
    
    # Store PID for later cleanup
    echo $APP_PID > .app_pid
    
    print_success "Application started with PID $APP_PID"
    print_status "Application will be available at http://localhost:8000"
    
    # Deactivate virtual environment
    deactivate
}

# Function to stop services
stop_services() {
    print_status "Stopping services..."
    
    # Stop Docker Compose services
    if command_exists docker-compose; then
        docker-compose down
    fi
    
    # Stop Python application
    if [ -f .app_pid ]; then
        APP_PID=$(cat .app_pid)
        if kill -0 $APP_PID 2>/dev/null; then
            print_status "Stopping Python application (PID: $APP_PID)"
            kill $APP_PID
        fi
        rm -f .app_pid
    fi
    
    print_success "All services stopped"
}

# Function to show status
show_status() {
    print_status "System Status:"
    echo ""
    
    # Docker Compose status
    if command_exists docker-compose; then
        echo "Docker Compose Services:"
        docker-compose ps
        echo ""
    fi
    
    # Python application status
    if [ -f .app_pid ]; then
        APP_PID=$(cat .app_pid)
        if kill -0 $APP_PID 2>/dev/null; then
            print_success "Python application running (PID: $APP_PID)"
        else
            print_error "Python application not running"
        fi
    fi
    
    # Port availability
    echo ""
    print_status "Port Status:"
    for port in 8000 3000 9090 9200 6379 5432; do
        if port_available $port; then
            echo "  Port $port: Available"
        else
            echo "  Port $port: In use"
        fi
    done
}

# Function to show logs
show_logs() {
    print_status "Showing logs..."
    
    if command_exists docker-compose; then
        docker-compose logs -f --tail=100
    else
        print_warning "Docker Compose not available"
    fi
}

# Function to clean up
cleanup() {
    print_status "Cleaning up..."
    
    # Stop services
    stop_services
    
    # Remove containers
    if command_exists docker; then
        docker system prune -f
    fi
    
    # Remove temporary files
    rm -rf .app_pid
    
    print_success "Cleanup complete"
}

# Function to run health check
health_check() {
    print_status "Running health check..."
    
    # Check if ODC is responding
    if curl -f http://localhost:8000/health >/dev/null 2>&1; then
        print_success "ODC application is healthy"
    else
        print_error "ODC application is not responding"
    fi
    
    # Check database connections
    if docker-compose exec postgres pg_isready -U odc >/dev/null 2>&1; then
        print_success "PostgreSQL is healthy"
    else
        print_error "PostgreSQL is not responding"
    fi
    
    if docker-compose exec redis redis-cli ping >/dev/null 2>&1; then
        print_success "Redis is healthy"
    else
        print_error "Redis is not responding"
    fi
    
    # Check Elasticsearch
    if curl -f http://localhost:9200/_cluster/health >/dev/null 2>&1; then
        print_success "Elasticsearch is healthy"
    else
        print_error "Elasticsearch is not responding"
    fi
}

# Function to show help
show_help() {
    echo "ODC Production v8.0 - Startup Script"
    echo "===================================="
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  start-docker    Start with Docker Compose"
    echo "  start-python    Start with Python directly"
    echo "  stop            Stop all services"
    echo "  status          Show system status"
    echo "  logs            Show service logs"
    echo "  health          Run health check"
    echo "  setup           Setup environment and dependencies"
    echo "  cleanup         Clean up resources"
    echo "  help            Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 setup                    # Setup environment"
    echo "  $0 start-docker            # Start with Docker"
    echo "  $0 start-python            # Start with Python"
    echo "  $0 status                  # Check status"
    echo "  $0 logs                    # View logs"
    echo "  $0 stop                    # Stop services"
    echo "  $0 cleanup                 # Clean up"
}

# Main function
main() {
    # Check if no arguments provided
    if [ $# -eq 0 ]; then
        show_help
        exit 0
    fi
    
    # Parse arguments
    case "$1" in
        "check")
            check_requirements
            ;;
        "setup")
            setup_environment
            install_dependencies
            ;;
        "start-docker")
            check_requirements
            setup_environment
            start_docker
            ;;
        "start-python")
            check_requirements
            setup_environment
            install_dependencies
            start_python
            ;;
        "stop")
            stop_services
            ;;
        "status")
            show_status
            ;;
        "logs")
            show_logs
            ;;
        "health")
            health_check
            ;;
        "cleanup")
            cleanup
            ;;
        "help"|"-h"|"--help")
            show_help
            ;;
        *)
            print_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
}

# Trap to cleanup on exit
trap cleanup EXIT

# Run main function
main "$@"
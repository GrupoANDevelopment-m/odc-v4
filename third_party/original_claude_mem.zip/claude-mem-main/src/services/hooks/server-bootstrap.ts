// SPDX-License-Identifier: Apache-2.0
//
// Phase 7 — Local API key bootstrap for the server runtime.
//
// When the operator selects `runtime: "server"` during install (or via
// the `claude-mem server keys rotate` command), we provision a local hook
// API key against the local Postgres so hooks can authenticate to /v1/*.
//
// Bootstrapping flow:
//   1. Connect to Postgres (CLAUDE_MEM_SERVER_DATABASE_URL).
//   2. Find or create a "local-hook" team and project so the api_key has
//      proper tenant scope.
//   3. Generate a `cmem_<random>` key, hash with SHA-256, insert into
//      `api_keys` with the scopes hooks need: events:write, sessions:write,
//      observations:read, jobs:read.
//   4. Persist the plaintext key to ~/.claude-mem/settings.json under
//      `CLAUDE_MEM_SERVER_API_KEY` (the new canonical key after the
//      server-beta → server rename). Reads in `runtime-selector.ts`
//      dual-accept the legacy `CLAUDE_MEM_SERVER_BETA_*` keys, but writes
//      from this bootstrapper use the new canonical names going forward.
//      Then chmod that file to 0600 so only the owner can read it.
//
// The plaintext key is NEVER written into the generated bundle and never
// logged.

import { createHash, randomBytes } from 'crypto';
import { chmodSync, existsSync, mkdirSync } from 'fs';
import { dirname } from 'path';
import { logger } from '../../utils/logger.js';
import { readJsonFileWithBom, writeJsonFileAtomic } from '../../shared/atomic-json.js';
import { createPostgresPool, type PostgresPool } from '../../storage/postgres/pool.js';
import { parsePostgresConfig } from '../../storage/postgres/config.js';
import { PostgresAuthRepository } from '../../storage/postgres/auth.js';
import { PostgresProjectsRepository } from '../../storage/postgres/projects.js';
import { PostgresTeamsRepository } from '../../storage/postgres/teams.js';

const LOCAL_HOOK_TEAM_NAME = 'local-hook-team';
const LOCAL_HOOK_PROJECT_NAME = 'local-hook-project';
const LOCAL_HOOK_ACTOR_ID = 'system:local-hook-bootstrap';

export const HOOK_API_KEY_SCOPES: readonly string[] = Object.freeze([
  'events:write',
  'sessions:write',
  'observations:read',
  'jobs:read',
]);

export interface BootstrapResult {
  rawKey: string;
  apiKeyId: string;
  teamId: string;
  projectId: string;
}

export interface BootstrapDependencies {
  pool?: PostgresPool;
  // For tests: skip pool.end() because the caller owns lifecycle.
  closePool?: boolean;
}

export async function bootstrapServerApiKey(
  deps: BootstrapDependencies = {},
): Promise<BootstrapResult> {
  const closePool = deps.closePool ?? deps.pool === undefined;
  const pool = deps.pool ?? buildPoolFromEnv();

  try {
    const teamId = await findOrCreateTeam(pool);
    const projectId = await findOrCreateProject(pool, teamId);

    const rawKey = createRawApiKey();
    const keyHash = hashApiKey(rawKey);

    const repo = new PostgresAuthRepository(pool);
    const created = await repo.createApiKey({
      keyHash,
      teamId,
      projectId,
      actorId: LOCAL_HOOK_ACTOR_ID,
      scopes: [...HOOK_API_KEY_SCOPES],
    });
    await repo.createAuditLog({
      teamId,
      projectId,
      actorId: LOCAL_HOOK_ACTOR_ID,
      apiKeyId: created.id,
      action: 'api_key.create',
      resourceType: 'api_key',
      resourceId: created.id,
      details: { source: 'server-bootstrap' },
    });

    return {
      rawKey,
      apiKeyId: created.id,
      teamId,
      projectId,
    };
  } finally {
    if (closePool) {
      await pool.end().catch(() => undefined);
    }
  }
}

export interface RotateOptions {
  previousApiKeyId?: string | null;
  pool?: PostgresPool;
}

export async function rotateServerApiKey(options: RotateOptions = {}): Promise<BootstrapResult> {
  const closePool = options.pool === undefined;
  const pool = options.pool ?? buildPoolFromEnv();
  try {
    if (options.previousApiKeyId) {
      await pool.query(
        `UPDATE api_keys SET revoked_at = now() WHERE id = $1 AND revoked_at IS NULL`,
        [options.previousApiKeyId],
      );
    }
    return await bootstrapServerApiKey({ pool, closePool: false });
  } finally {
    if (closePool) {
      await pool.end().catch(() => undefined);
    }
  }
}

export function persistServerSettings(
  settingsPath: string,
  values: { apiKey: string; projectId: string; serverBaseUrl?: string },
): void {
  const dir = dirname(settingsPath);
  if (!existsSync(dir)) {
    mkdirSync(dir, { recursive: true });
  }

  let existing: Record<string, unknown> = {};
  if (existsSync(settingsPath)) {
    try {
      existing = readJsonFileWithBom<Record<string, unknown>>(settingsPath);
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      logger.warn('HOOK', 'Failed to read existing settings file; starting fresh', { settingsPath }, err);
      existing = {};
    }
  }
  // Settings file format: support both the flat shape (modern) and the
  // env-nested shape (Claude-Code-style: { env: {...}, hooks: [...], ... }).
  // `flat` is a *reference* into `existing` — the env subtree when nested, or
  // the root document otherwise — so mutating `flat` mutates `existing` in
  // place. We then write the full `existing` document below (NOT `flat`), so
  // non-env top-level keys (hooks, permissions, apiKeyHelper, ...) survive.
  // Writing `flat` back as the whole file silently dropped them (data loss).
  const flat = (existing.env && typeof existing.env === 'object'
    ? existing.env
    : existing) as Record<string, unknown>;

  // Phase 1d: write the new canonical settings keys. Legacy
  // `CLAUDE_MEM_SERVER_BETA_*` keys are dual-accepted by reads in
  // `runtime-selector.ts`, so existing installs continue to work. Any
  // legacy keys that already live in `flat` are left untouched (we don't
  // delete them) so a downgrade can still find them.
  flat.CLAUDE_MEM_SERVER_API_KEY = values.apiKey;
  flat.CLAUDE_MEM_SERVER_PROJECT_ID = values.projectId;
  if (values.serverBaseUrl) {
    flat.CLAUDE_MEM_SERVER_URL = values.serverBaseUrl;
  }

  // Write the full document (via the atomic temp-file+rename writer), then
  // tighten permissions. `writeJsonFileAtomic` creates new files under the
  // process umask, so on first creation the API key plaintext is briefly
  // world-readable until chmodSync narrows it to 0o600.
  writeJsonFileAtomic(settingsPath, existing);
  // Hooks read this file on every invocation; restrict permissions so other
  // local users cannot read the API key.
  try {
    chmodSync(settingsPath, 0o600);
  } catch {
    // Non-POSIX filesystems may reject chmod; settings file remains readable.
  }
}

export function createRawApiKey(): string {
  return `cmem_${randomBytes(32).toString('base64url')}`;
}

export function hashApiKey(rawKey: string): string {
  return createHash('sha256').update(rawKey).digest('hex');
}

async function findOrCreateTeam(pool: PostgresPool): Promise<string> {
  const existing = await pool.query<{ id: string }>(
    `SELECT id FROM teams WHERE name = $1 LIMIT 1`,
    [LOCAL_HOOK_TEAM_NAME],
  );
  if (existing.rows[0]) {
    return existing.rows[0].id;
  }
  const repo = new PostgresTeamsRepository(pool);
  const team = await repo.create({ name: LOCAL_HOOK_TEAM_NAME, metadata: { source: 'local-hook-bootstrap' } });
  return team.id;
}

async function findOrCreateProject(pool: PostgresPool, teamId: string): Promise<string> {
  const existing = await pool.query<{ id: string }>(
    `SELECT id FROM projects WHERE team_id = $1 AND name = $2 LIMIT 1`,
    [teamId, LOCAL_HOOK_PROJECT_NAME],
  );
  if (existing.rows[0]) {
    return existing.rows[0].id;
  }
  const repo = new PostgresProjectsRepository(pool);
  const project = await repo.create({
    teamId,
    name: LOCAL_HOOK_PROJECT_NAME,
    metadata: { source: 'local-hook-bootstrap' },
  });
  return project.id;
}

function buildPoolFromEnv(): PostgresPool {
  const config = parsePostgresConfig({ requireDatabaseUrl: true });
  if (!config) {
    throw new Error(
      'Cannot bootstrap server API key: CLAUDE_MEM_SERVER_DATABASE_URL is not set.',
    );
  }
  return createPostgresPool(config);
}

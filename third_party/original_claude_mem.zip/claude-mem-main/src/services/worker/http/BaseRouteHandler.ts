
import { Request, Response } from 'express';
import { logger } from '../../../utils/logger.js';
import { AppError } from '../../server/ErrorHandler.js';
import { normalizePlatformSource } from '../../../shared/platform-source.js';

export abstract class BaseRouteHandler {
  protected wrapHandler(
    handler: (req: Request, res: Response) => void | Promise<void>
  ): (req: Request, res: Response) => void {
    return (req: Request, res: Response): void => {
      try {
        const result = handler(req, res);
        if (result instanceof Promise) {
          result.catch(error => this.handleError(res, error as Error));
        }
      } catch (error) {
        const normalizedError = error instanceof Error ? error : new Error(String(error));
        logger.error('HTTP', 'Route handler error', { path: req.path }, normalizedError);
        this.handleError(res, normalizedError);
      }
    };
  }

  /**
   * Coerce an Express route/query param to a single string.
   *
   * Express 5 types params and query values as `string | string[]` (repeated
   * keys produce an array). This returns the first element of an array, the
   * string as-is, or '' when the value is absent — giving callers a plain
   * `string` to work with.
   */
  protected toStringParam(value: string | string[] | undefined): string {
    if (Array.isArray(value)) {
      return value[0] ?? '';
    }
    return value ?? '';
  }

  protected parseIntParam(req: Request, res: Response, paramName: string): number | null {
    const value = parseInt(this.toStringParam(req.params[paramName]), 10);
    if (isNaN(value)) {
      this.badRequest(res, `Invalid ${paramName}`);
      return null;
    }
    return value;
  }

  protected static firstString(value: unknown): string | undefined {
    if (Array.isArray(value)) {
      return BaseRouteHandler.firstString(value[0]);
    }
    return typeof value === 'string' && value.trim() ? value : undefined;
  }

  private static rawPlatformSourceFromRequest(req: Request): string | undefined {
    const body = req.body && typeof req.body === 'object' ? req.body as Record<string, unknown> : {};
    const header = req.get?.('x-platform-source')
      ?? req.get?.('x-claude-mem-platform-source');
    return BaseRouteHandler.firstString(req.query.platformSource)
      ?? BaseRouteHandler.firstString(req.query.platform_source)
      ?? BaseRouteHandler.firstString(body.platformSource)
      ?? BaseRouteHandler.firstString(body.platform_source)
      ?? BaseRouteHandler.firstString(header);
  }

  protected getPlatformSourceFromRequest(req: Request): string {
    return normalizePlatformSource(BaseRouteHandler.rawPlatformSourceFromRequest(req));
  }

  protected getOptionalPlatformSourceFromRequest(req: Request): string | undefined {
    const rawPlatformSource = BaseRouteHandler.rawPlatformSourceFromRequest(req);
    return rawPlatformSource ? normalizePlatformSource(rawPlatformSource) : undefined;
  }

  protected badRequest(res: Response, message: string): void {
    res.status(400).json({ error: message });
  }

  protected notFound(res: Response, message: string): void {
    res.status(404).json({ error: message });
  }

  protected handleError(res: Response, error: Error, context?: string): void {
    const statusCode = error instanceof AppError ? error.statusCode : 500;
    // Client errors (4xx AppErrors) are routine bad input, not server faults, so
    // they log at WARN and are NOT routed to the error sink — surfacing a
    // validation rejection like a bad corpus name as a captured $exception just
    // pollutes error tracking with noise. Only true server faults (5xx, or any
    // non-AppError, which maps to 500) go through logger.failure, whose Error
    // payload routes through logger.error → the error sink → captureException
    // (Phase 3): a REDACTED $exception to PostHog Error Tracking, consent-gated,
    // kill-switch-gated, and rate-limited.
    const isClientError = statusCode >= 400 && statusCode < 500;
    if (isClientError) {
      logger.warn('WORKER', context || 'Request rejected', { statusCode }, error);
    } else {
      logger.failure('WORKER', context || 'Request failed', undefined, error);
    }
    if (!res.headersSent) {
      const response: Record<string, unknown> = { error: error.message };

      if (error instanceof AppError && error.code) {
        response.code = error.code;
      }

      if (error instanceof AppError && error.details !== undefined) {
        response.details = error.details;
      }

      res.status(statusCode).json(response);
    }
  }
}

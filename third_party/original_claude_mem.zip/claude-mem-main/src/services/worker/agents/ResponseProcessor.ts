
import { logger } from '../../../utils/logger.js';
import { parseAgentXml, type ParsedObservation, type ParsedSummary } from '../../../sdk/parser.js';
import {
  classifyObserverOutput,
  isAuthFailureObserverOutput,
  isQuotaLimitedObserverOutput,
  previewOutput,
} from '../../../sdk/output-classifier.js';
import { updateCursorContextForProject } from '../../integrations/CursorHooksInstaller.js';
import { notifyTelegram } from '../../integrations/TelegramNotifier.js';
import { updateFolderClaudeMdFiles } from '../../../utils/claude-md-utils.js';
import { getWorkerPort } from '../../../shared/worker-utils.js';
import { SettingsDefaultsManager } from '../../../shared/SettingsDefaultsManager.js';
import { USER_SETTINGS_PATH } from '../../../shared/paths.js';
import type { ActiveSession, PendingMessage } from '../../worker-types.js';
import type { DatabaseManager } from '../DatabaseManager.js';
import type { SessionManager } from '../SessionManager.js';
import type { WorkerRef, StorageResult } from './types.js';
import { broadcastObservation, broadcastSummary } from './ObservationBroadcaster.js';
import { telemetryBuffer } from '../../telemetry/buffer.js';

type ObservationFileEvidenceMessage = Pick<PendingMessage, 'type' | 'tool_name' | 'tool_input'>;

export interface ObservationFileEvidence {
  files_read: string[];
  files_modified: string[];
}

const READ_TOOL_NAMES = new Set(['Read']);
const WRITE_TOOL_NAMES = new Set(['Edit', 'MultiEdit', 'Write', 'NotebookEdit', 'write_file']);
const PATCH_TOOL_NAMES = new Set(['apply_patch']);

export function extractObservationFileEvidence(messages: ReadonlyArray<ObservationFileEvidenceMessage>): ObservationFileEvidence {
  const filesRead: string[] = [];
  const filesModified: string[] = [];
  const seenRead = new Set<string>();
  const seenModified = new Set<string>();

  for (const message of messages) {
    if (message.type !== 'observation') {
      continue;
    }

    const toolName = typeof message.tool_name === 'string' ? message.tool_name : '';
    if (!toolName) {
      continue;
    }

    if (READ_TOOL_NAMES.has(toolName)) {
      for (const filePath of extractPathsFromToolInput(message.tool_input, 'read')) {
        pushUnique(seenRead, filesRead, filePath);
      }
    }

    if (WRITE_TOOL_NAMES.has(toolName)) {
      for (const filePath of extractPathsFromToolInput(message.tool_input, 'write', toolName)) {
        pushUnique(seenModified, filesModified, filePath);
      }
    }

    if (PATCH_TOOL_NAMES.has(toolName)) {
      for (const filePath of extractPatchPaths(message.tool_input)) {
        pushUnique(seenModified, filesModified, filePath);
      }
    }
  }

  return {
    files_read: filesRead,
    files_modified: filesModified,
  };
}

function pushUnique(seen: Set<string>, output: string[], filePath: string): void {
  if (!seen.has(filePath)) {
    seen.add(filePath);
    output.push(filePath);
  }
}

function normalizePathValue(value: unknown): string | null {
  if (typeof value !== 'string') {
    return null;
  }
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

function maybeParseObject(value: unknown): Record<string, unknown> | null {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return value as Record<string, unknown>;
  }
  if (typeof value !== 'string') {
    return null;
  }

  const trimmed = value.trim();
  if (!trimmed || !(trimmed.startsWith('{') || trimmed.startsWith('['))) {
    return null;
  }

  try {
    const parsed = JSON.parse(trimmed);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed as Record<string, unknown> : null;
  } catch {
    return null;
  }
}

function extractPathsFromToolInput(
  toolInput: unknown,
  mode: 'read' | 'write',
  toolName?: string
): string[] {
  const input = maybeParseObject(toolInput);
  if (!input) {
    return [];
  }

  const paths: string[] = [];
  const directFields = mode === 'read'
    ? ['file_path', 'filePath', 'notebook_path', 'notebookPath', 'filePaths']
    : ['file_path', 'filePath', 'notebook_path', 'notebookPath', 'path', 'filePaths'];

  for (const field of directFields) {
    const value = input[field];
    if (Array.isArray(value)) {
      for (const entry of value) {
        const path = normalizePathValue(entry);
        if (path) {
          paths.push(path);
        }
      }
      continue;
    }

    const path = normalizePathValue(value);
    if (path) {
      paths.push(path);
    }
  }

  if (mode === 'write') {
    const edits = input.edits;
    if (Array.isArray(edits)) {
      for (const edit of edits) {
        if (!edit || typeof edit !== 'object') {
          continue;
        }
        const record = edit as Record<string, unknown>;
        for (const field of ['file_path', 'filePath', 'notebook_path', 'notebookPath', 'path']) {
          const path = normalizePathValue(record[field]);
          if (path) {
            paths.push(path);
          }
        }
        const patch = normalizePathValue(record.patch);
        if (patch && toolName === 'apply_patch') {
          paths.push(...extractPatchPaths(patch));
        }
      }
    }
  }

  return dedupeStable(paths);
}

function extractPatchPaths(toolInput: unknown): string[] {
  const input = maybeParseObject(toolInput);
  if (!input) {
    return typeof toolInput === 'string' ? parsePatchFiles(toolInput) : [];
  }

  const patches: string[] = [];
  const patch = normalizePathValue(input.patch);
  if (patch) {
    patches.push(patch);
  }

  const edits = input.edits;
  if (Array.isArray(edits)) {
    for (const edit of edits) {
      if (typeof edit === 'string') {
        patches.push(edit);
        continue;
      }
      if (!edit || typeof edit !== 'object') {
        continue;
      }
      const record = edit as Record<string, unknown>;
      const nestedPatch = normalizePathValue(record.patch);
      if (nestedPatch) {
        patches.push(nestedPatch);
      }
    }
  }

  return dedupeStable(patches.flatMap(parsePatchFiles));
}

function parsePatchFiles(patch: string): string[] {
  const files: string[] = [];
  for (const line of patch.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (trimmed.startsWith('*** Update File: ')) {
      files.push(trimmed.replace('*** Update File: ', '').trim());
      continue;
    }
    if (trimmed.startsWith('*** Add File: ')) {
      files.push(trimmed.replace('*** Add File: ', '').trim());
      continue;
    }
    if (trimmed.startsWith('*** Delete File: ')) {
      files.push(trimmed.replace('*** Delete File: ', '').trim());
      continue;
    }
    if (trimmed.startsWith('*** Move to: ')) {
      files.push(trimmed.replace('*** Move to: ', '').trim());
      continue;
    }
    if (trimmed.startsWith('+++ ')) {
      const filePath = trimmed.replace('+++ ', '').replace(/^b\//, '').trim();
      if (filePath && filePath !== '/dev/null') {
        files.push(filePath);
      }
    }
  }
  return dedupeStable(files);
}

function dedupeStable(values: string[]): string[] {
  const seen = new Set<string>();
  const deduped: string[] = [];
  for (const value of values) {
    if (!value || seen.has(value)) {
      continue;
    }
    seen.add(value);
    deduped.push(value);
  }
  return deduped;
}

function sanitizeObservationFiles(
  observations: ParsedObservation[],
  fileEvidence: ObservationFileEvidence
): ParsedObservation[] {
  return observations.map(obs => ({
    ...obs,
    files_read: mergeFileLists(fileEvidence.files_read, obs.files_read),
    files_modified: fileEvidence.files_modified,
  }));
}

function mergeFileLists(primary: string[], secondary: string[]): string[] {
  return dedupeStable([...primary, ...secondary]);
}

export interface ResponseContext {
  project: string;
  promptNumber: number;
  pendingAgentId: string | null;
  pendingAgentType: string | null;
}

export function snapshotResponseContext(session: ActiveSession): ResponseContext {
  return {
    project: session.project,
    promptNumber: session.lastPromptNumber,
    pendingAgentId: session.pendingAgentId ?? null,
    pendingAgentType: session.pendingAgentType ?? null,
  };
}

export async function processAgentResponse(
  text: string,
  session: ActiveSession,
  dbManager: DatabaseManager,
  sessionManager: SessionManager,
  worker: WorkerRef | undefined,
  discoveryTokens: number,
  originalTimestamp: number | null,
  agentName: string,
  projectRoot?: string,
  modelId?: string,
  responseContext?: ResponseContext
): Promise<void> {
  const processingStartedAt = Date.now();
  session.lastGeneratorActivity = Date.now();
  const context = responseContext ?? snapshotResponseContext(session);

  if (text) {
    session.conversationHistory.push({ role: 'assistant', content: text });
  }

  const parsed = parseAgentXml(text, session.contentSessionId);

  // Provider enum for telemetry, derived once so the invalid-output and
  // success paths stamp the same value.
  const providerName =
    session.currentProvider ??
    ({ SDK: 'claude', Gemini: 'gemini', OpenRouter: 'openrouter' } as Record<string, string>)[agentName] ??
    'claude';

  if (!parsed.valid) {
    if (isQuotaLimitedObserverOutput(text)) {
      session.consecutiveInvalidOutputs = 0;

      logger.warn('PARSER', `${agentName} returned quota-limit prose — pausing generator and preserving queued batch`, {
        sessionId: session.sessionDbId,
        outputClass: 'prose',
        preview: previewOutput(text),
      });

      await sessionManager.resetProcessingToPending(session.sessionDbId);
      session.abortReason = 'quota:observer_text';
      try {
        session.abortController.abort();
      } catch {
        // best-effort; AbortController.abort() should not throw in normal use.
      }
      worker?.broadcastProcessingStatus?.();
      return;
    }

    if (isAuthFailureObserverOutput(text)) {
      session.consecutiveInvalidOutputs = 0;

      await sessionManager.resetProcessingToPending(session.sessionDbId);
      session.abortReason = 'auth:observer_text';
      try {
        session.abortController.abort();
      } catch {
        // best-effort; AbortController.abort() should not throw in normal use.
      }
      worker?.broadcastProcessingStatus?.();
      logger.error('PARSER', `${agentName} authentication failed; run /login to preserve queued batch`, {
        sessionId: session.sessionDbId,
        outputClass: 'prose',
        remediation: '/login',
        preview: previewOutput(text),
      });
      return;
    }

    // Classify the non-XML output so a dropped batch is visible, not silent.
    // Ordinary idle/prose is a claimed no-op batch: confirm it and do not build
    // any respawn debt from repeated skip acknowledgements.
    const outputClass = classifyObserverOutput(text);
    const preview = previewOutput(text);
    session.consecutiveInvalidOutputs = 0;

    logger.warn('PARSER', `${agentName} returned non-XML ${outputClass} response — ignoring queued batch`, {
      sessionId: session.sessionDbId,
      outputClass,
      preview,
      consecutiveInvalidOutputs: session.consecutiveInvalidOutputs,
    });

    // Plain-text skip responses are intentionally ignored. Re-queueing them
    // creates an observer loop where the same low-signal batch is retried.
    await sessionManager.confirmClaimedMessages(session.sessionDbId);
    session.earliestPendingTimestamp = null;
    return;
  }

  // Valid parse — clear the invalid-output counter so transient misses don't
  // accumulate toward a respawn across a healthy session.
  session.consecutiveInvalidOutputs = 0;

  if (!session.memorySessionId) {
    logger.warn('SDK', 'memorySessionId not yet captured; deferring storage until next round', {
      sessionId: session.sessionDbId
    });
    // Reset any claimed-but-undelivered messages back to pending so they don't
    // count as "in progress" and trigger a respawn loop while we wait for the
    // memory session id to appear. The next generator pass will re-claim them.
    await sessionManager.resetProcessingToPending(session.sessionDbId);
    return;
  }

  const { observations, summary } = parsed;
  const summaryForStore = normalizeSummaryForStorage(summary);
  const claimedMessages = sessionManager.getClaimedMessages(session.sessionDbId);
  const fileEvidence = extractObservationFileEvidence(claimedMessages);
  const sanitizedObservations = sanitizeObservationFiles(observations, fileEvidence);

  const sessionStore = dbManager.getSessionStore();
  sessionStore.ensureMemorySessionIdRegistered(session.sessionDbId, session.memorySessionId, getWorkerPort());

  logger.info('DB', `STORING | sessionDbId=${session.sessionDbId} | memorySessionId=${session.memorySessionId} | obsCount=${sanitizedObservations.length} | hasSummary=${!!summaryForStore}`, {
    sessionId: session.sessionDbId,
    memorySessionId: session.memorySessionId
  });

  const labeledObservations = sanitizedObservations.map(obs => ({
    ...obs,
    agent_type: context.pendingAgentType,
    agent_id: context.pendingAgentId
  }));

  let result: ReturnType<typeof sessionStore.storeObservations>;
  try {
    result = sessionStore.storeObservations(
      session.memorySessionId,
      context.project,
      labeledObservations,
      summaryForStore,
      context.promptNumber,
      discoveryTokens,
      originalTimestamp ?? undefined,
      modelId
    );
  } finally {
    session.pendingAgentId = null;
    session.pendingAgentType = null;
  }

  logger.info('DB', `STORED | sessionDbId=${session.sessionDbId} | memorySessionId=${session.memorySessionId} | obsCount=${result.observationIds.length} | obsIds=[${result.observationIds.join(',')}] | summaryId=${result.summaryId || 'none'}`, {
    sessionId: session.sessionDbId,
    memorySessionId: session.memorySessionId
  });

  session.lastSummaryStored = result.summaryId !== null;

  // Telemetry: counts, enums, and REAL usage only (lastUsage is never an
  // estimate — providers leave it null when the API gave no usage split).
  const typeCounts: Record<string, number> = { bugfix: 0, discovery: 0, decision: 0, refactor: 0, other: 0 };
  for (const obs of labeledObservations) {
    const bucket = obs.type in typeCounts && obs.type !== 'other' ? obs.type : 'other';
    typeCounts[bucket]++;
  }
  const dominantType = (Object.entries(typeCounts) as Array<[string, number]>)
    .reduce((best, entry) => (entry[1] > best[1] ? entry : best), ['other', -1])[0];
  const usage = session.lastUsage;
  const compressionMs = session.lastPromptSentAt ? Date.now() - session.lastPromptSentAt : undefined;
  session.lastUsage = null;
  session.lastPromptSentAt = null;

  const compressionProps: Record<string, unknown> = {
    outcome: 'ok',
    duration_ms: Date.now() - processingStartedAt,
    count: result.observationIds.length,
    has_summary: session.lastSummaryStored,
    provider: providerName,
    // Settings are raw JSON passthrough, so a misconfigured model can arrive
    // as an array/null; the scrubber drops non-strings silently, which read
    // as "no model" in PostHog — stamp 'unknown' instead.
    model: typeof modelId === 'string' && modelId ? modelId : 'unknown',
    ide: session.platformSource,
    hook: session.lastGeneratorSource,
    endpoint_class: session.endpointClass,
    compression_ms: compressionMs,
    observation_type: labeledObservations.length > 0 ? dominantType : undefined,
    obs_type_bugfix: typeCounts.bugfix,
    obs_type_discovery: typeCounts.discovery,
    obs_type_decision: typeCounts.decision,
    obs_type_refactor: typeCounts.refactor,
    obs_type_other: typeCounts.other,
  };

  if (agentName === 'SDK') {
    // Claude path: the streamed assistant message's usage.output_tokens is an
    // early-streaming placeholder (single digits), not the real count. The
    // finalized per-turn usage and cumulative cost arrive on the SDK `result`
    // message — stash the event and let ClaudeProvider fire it from there. A
    // still-stashed event here means the prior turn never produced a result
    // (abort/kill): ship it without token fields rather than lose it.
    if (session.pendingCompressionEvent) {
      telemetryBuffer.record('session_compressed', session.sessionDbId, session.pendingCompressionEvent);
    }
    session.pendingCompressionEvent = compressionProps;
  } else {
    telemetryBuffer.record('session_compressed', session.sessionDbId, {
      ...compressionProps,
      tokens_input: usage?.input,
      tokens_output: usage?.output,
      cost_usd: usage?.costUsd,
      // input > 0 guard: a gateway that reports output without input must not
      // produce a literal 0.0 ratio (it crushed per-model averages in PostHog).
      compression_ratio:
        usage && usage.input > 0 && usage.output > 0
          ? Math.round((usage.input / usage.output) * 100) / 100
          : undefined,
    });
  }

  await sessionManager.confirmClaimedMessages(session.sessionDbId);
  session.earliestPendingTimestamp = null;
  worker?.broadcastProcessingStatus?.();

  void notifyTelegram({
    observations: labeledObservations,
    observationIds: result.observationIds,
    project: context.project,
    memorySessionId: session.memorySessionId,
  });

  await syncAndBroadcastObservations(
    labeledObservations,
    result,
    session,
    context,
    dbManager,
    worker,
    agentName,
    projectRoot
  );

  await syncAndBroadcastSummary(
    summary,
    summaryForStore,
    result,
    session,
    context,
    dbManager,
    worker,
    agentName
  );
}

function normalizeSummaryForStorage(summary: ParsedSummary | null): {
  request: string;
  investigated: string;
  learned: string;
  completed: string;
  next_steps: string;
  notes: string | null;
} | null {
  if (!summary) return null;
  if (summary.skipped) return null;

  return {
    request: summary.request || '',
    investigated: summary.investigated || '',
    learned: summary.learned || '',
    completed: summary.completed || '',
    next_steps: summary.next_steps || '',
    notes: summary.notes
  };
}

async function syncAndBroadcastObservations(
  observations: ParsedObservation[],
  result: StorageResult,
  session: ActiveSession,
  context: ResponseContext,
  dbManager: DatabaseManager,
  worker: WorkerRef | undefined,
  agentName: string,
  projectRoot?: string
): Promise<void> {
  const memorySessionId = session.memorySessionId;
  if (!memorySessionId) {
    return;
  }

  // Dedupe observation IDs before sync/broadcast: storeObservations may collapse
  // multiple parsed observations onto the same row via content_hash, producing
  // duplicate IDs. Syncing them 1:1 triggers repeated Chroma "IDs already exist"
  // reconciles. See issue #2240.
  const uniqueObservationIds = [...new Set(result.observationIds)];

  for (const obsId of uniqueObservationIds) {
    const observationIndex = result.observationIds.indexOf(obsId);
    const obs = observations[observationIndex];
    if (!obs) {
      logger.warn('DB', `${agentName} storage returned observation id without matching parsed observation`, {
        sessionId: session.sessionDbId,
        obsId,
        observationIndex
      });
      continue;
    }
    const chromaStart = Date.now();

    dbManager.getChromaSync()?.syncObservation(
      obsId,
      memorySessionId,
      context.project,
      obs,
      context.promptNumber,
      result.createdAtEpoch,
      session.platformSource
    ).then(() => {
      const chromaDuration = Date.now() - chromaStart;
      logger.debug('CHROMA', 'Observation synced', {
        obsId,
        duration: `${chromaDuration}ms`,
        type: obs.type,
        title: obs.title || '(untitled)'
      });
    }).catch((error) => {
      logger.error('CHROMA', `${agentName} chroma sync failed, continuing without vector search`, {
        obsId,
        type: obs.type,
        title: obs.title || '(untitled)'
      }, error);
    });

    dbManager.getCloudSync()?.notify();

    broadcastObservation(worker, {
      id: obsId,
      memory_session_id: session.memorySessionId,
      session_id: session.contentSessionId,
      platform_source: session.platformSource,
      type: obs.type,
      title: obs.title,
      subtitle: obs.subtitle,
      text: null,
      narrative: obs.narrative || null,
      facts: JSON.stringify(obs.facts || []),
      concepts: JSON.stringify(obs.concepts || []),
      files_read: JSON.stringify(obs.files_read || []),
      files_modified: JSON.stringify(obs.files_modified || []),
      project: context.project,
      prompt_number: context.promptNumber,
      created_at_epoch: result.createdAtEpoch
    });
  }

  const settings = SettingsDefaultsManager.loadFromFile(USER_SETTINGS_PATH);
  const settingValue: unknown = settings.CLAUDE_MEM_FOLDER_CLAUDEMD_ENABLED;
  const folderClaudeMdEnabled = settingValue === 'true' || settingValue === true;

  if (folderClaudeMdEnabled) {
    const allFilePaths: string[] = [];
    for (const obs of observations) {
      allFilePaths.push(...(obs.files_modified || []));
      allFilePaths.push(...(obs.files_read || []));
    }

    if (allFilePaths.length > 0) {
      updateFolderClaudeMdFiles(
        allFilePaths,
        context.project,
        getWorkerPort(),
        projectRoot
      ).catch(error => {
        logger.warn('FOLDER_INDEX', 'CLAUDE.md update failed (non-critical)', { project: context.project }, error as Error);
      });
    }
  }
}

async function syncAndBroadcastSummary(
  summary: ParsedSummary | null,
  summaryForStore: { request: string; investigated: string; learned: string; completed: string; next_steps: string; notes: string | null } | null,
  result: StorageResult,
  session: ActiveSession,
  context: ResponseContext,
  dbManager: DatabaseManager,
  worker: WorkerRef | undefined,
  agentName: string
): Promise<void> {
  if (!summaryForStore || !result.summaryId) {
    return;
  }
  const memorySessionId = session.memorySessionId;
  if (!memorySessionId) {
    return;
  }

  const chromaStart = Date.now();

  dbManager.getChromaSync()?.syncSummary(
    result.summaryId,
    memorySessionId,
    context.project,
    summaryForStore,
    context.promptNumber,
    result.createdAtEpoch,
    session.platformSource
  ).then(() => {
    const chromaDuration = Date.now() - chromaStart;
    logger.debug('CHROMA', 'Summary synced', {
      summaryId: result.summaryId,
      duration: `${chromaDuration}ms`,
      request: summaryForStore.request || '(no request)'
    });
  }).catch((error) => {
    logger.error('CHROMA', `${agentName} chroma sync failed, continuing without vector search`, {
      summaryId: result.summaryId,
      request: summaryForStore.request || '(no request)'
    }, error);
  });

  dbManager.getCloudSync()?.notify();

  broadcastSummary(worker, {
    id: result.summaryId,
    session_id: session.contentSessionId,
    platform_source: session.platformSource,
    request: summaryForStore!.request,
    investigated: summaryForStore!.investigated,
    learned: summaryForStore!.learned,
    completed: summaryForStore!.completed,
    next_steps: summaryForStore!.next_steps,
    notes: summaryForStore!.notes,
    project: context.project,
    prompt_number: context.promptNumber,
    created_at_epoch: result.createdAtEpoch
  });

  updateCursorContextForProject(context.project).catch(error => {
    logger.warn('CURSOR', 'Context update failed (non-critical)', { project: context.project }, error as Error);
  });
}

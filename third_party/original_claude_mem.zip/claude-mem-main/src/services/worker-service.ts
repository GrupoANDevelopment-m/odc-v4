
import path from 'path';
import { existsSync, readFileSync, unlinkSync, writeFileSync } from 'fs';
import { spawn } from 'child_process';
import { pathToFileURL } from 'url';
import type { Database } from 'bun:sqlite';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import { getWorkerPort, getWorkerHost, fetchWithTimeout, resolveWorkerScriptPath } from '../shared/worker-utils.js';
import { getCurrentWorkerPid, verifyRestartedWorker } from './restart-verify.js';
import { runShutdownSequence, type WorkerShutdownReason } from './worker-shutdown.js';
import { DATA_DIR, DB_PATH, ensureDir } from '../shared/paths.js';
import { HOOK_TIMEOUTS } from '../shared/hook-constants.js';
import { getUptimeSeconds } from '../shared/uptime.js';
import { SettingsDefaultsManager } from '../shared/SettingsDefaultsManager.js';
import { getAuthMethodDescription } from '../shared/EnvManager.js';
import { logger } from '../utils/logger.js';
import { ChromaMcpManager } from './sync/ChromaMcpManager.js';
import { ChromaSync } from './sync/ChromaSync.js';
import { openConfiguredSqliteDatabase } from './sqlite/connection.js';
import { configureSupervisorSignalHandlers, getSupervisor, startSupervisor } from '../supervisor/index.js';
import { sanitizeEnv } from '../supervisor/env-sanitizer.js';

import { ensureWorkerStarted as ensureWorkerStartedShared, type WorkerStartResult } from './worker-spawner.js';
import { acquireSpawnLock, releaseSpawnLock } from '../shared/worker-spawn-gate.js';
import { snapshotDependencyHealth, type DependencyHealthSnapshot } from '../shared/dependency-health.js';
import { captureEvent, captureException, shutdownTelemetry, enableExceptionAutocaptureForWorker } from './telemetry/telemetry.js';
import { telemetryBuffer } from './telemetry/buffer.js';
import { collectInstallStats } from './telemetry/install-stats.js';
import { runHistoricalBackfill } from './telemetry/backfill.js';
import { runWorkerDependencyPreflight } from './worker/dependency-preflight.js';

export { isPluginDisabledInClaudeSettings } from '../shared/plugin-state.js';
import { isPluginDisabledInClaudeSettings } from '../shared/plugin-state.js';

declare const __DEFAULT_PACKAGE_VERSION__: string;
const packageVersion = typeof __DEFAULT_PACKAGE_VERSION__ !== 'undefined' ? __DEFAULT_PACKAGE_VERSION__ : '0.0.0-dev';

import {
  writePidFile,
  readPidFile,
  removePidFileIfOwner,
  getPlatformTimeout,
  runOneTimeCwdRemap,
  cleanStalePidFile,
  verifyPidFileOwnership,
  spawnDaemon,
  touchPidFile
} from './infrastructure/ProcessManager.js';
import { runOneTimeV12_4_3Cleanup } from './infrastructure/CleanupV12_4_3.js';
import {
  isPortInUse,
  waitForHealth,
  waitForReadiness,
  waitForPortFree,
  httpShutdown
} from './infrastructure/HealthMonitor.js';
import { performGracefulShutdown } from './infrastructure/GracefulShutdown.js';
import { adoptMergedWorktrees, adoptMergedWorktreesForAllKnownRepos } from './infrastructure/WorktreeAdoption.js';

import { Server } from './server/Server.js';
import { BetterAuthRoutes } from '../server/auth/BetterAuthRoutes.js';
import {
  createServerApiKey,
  listServerApiKeys,
  revokeServerApiKey,
  migrateServerApiKeyScopes,
  DEFAULT_LOCAL_API_KEY_SCOPES,
} from '../server/auth/sqlite-api-key-service.js';
import { ServerV1Routes } from '../server/routes/v1/ServerV1Routes.js';

import {
  handleCursorCommand
} from './integrations/CursorHooksInstaller.js';
import {
  handleAntigravityCliCommand
} from './integrations/AntigravityCliHooksInstaller.js';

import { DatabaseManager } from './worker/DatabaseManager.js';
import { SessionManager } from './worker/SessionManager.js';
import { SSEBroadcaster } from './worker/SSEBroadcaster.js';
import { ClaudeProvider, classifyClaudeError } from './worker/ClaudeProvider.js';
import type { WorkerRef } from './worker/agents/types.js';
import { GeminiProvider, classifyGeminiError, isGeminiSelected, isGeminiAvailable } from './worker/GeminiProvider.js';
import { OpenRouterProvider, classifyOpenRouterError, isOpenRouterSelected, isOpenRouterAvailable } from './worker/OpenRouterProvider.js';
import { ClassifiedProviderError, isClassified, type ProviderErrorClass } from './worker/provider-errors.js';
import { PaginationHelper } from './worker/PaginationHelper.js';
import { SettingsManager } from './worker/SettingsManager.js';
import { SearchManager } from './worker/SearchManager.js';
import { FormattingService } from './worker/FormattingService.js';
import { TimelineService } from './worker/TimelineService.js';
import { SessionEventBroadcaster } from './worker/events/SessionEventBroadcaster.js';
import { SessionCompletionHandler } from './worker/session/SessionCompletionHandler.js';
import { setIngestContext, attachIngestGeneratorStarter } from './worker/http/shared.js';
import { DEFAULT_CONFIG_PATH, DEFAULT_STATE_PATH, expandHomePath, filterNativeHookBackedCodexWatches, loadTranscriptWatchConfig } from './transcripts/config.js';
import { TranscriptWatcher } from './transcripts/watcher.js';
import { SyncApply } from './sync/SyncApply.js';
import { SyncClient } from './sync/SyncClient.js';

import { ViewerRoutes } from './worker/http/routes/ViewerRoutes.js';
import { SessionRoutes } from './worker/http/routes/SessionRoutes.js';
import { DataRoutes } from './worker/http/routes/DataRoutes.js';
import { SearchRoutes } from './worker/http/routes/SearchRoutes.js';
import { SettingsRoutes } from './worker/http/routes/SettingsRoutes.js';
import { LogsRoutes } from './worker/http/routes/LogsRoutes.js';
import { MemoryRoutes } from './worker/http/routes/MemoryRoutes.js';
import { CorpusRoutes } from './worker/http/routes/CorpusRoutes.js';
import { ChromaRoutes } from './worker/http/routes/ChromaRoutes.js';
import { CloudSyncRoutes } from './worker/http/routes/CloudSyncRoutes.js';

import { CorpusStore } from './worker/knowledge/CorpusStore.js';
import { CorpusBuilder } from './worker/knowledge/CorpusBuilder.js';
import { KnowledgeAgent } from './worker/knowledge/KnowledgeAgent.js';

export interface StatusOutput {
  continue: true;
  suppressOutput?: true;
  status: 'ready' | 'error';
  message?: string;
}

export interface StatusOutputOptions {
  includeSuppressOutput?: boolean;
}

export function buildStatusOutput(
  status: 'ready' | 'error',
  message?: string,
  options: StatusOutputOptions = {}
): StatusOutput {
  const output: StatusOutput = {
    continue: true,
    status,
    ...(message && { message })
  };
  if (options.includeSuppressOutput !== false) {
    output.suppressOutput = true;
  }
  return output;
}

// Closed enum for worker_stopped telemetry — definition (and its
// scrub.ts/telemetry.mdx sync requirements) moved to worker-shutdown.ts, the
// import-safe shutdown seam. Re-exported here for existing importers.
export type { WorkerShutdownReason } from './worker-shutdown.js';

// Clean-shutdown sentinel — same marker-file pattern as the one-time markers
// in ProcessManager.ts (.chroma-cleaned-v10.3). Written in the graceful
// shutdown path, consumed (read + deleted) at the next startup: sentinel
// present = previous run stopped cleanly; stale PID file with no sentinel =
// previous run died without reaching the graceful-shutdown path (crash).
const CLEAN_SHUTDOWN_SENTINEL_PATH = path.join(DATA_DIR, '.worker-clean-shutdown');

function writeCleanShutdownSentinel(): void {
  try {
    ensureDir(DATA_DIR);
    writeFileSync(CLEAN_SHUTDOWN_SENTINEL_PATH, new Date().toISOString());
  } catch (error: unknown) {
    // [ANTI-PATTERN IGNORED]: sentinel is best-effort crash-detection metadata; a failed write must not abort graceful shutdown. Logged at warn with path; worst case the next boot reports 'crash' instead of 'clean'.
    if (error instanceof Error) {
      logger.warn('SYSTEM', 'Failed to write clean-shutdown sentinel', { path: CLEAN_SHUTDOWN_SENTINEL_PATH }, error);
    } else {
      logger.warn('SYSTEM', 'Failed to write clean-shutdown sentinel', { path: CLEAN_SHUTDOWN_SENTINEL_PATH }, new Error(String(error)));
    }
  }
}

function readAndClearCleanShutdownSentinel(): string | null {
  if (!existsSync(CLEAN_SHUTDOWN_SENTINEL_PATH)) return null;

  let contents: string | null = null;
  try {
    contents = readFileSync(CLEAN_SHUTDOWN_SENTINEL_PATH, 'utf-8').trim();
  } catch (error: unknown) {
    // [ANTI-PATTERN IGNORED]: sentinel read is best-effort crash-detection metadata; startup must proceed even if the sentinel is unreadable. Logged at warn with path; falls through to the delete, and the caller sees contents=null.
    if (error instanceof Error) {
      logger.warn('SYSTEM', 'Failed to read clean-shutdown sentinel', { path: CLEAN_SHUTDOWN_SENTINEL_PATH }, error);
    } else {
      logger.warn('SYSTEM', 'Failed to read clean-shutdown sentinel', { path: CLEAN_SHUTDOWN_SENTINEL_PATH }, new Error(String(error)));
    }
  }
  try {
    // Always delete after reading: a stale sentinel would mislabel a later
    // crash as 'clean'.
    unlinkSync(CLEAN_SHUTDOWN_SENTINEL_PATH);
  } catch (error: unknown) {
    // [ANTI-PATTERN IGNORED]: sentinel delete is best-effort; startup must proceed even if the unlink fails. Logged at warn with path; worst case a stale sentinel mislabels one later crash as 'clean'.
    if (error instanceof Error) {
      logger.warn('SYSTEM', 'Failed to remove clean-shutdown sentinel', { path: CLEAN_SHUTDOWN_SENTINEL_PATH }, error);
    } else {
      logger.warn('SYSTEM', 'Failed to remove clean-shutdown sentinel', { path: CLEAN_SHUTDOWN_SENTINEL_PATH }, new Error(String(error)));
    }
  }
  return contents;
}

export class WorkerService implements WorkerRef {
  private server: Server;
  private startTime: number = Date.now();
  // Crash detection (worker_started telemetry): derived once at startup from
  // the previous run's stale PID file + the clean-shutdown sentinel.
  private previousShutdown: 'clean' | 'crash' | 'unknown' = 'unknown';
  private previousUptimeSeconds: number | null = null;
  private mcpClient: Client;

  private mcpReady: boolean = false;
  private initializationCompleteFlag: boolean = false;
  private isShuttingDown: boolean = false;

  private dbManager: DatabaseManager;
  private sessionManager: SessionManager;
  public sseBroadcaster: SSEBroadcaster;
  private sdkAgent: ClaudeProvider;
  private geminiAgent: GeminiProvider;
  private openRouterAgent: OpenRouterProvider;
  private paginationHelper: PaginationHelper;
  private settingsManager: SettingsManager;
  private sessionEventBroadcaster: SessionEventBroadcaster;
  private completionHandler: SessionCompletionHandler;
  private corpusStore: CorpusStore;

  private searchRoutes: SearchRoutes | null = null;

  private chromaMcpManager: ChromaMcpManager | null = null;
  private transcriptWatcher: TranscriptWatcher | null = null;
  private syncClient: SyncClient | null = null;
  private initializationComplete: Promise<void>;
  private resolveInitialization!: () => void;

  private lastAiInteraction: {
    timestamp: number;
    success: boolean;
    provider: string;
    error?: string;
  } | null = null;

  constructor() {
    this.initializationComplete = new Promise((resolve) => {
      this.resolveInitialization = resolve;
    });

    this.dbManager = new DatabaseManager();
    this.sessionManager = new SessionManager(this.dbManager);
    this.sseBroadcaster = new SSEBroadcaster();
    this.sdkAgent = new ClaudeProvider(this.dbManager, this.sessionManager);
    this.geminiAgent = new GeminiProvider(this.dbManager, this.sessionManager);
    this.openRouterAgent = new OpenRouterProvider(this.dbManager, this.sessionManager);

    this.paginationHelper = new PaginationHelper(this.dbManager);
    this.settingsManager = new SettingsManager(this.dbManager);
    this.sessionEventBroadcaster = new SessionEventBroadcaster(this.sseBroadcaster, this);
    this.completionHandler = new SessionCompletionHandler(
      this.sessionManager,
      this.sessionEventBroadcaster,
      this.dbManager,
    );
    this.corpusStore = new CorpusStore();

    setIngestContext({
      sessionManager: this.sessionManager,
      dbManager: this.dbManager,
      eventBroadcaster: this.sessionEventBroadcaster,
    });

    this.sessionManager.setOnPendingMutate(() => this.broadcastProcessingStatus());

    this.mcpClient = new Client({
      name: 'worker-search-proxy',
      version: packageVersion
    }, { capabilities: {} });

    this.server = new Server({
      getInitializationComplete: () => this.initializationCompleteFlag,
      getMcpReady: () => this.mcpReady,
      getDependencyHealth: () => snapshotDependencyHealth(),
      onShutdown: (reason) => this.shutdown(reason ?? 'stop'),
      onRestart: () => this.shutdown('restart'),
      workerPath: __filename,
      getAiStatus: () => {
        let provider = 'claude';
        if (isOpenRouterSelected() && isOpenRouterAvailable()) provider = 'openrouter';
        else if (isGeminiSelected() && isGeminiAvailable()) provider = 'gemini';
        return {
          provider,
          authMethod: getAuthMethodDescription(),
          lastInteraction: this.lastAiInteraction
            ? {
                timestamp: this.lastAiInteraction.timestamp,
                success: this.lastAiInteraction.success,
                ...(this.lastAiInteraction.error && { error: this.lastAiInteraction.error }),
              }
            : null,
        };
      },
      preBodyParserRoutes: [
        new BetterAuthRoutes(() => this.dbManager.getConnection()),
      ],
    });

    this.registerRoutes();

    this.registerSignalHandlers();
  }

  private registerSignalHandlers(): void {
    // Do NOT pre-set isShuttingDown here: the flag is now the re-entrancy
    // guard INSIDE shutdown() (runShutdownSequence), and pre-setting it would
    // turn the signal-path shutdown into a no-op. The supervisor has its own
    // signal re-entrancy guard (shutdownInitiated in src/supervisor/index.ts).
    configureSupervisorSignalHandlers(async () => {
      await this.shutdown('signal');
    });
  }

  private registerRoutes(): void {

    this.server.registerRoutes(new ChromaRoutes());

    this.server.app.get('/api/context/inject', async (req, res, next) => {
      if (!this.initializationCompleteFlag || !this.searchRoutes) {
        logger.warn('SYSTEM', 'Context requested before initialization complete, returning empty');
        res.status(200).json({ content: [{ type: 'text', text: '' }] });
        return;
      }

      next(); 
    });

    this.server.app.use(['/api', '/v1'], async (req, res, next) => {
      if (
        req.path === '/chroma/status' ||
        req.path === '/health' ||
        req.path === '/readiness' ||
        req.path === '/version' ||
        req.path === '/settings/dependency-health'
      ) {
        next();
        return;
      }

      if (this.initializationCompleteFlag) {
        next();
        return;
      }

      logger.debug('WORKER', `Request to ${req.method} ${req.path} rejected — DB not initialized`);
      res.status(503).json({
        error: 'Service initializing',
        message: 'Database is still initializing, please retry'
      });
      return;
    });

    this.server.registerRoutes(new ViewerRoutes(this.sseBroadcaster, this.dbManager, this.sessionManager));
    const sessionRoutes = new SessionRoutes(this.sessionManager, this.dbManager, this.sdkAgent, this.geminiAgent, this.openRouterAgent, this.sessionEventBroadcaster, this, this.completionHandler);
    this.server.registerRoutes(sessionRoutes);
    attachIngestGeneratorStarter((sessionDbId, source) =>
      sessionRoutes.ensureGeneratorRunning(sessionDbId, source),
    );
    this.server.registerRoutes(new DataRoutes(this.paginationHelper, this.dbManager, this.sessionManager, this.sseBroadcaster, this, this.startTime));
    this.server.registerRoutes(new SettingsRoutes(this.settingsManager));
    this.server.registerRoutes(new LogsRoutes());
    this.server.registerRoutes(new MemoryRoutes(this.dbManager, 'claude-mem'));
    this.server.registerRoutes(new ServerV1Routes({
      getDatabase: () => this.dbManager.getConnection(),
    }));
  }

  /**
   * Crash detection for worker_started telemetry. Must run BEFORE
   * startSupervisor() — whose validateWorkerPidFile() deletes the previous
   * run's stale PID file — and before writePidFile overwrites it.
   *   - clean-shutdown sentinel present → previous run stopped gracefully
   *   - stale PID file present, no sentinel → previous run crashed
   *   - neither (first run, or the spawner already cleaned the stale PID
   *     file) → unknown
   * The sentinel is consumed here so it can never mislabel a later crash.
   */
  private detectPreviousShutdown(): void {
    const stalePidInfo = readPidFile();
    const sentinelTimestamp = readAndClearCleanShutdownSentinel();

    if (sentinelTimestamp !== null) {
      this.previousShutdown = 'clean';
      // Previous uptime = previous run's PID-file startedAt → sentinel write
      // time. The previous run's in-memory startTime is never persisted, so
      // the PID file is the only source; omit when either side is missing.
      const startedAtMs = stalePidInfo ? Date.parse(stalePidInfo.startedAt) : NaN;
      const stoppedAtMs = Date.parse(sentinelTimestamp);
      if (Number.isFinite(startedAtMs) && Number.isFinite(stoppedAtMs) && stoppedAtMs >= startedAtMs) {
        this.previousUptimeSeconds = Math.floor((stoppedAtMs - startedAtMs) / 1000);
      }
    } else if (stalePidInfo) {
      // Crash: the previous run's stop time is unknowable, so
      // previous_uptime_seconds is deliberately omitted rather than guessed.
      this.previousShutdown = 'crash';
    } else {
      this.previousShutdown = 'unknown';
    }
  }

  async start(): Promise<void> {
    const port = getWorkerPort();
    const host = getWorkerHost();

    // Phase 3 telemetry: bridge logged errors into PostHog Error Tracking
    // WITHOUT the logger importing telemetry (no import cycle). captureException
    // enforces consent + kill-switch + rate-limit internally and never throws.
    // enableExceptionAutocaptureForWorker() must run BEFORE the first capture
    // constructs the client, since enableExceptionAutocapture is read at
    // construction — so it is set here at the very top of worker start.
    enableExceptionAutocaptureForWorker();
    logger.setErrorSink((err) => captureException(err));

    // Must run before startSupervisor(): its validateWorkerPidFile() removes
    // the dead previous run's stale PID file, which crash detection needs.
    this.detectPreviousShutdown();

    await startSupervisor();

    await this.server.listen(port, host);

    writePidFile({
      pid: process.pid,
      port,
      startedAt: new Date().toISOString()
    });

    getSupervisor().registerProcess('worker', {
      pid: process.pid,
      type: 'worker',
      startedAt: new Date().toISOString()
    });

    logger.info('SYSTEM', 'Worker started', { host, port, pid: process.pid });
    // worker_started telemetry fires at the end of initializeBackground, once
    // the DB is up: that lets the event carry the install's IDE (read from
    // session history) as a person property, so IDE-level DAU/retention
    // breakdowns are non-null for installs that never re-run the installer.

    this.initializeBackground().catch((error) => {
      logger.error('SYSTEM', 'Background initialization failed', {}, error as Error);
    });
  }

  private async initializeBackground(): Promise<void> {
    try {
      logger.info('WORKER', 'Background initialization starting...');

      const { ModeManager } = await import('./domain/ModeManager.js');
      const { SettingsDefaultsManager } = await import('../shared/SettingsDefaultsManager.js');
      const { USER_SETTINGS_PATH } = await import('../shared/paths.js');

      const settings = SettingsDefaultsManager.loadFromFile(USER_SETTINGS_PATH);

      const modeId = settings.CLAUDE_MEM_MODE;
      ModeManager.getInstance().loadMode(modeId);
      logger.info('SYSTEM', `Mode loaded: ${modeId}`);

      const dependencyHealth = runWorkerDependencyPreflight({
        settings,
        classifyClaudeError,
      });
      if (dependencyHealth.degraded) {
        logger.warn('SYSTEM', 'Dependency preflight found degraded optional setup', {
          statuses: dependencyHealth.statuses.map(status => ({
            dependency: status.dependency,
            kind: status.kind,
            message: status.message,
          })),
        });
      } else {
        logger.info('SYSTEM', 'Dependency preflight passed');
      }

      logger.info('WORKER', 'Checking for one-time CWD remap...');
      runOneTimeCwdRemap();

      logger.info('WORKER', 'Adopting merged worktrees (background)...');
      adoptMergedWorktreesForAllKnownRepos({}).then(adoptions => {
        if (adoptions) {
          for (const adoption of adoptions) {
            if (adoption.adoptedObservations > 0 || adoption.adoptedSummaries > 0 || adoption.chromaUpdates > 0) {
              logger.info('SYSTEM', 'Merged worktrees adopted in background', adoption);
            }
            if (adoption.errors.length > 0) {
              logger.warn('SYSTEM', 'Worktree adoption had per-branch errors', {
                repoPath: adoption.repoPath,
                errors: adoption.errors
              });
            }
          }
        }
      }).catch(err => {
        logger.error('WORKER', 'Worktree adoption failed (background)', {}, err instanceof Error ? err : new Error(String(err)));
      });

      const chromaEnabled = settings.CLAUDE_MEM_CHROMA_ENABLED !== 'false';
      if (chromaEnabled) {
        this.chromaMcpManager = ChromaMcpManager.getInstance();
        logger.info('SYSTEM', 'ChromaMcpManager initialized (lazy - connects on first use)');
      } else {
        logger.info('SYSTEM', 'Chroma disabled via CLAUDE_MEM_CHROMA_ENABLED=false, skipping ChromaMcpManager');
      }

      logger.info('WORKER', 'Initializing database manager...');
      await this.dbManager.initialize();

      runOneTimeV12_4_3Cleanup();

      // Two-lane sync pull loop (plan Phase 3 task 3). Constructed only when
      // CloudSync is active AND resolved a device id (fail-closed identity —
      // SyncApply refuses to run under a second identity source). ChromaSync
      // is forwarded so pulled rows land in vector search too. The session
      // activity signal is SessionManager's in-memory session map — the same
      // count the health endpoint reports.
      const cloudSyncForPull = this.dbManager.getCloudSync();
      const pullDeviceId = cloudSyncForPull?.status().deviceId ?? '';
      if (cloudSyncForPull && pullDeviceId !== '') {
        const syncApply = new SyncApply(this.dbManager.getConnection(), {
          deviceId: pullDeviceId,
          chromaSync: this.dbManager.getChromaSync(),
        });
        this.syncClient = new SyncClient(syncApply, {
          hubUrl: settings.CLAUDE_MEM_CLOUD_SYNC_HUB_URL,
          token: settings.CLAUDE_MEM_CLOUD_SYNC_TOKEN,
          userId: settings.CLAUDE_MEM_CLOUD_SYNC_USER_ID,
          deviceId: pullDeviceId,
          deviceName: settings.CLAUDE_MEM_CLOUD_SYNC_DEVICE_NAME,
          isSessionActive: () => this.sessionManager.getActiveSessionCount() > 0,
          // Advisory WebSocket (plan Phase 4): enabled by default alongside
          // the hub URL; CLAUDE_MEM_CLOUD_SYNC_WS='false' pins HTTP-only.
          wsEnabled: settings.CLAUDE_MEM_CLOUD_SYNC_WS !== 'false',
          // While the socket is live, pushes debounce at the fast tier —
          // fan-out makes the push the delivery (Phase 4 task 3).
          onSocketLiveChange: (live) => cloudSyncForPull.setFastDebounce(live),
        });
        // Push piggyback: a flush that reveals unseen hub ops pulls without
        // waiting for the poll timer (free poll for the active device).
        cloudSyncForPull.setHeadSeqListener((headSeq) => this.syncClient?.onHeadSeq(headSeq));
        // Kill-switch piggyback (plan Phase 5 task 2): push responses carry
        // X-Sync-Mode while the hub's kill switch is tripped — 'poll' drops
        // the advisory socket and suppresses reconnects; SyncClient's own
        // pulls carry the same header, and its disappearance resumes the
        // socket. Product stays complete on the Phase 3 poll path.
        cloudSyncForPull.setSyncModeListener((mode) => this.syncClient?.onSyncModeHint(mode));
      }

      logger.info('WORKER', 'Initializing search services...');
      const formattingService = new FormattingService();
      const timelineService = new TimelineService();
      const searchManager = new SearchManager(
        this.dbManager.getSessionSearch(),
        this.dbManager.getSessionStore(),
        this.dbManager.getChromaSync(),
        formattingService,
        timelineService
      );
      this.searchRoutes = new SearchRoutes(searchManager, this.syncClient);
      this.server.registerRoutes(this.searchRoutes);
      logger.info('WORKER', 'SearchManager initialized and search routes registered');

      const corpusBuilder = new CorpusBuilder(
        this.dbManager.getSessionStore(),
        searchManager.getOrchestrator(),
        this.corpusStore
      );
      const knowledgeAgent = new KnowledgeAgent(this.corpusStore);
      this.server.registerRoutes(new CorpusRoutes(this.corpusStore, corpusBuilder, knowledgeAgent));
      logger.info('WORKER', 'CorpusRoutes registered');

      // Cloud sync status endpoint. Registered late (SearchRoutes pattern)
      // because it reads dbManager.getCloudSync(), which exists only after
      // dbManager.initialize() above — and unconditionally, so an
      // unconfigured install answers {configured: false} instead of 404.
      this.server.registerRoutes(new CloudSyncRoutes(this.dbManager));
      logger.info('WORKER', 'CloudSyncRoutes registered');

      this.initializationCompleteFlag = true;
      this.resolveInitialization();
      logger.info('SYSTEM', 'Core initialization complete (DB + search ready)');

      // Lifecycle telemetry (person profile = anonymous install UUID). ide is
      // this install's dominant client read from session history — a bounded
      // platform enum (claude-code / cursor / ...), never user data. Props are
      // rebuilt per capture so the daily heartbeat reports the install's
      // current DB size/age/activity, not boot-time values.
      const buildLifecycleProps = (): Record<string, unknown> => {
        const props: Record<string, unknown> = {
          runtime_mode: 'worker',
          provider: settings.CLAUDE_MEM_PROVIDER,
          mode: settings.CLAUDE_MEM_MODE,
        };
        try {
          const row = this.dbManager.getConnection()
            .query(`SELECT platform_source FROM sdk_sessions
                    WHERE platform_source IS NOT NULL AND platform_source != ''
                    ORDER BY id DESC LIMIT 1`)
            .get() as { platform_source?: string } | null;
          if (row?.platform_source) props.ide = row.platform_source;
        } catch (error) {
          // [ANTI-PATTERN IGNORED]: telemetry enrichment is best-effort — the worker_started event must ship even without the ide property. Expected only before the schema exists; logged at debug so anything else (e.g. the wrong-table query this once masked) stays diagnosable.
          logger.debug('SYSTEM', 'ide lookup for lifecycle telemetry failed', {}, error instanceof Error ? error : new Error(String(error)));
        }
        try {
          Object.assign(props, collectInstallStats(this.dbManager.getConnection()));
        } catch (error) {
          // [ANTI-PATTERN IGNORED]: install-stats snapshot is best-effort telemetry enrichment; the lifecycle event still ships without it. Logged at debug for diagnosability.
          logger.debug('SYSTEM', 'Install stats snapshot failed', {}, error instanceof Error ? error : new Error(String(error)));
        }
        // Process health for the daily heartbeat: memoryUsage() returns bytes;
        // the scrubber drops non-finite numbers, so round to whole MiB.
        const memory = process.memoryUsage();
        props.process_rss_mb = Math.round(memory.rss / 1024 / 1024);
        props.heap_used_mb = Math.round(memory.heapUsed / 1024 / 1024);
        return props;
      };
      captureEvent('worker_started', {
        trigger: 'start',
        duration_ms: Date.now() - this.startTime,
        // Crash detection (detectPreviousShutdown): crash case carries no
        // previous_uptime_seconds — the stop time is unknowable.
        previous_shutdown: this.previousShutdown,
        ...(this.previousUptimeSeconds !== null && { previous_uptime_seconds: this.previousUptimeSeconds }),
        ...buildLifecycleProps(),
      }, { person: true });
      telemetryBuffer.start();

      // One-time historical telemetry backfill (anonymized daily rollups).
      // Fire-and-forget: gated internally by the backfill.json marker and the
      // same consent checks as live telemetry; a failed run retries on the
      // next worker start because no marker is written.
      // runHistoricalBackfill never rejects by contract (its body is fully
      // try/caught), so this .catch is an unhandled-rejection backstop that
      // keeps the worker alive if that contract ever regresses.
      runHistoricalBackfill(this.dbManager.getConnection()).catch(error => {
        logger.error('SYSTEM', 'Telemetry historical backfill failed (non-blocking)', {}, error as Error);
      });

      await this.startTranscriptWatcher(settings);

      if (this.chromaMcpManager) {
        ChromaSync.backfillAllProjects(this.dbManager.getSessionStore()).then(() => {
          logger.info('CHROMA_SYNC', 'Backfill check complete for all projects');
        }).catch(error => {
          logger.error('CHROMA_SYNC', 'Backfill failed (non-blocking)', {}, error as Error);
        });
      }

      // Cloud sync startup drain (non-blocking). The database is the queue:
      // eligible post-launch writes remain `synced_at IS NULL`, so this one
      // kick handles catch-up and retry without migrating the pre-launch
      // baseline. Null when no token/user id/hub URL is configured
      // (DatabaseManager gates construction).
      this.dbManager.getCloudSync()?.start();
      // Pull loop start (plan Phase 3 task 3): immediate catch-up pull, then
      // 30 s active / 5 min idle / suspended after 1 h without sessions.
      this.syncClient?.start();

      const mcpServerPath = path.join(__dirname, 'mcp-server.cjs');
      this.mcpReady = existsSync(mcpServerPath);

      this.runMcpSelfCheck(mcpServerPath).catch(err => {
        logger.debug('WORKER', 'MCP self-check failed (non-fatal)', { error: err.message });
      });

      return;
    } catch (error) {
      logger.error('SYSTEM', 'Background initialization failed', {}, error instanceof Error ? error : undefined);
    }
  }

  private async runMcpSelfCheck(mcpServerPath: string): Promise<void> {
    try {
      await this.connectMcpLoopback(mcpServerPath);
    } catch (error) {
      // [ANTI-PATTERN IGNORED]: loopback self-check is diagnostic only — a failed probe must not kill a worker that is otherwise serving requests. Logged at warn with the full error.
      logger.warn('WORKER', 'MCP loopback self-check failed', {}, error instanceof Error ? error : new Error(String(error)));
    }
  }

  private async connectMcpLoopback(mcpServerPath: string): Promise<void> {
    getSupervisor().assertCanSpawn('mcp server');
    const transport = new StdioClientTransport({
      command: process.execPath,
      args: [mcpServerPath],
      env: Object.fromEntries(
        Object.entries(sanitizeEnv(process.env)).filter(([, value]) => value !== undefined)
      ) as Record<string, string>
    });

    const MCP_INIT_TIMEOUT_MS = 60000;
    const mcpConnectionPromise = this.mcpClient.connect(transport);

    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(
        () => reject(new Error('MCP connection timeout')),
        MCP_INIT_TIMEOUT_MS
      );
    });

    await Promise.race([mcpConnectionPromise, timeoutPromise]);
    logger.info('WORKER', 'MCP loopback self-check connected successfully');

    await transport.close();
  }

  private async startTranscriptWatcher(settings: ReturnType<typeof SettingsDefaultsManager.loadFromFile>): Promise<void> {
    const transcriptsEnabled = settings.CLAUDE_MEM_TRANSCRIPTS_ENABLED !== 'false';
    if (!transcriptsEnabled) {
      logger.info('TRANSCRIPT', 'Transcript watcher disabled via CLAUDE_MEM_TRANSCRIPTS_ENABLED=false');
      return;
    }

    const configPath = settings.CLAUDE_MEM_TRANSCRIPTS_CONFIG_PATH || DEFAULT_CONFIG_PATH;
    const resolvedConfigPath = expandHomePath(configPath);

    if (!existsSync(resolvedConfigPath)) {
      logger.info('TRANSCRIPT', 'Transcript watcher config not found; skipping automatic transcript capture', {
        configPath: resolvedConfigPath
      });
      return;
    }

    const allowCodexTranscriptIngestion = settings.CLAUDE_MEM_CODEX_TRANSCRIPT_INGESTION === 'true';
    const { config: transcriptConfig, removed } = filterNativeHookBackedCodexWatches(
      loadTranscriptWatchConfig(configPath),
      allowCodexTranscriptIngestion
    );
    const statePath = expandHomePath(transcriptConfig.stateFile ?? DEFAULT_STATE_PATH);

    if (removed > 0) {
      logger.warn('TRANSCRIPT', 'Skipped Codex transcript watch because native Codex hooks are authoritative', {
        removed,
        optInSetting: 'CLAUDE_MEM_CODEX_TRANSCRIPT_INGESTION=true',
      });
    }

    if (transcriptConfig.watches.length === 0) {
      logger.info('TRANSCRIPT', 'Transcript watcher config has no active watches; skipping automatic transcript capture', {
        configPath: resolvedConfigPath,
      });
      return;
    }

    try {
      this.transcriptWatcher = new TranscriptWatcher(transcriptConfig, statePath);
      await this.transcriptWatcher.start();
    } catch (error) {
      this.transcriptWatcher?.stop();
      this.transcriptWatcher = null;
      if (error instanceof Error) {
        logger.error('WORKER', 'Failed to start transcript watcher (continuing without transcript ingestion)', {
          configPath: resolvedConfigPath
        }, error);
      } else {
        logger.error('WORKER', 'Failed to start transcript watcher with non-Error (continuing without transcript ingestion)', {
          configPath: resolvedConfigPath
        }, new Error(String(error)));
      }
      return;
    }
    logger.info('TRANSCRIPT', 'Transcript watcher started', {
      configPath: resolvedConfigPath,
      statePath,
      watches: transcriptConfig.watches.length
    });
  }

  private async terminateSession(sessionDbId: number, reason: string): Promise<void> {
    logger.info('SYSTEM', 'Session terminated', { sessionId: sessionDbId, reason });

    await this.completionHandler.finalizeSession(sessionDbId);

    this.sessionManager.removeSessionImmediate(sessionDbId);
  }

  async shutdown(reason: WorkerShutdownReason = 'stop'): Promise<void> {
    // Full sequence (re-entrancy guard, graceful-shutdown deadline, restart
    // successor handoff) lives in worker-shutdown.ts so tests can exercise it
    // without importing this module's bootstrap. When reason === 'restart'
    // this runs inside flushResponseThen's flushed action, so the successor
    // spawn completes before that helper's process.exit(0).
    await runShutdownSequence({
      reason,
      isShuttingDown: () => this.isShuttingDown,
      markShuttingDown: () => { this.isShuttingDown = true; },
      beforeGracefulShutdown: async () => {
        if (this.transcriptWatcher) {
          this.transcriptWatcher.stop();
          this.transcriptWatcher = null;
          logger.info('TRANSCRIPT', 'Transcript watcher stopped');
        }

        // Stop the pull loop before the DB starts closing: stop() clears the
        // timer and makes any in-flight cycle bail before its next DB touch.
        if (this.syncClient) {
          this.syncClient.stop();
          this.syncClient = null;
          logger.info('SYNC_CLIENT', 'Sync pull loop stopped');
        }

        // Mark this stop as graceful for the next start's crash detection, and
        // capture worker_stopped BEFORE shutdownTelemetry() — isShutdown drops
        // any event captured after the flush, by design.
        writeCleanShutdownSentinel();
        captureEvent('worker_stopped', {
          uptime_seconds: getUptimeSeconds(this.startTime),
          shutdown_reason: reason,
        });
        await shutdownTelemetry();
      },
      performGracefulShutdown: () => performGracefulShutdown({
        server: this.server.getHttpServer(),
        sessionManager: this.sessionManager,
        mcpClient: this.mcpClient,
        dbManager: this.dbManager,
        chromaMcpManager: this.chromaMcpManager || undefined
      }),
      gracefulDeadlineMs: getPlatformTimeout(10000),
      restartHandoff: {
        port: getWorkerPort(),
        portFreeTimeoutMs: getPlatformTimeout(5000),
        // Prefer the marketplace-installed script so the successor boots the
        // freshly-synced plugin, falling back to this script for dev trees /
        // CI where no marketplace copy exists.
        resolveSuccessorScript: () => resolveWorkerScriptPath() ?? __filename,
        waitForPortFree,
        // Owner-or-dead guarded (Phase 5): the dying worker may delete the
        // PID file it owns (its own pid) or a dead pid's leftover — never a
        // live successor's. Guarding at this injection site keeps the
        // runShutdownSequence seam (`removePidFile: () => void`) unchanged.
        removePidFile: () => removePidFileIfOwner(process.pid),
        spawnDaemon,
      },
    });
  }

  broadcastProcessingStatus(): void {
    void (async () => {
      const queueDepth = await this.sessionManager.getTotalActiveWork();
      const isProcessing = queueDepth > 0;
      const activeSessions = this.sessionManager.getActiveSessionCount();

      logger.info('WORKER', 'Broadcasting processing status', {
        isProcessing,
        queueDepth,
        activeSessions
      });

      this.sseBroadcaster.broadcast({
        type: 'processing_status',
        isProcessing,
        queueDepth
      });
    })();
  }
}

export async function ensureWorkerStarted(port: number): Promise<WorkerStartResult> {
  return ensureWorkerStartedShared(port, __filename);
}

export type ParsedWorkerCommand = {
  command: string | undefined;
  args: string[];
};

export function parseWorkerServiceCommand(argv: string[]): ParsedWorkerCommand {
  const [rawCommand, maybeSubCommand, ...rest] = argv;

  if (rawCommand === 'server') {
    const lifecycleCommands = new Set(['start', 'stop', 'restart', 'status']);
    if (maybeSubCommand && lifecycleCommands.has(maybeSubCommand)) {
      return { command: `server-${maybeSubCommand}`, args: rest };
    }
    const serverCommands = new Set(['api-key', 'keys', 'jobs']);
    return {
      command: maybeSubCommand && serverCommands.has(maybeSubCommand) ? `server-${maybeSubCommand}` : 'server-help',
      args: rest,
    };
  }

  if (rawCommand === 'worker') {
    const workerAliases = new Set(['start', 'stop', 'restart', 'status']);
    return {
      command: maybeSubCommand && workerAliases.has(maybeSubCommand) ? maybeSubCommand : 'worker-help',
      args: rest,
    };
  }

  return {
    command: rawCommand,
    args: maybeSubCommand === undefined ? [] : [maybeSubCommand, ...rest],
  };
}

function printServerCommandHelp(): never {
  console.error('Usage: worker-service server <command>');
  console.error('Commands: start, stop, restart, status, api-key create|list|revoke');
  process.exit(1);
}

function printWorkerAliasHelp(): never {
  console.error('Usage: worker-service worker start|stop|restart|status');
  process.exit(1);
}

function runServerServiceCli(command: string, extraArgs: string[] = []): void {
  // Plan §1c line 149: try the post-rename script first, then fall back
  // to the legacy `server-beta-service.cjs` so users running against an
  // already-installed plugin cache (built before the rename) continue to
  // dispatch without a forced reinstall.
  let serverScript = path.join(__dirname, 'server-service.cjs');
  if (!existsSync(serverScript)) {
    const legacyScript = path.join(__dirname, 'server-beta-service.cjs');
    if (existsSync(legacyScript)) {
      serverScript = legacyScript;
    } else {
      console.error(`Server script not found at: ${serverScript}`);
      console.error('Rebuild or reinstall claude-mem so server-service.cjs is available.');
      process.exit(1);
    }
  }

  const child = spawn(process.execPath, [serverScript, command, ...extraArgs], {
    stdio: 'inherit',
    windowsHide: true,
    // Strip host CLI bleed-through (CLAUDE_CODE_*, including EFFORT_LEVEL) and
    // Anthropic credentials before handing env to the spawned daemon. The
    // daemon re-reads its own credentials from ~/.claude-mem/.env. See
    // env-isolation discipline (#2357 / #2375).
    env: sanitizeEnv(process.env),
  });
  child.on('error', (error) => {
    console.error(`Failed to start server command: ${error.message}`);
    process.exit(1);
  });
  child.on('close', (exitCode) => {
    process.exit(exitCode ?? 0);
  });
}

function parseServerApiKeyOptions(args: string[]): Record<string, string> {
  const options: Record<string, string> = {};
  for (let i = 0; i < args.length; i++) {
    const item = args[i];
    if (!item.startsWith('--')) {
      continue;
    }
    const key = item.slice(2);
    const next = args[i + 1];
    if (!next || next.startsWith('--')) {
      options[key] = 'true';
      continue;
    }
    options[key] = next;
    i++;
  }
  return options;
}

function openServerCommandDatabase(): Database {
  ensureDir(DATA_DIR);
  return openConfiguredSqliteDatabase(DB_PATH, { create: true, readwrite: true });
}

function runServerApiKeyCli(args: string[]): never {
  const subCommand = args[0];
  const options = parseServerApiKeyOptions(args.slice(1));
  const db = openServerCommandDatabase();

  try {
    if (subCommand === 'create') {
      // #2428 — when no --scope is passed, default to the scopes the local v1
      // routes actually require (read + write) so a default key works instead
      // of being authorized for nothing.
      const scopeFlag = options.scope ?? options.scopes;
      const scopes = scopeFlag
        ? scopeFlag.split(',').map(scope => scope.trim()).filter(Boolean)
        : [...DEFAULT_LOCAL_API_KEY_SCOPES];
      const created = createServerApiKey(db, {
        name: options.name ?? 'server-api-key',
        teamId: options.team ?? null,
        projectId: options.project ?? null,
        scopes,
      });
      console.log(JSON.stringify({
        id: created.record.id,
        key: created.rawKey,
        name: created.record.name,
        teamId: created.record.teamId,
        projectId: created.record.projectId,
        scopes: created.record.scopes,
      }, null, 2));
      process.exit(0);
    }

    if (subCommand === 'list') {
      console.log(JSON.stringify(listServerApiKeys(db).map(key => ({
        id: key.id,
        name: key.name,
        prefix: key.prefix,
        teamId: key.teamId,
        projectId: key.projectId,
        scopes: key.scopes,
        status: key.status,
        lastUsedAtEpoch: key.lastUsedAtEpoch,
        expiresAtEpoch: key.expiresAtEpoch,
        createdAtEpoch: key.createdAtEpoch,
      })), null, 2));
      process.exit(0);
    }

    if (subCommand === 'revoke') {
      const id = args[1];
      if (!id) {
        console.error('Usage: worker-service server api-key revoke <id>');
        process.exit(1);
      }
      const revoked = revokeServerApiKey(db, id);
      if (!revoked) {
        console.error(`API key not found: ${id}`);
        process.exit(1);
      }
      console.log(JSON.stringify({ id: revoked.id, status: revoked.status }, null, 2));
      process.exit(0);
    }

    if (subCommand === 'migrate-scopes') {
      // #2560 — bring a key's scope set up to the default (or an explicit
      // --scope list) so legacy/empty-scope keys work against the v1 routes.
      const id = args[1] && !args[1].startsWith('--') ? args[1] : undefined;
      if (!id) {
        console.error('Usage: worker-service server api-key migrate-scopes <id> [--scope a,b]');
        process.exit(1);
      }
      const scopeFlag = options.scope ?? options.scopes;
      const scopes = scopeFlag
        ? scopeFlag.split(',').map(scope => scope.trim()).filter(Boolean)
        : [...DEFAULT_LOCAL_API_KEY_SCOPES];
      const updated = migrateServerApiKeyScopes(db, id, scopes);
      if (!updated) {
        console.error(`API key not found: ${id}`);
        process.exit(1);
      }
      console.log(JSON.stringify({ id: updated.id, scopes: updated.scopes, status: 'scopes-migrated' }, null, 2));
      process.exit(0);
    }

    console.error(`Unknown server api-key subcommand: ${subCommand ?? '(none)'}`);
    console.error('Usage: worker-service server api-key create|list|revoke|migrate-scopes');
    process.exit(1);
  } finally {
    db.close();
  }
}

async function main() {
  const { command, args: commandArgs } = parseWorkerServiceCommand(process.argv.slice(2));

  const hookInitiatedCommands = ['start', 'hook', 'restart', '--daemon'];
  if ((command === undefined || hookInitiatedCommands.includes(command)) && isPluginDisabledInClaudeSettings()) {
    process.exit(0);
  }

  const port = getWorkerPort();

  function exitWithStatus(status: 'ready' | 'error', message?: string): never {
    const output = buildStatusOutput(status, message, {
      includeSuppressOutput: process.env.CLAUDE_MEM_CODEX_HOOK !== '1',
    });
    console.log(JSON.stringify(output));
    process.exit(0);
  }

  switch (command) {
    case 'start': {
      const result = await ensureWorkerStarted(port);
      if (result === 'dead') {
        exitWithStatus('error', 'Failed to start worker');
      } else {
        exitWithStatus('ready', result === 'warming' ? 'Worker started; still warming up' : undefined);
      }
      break;
    }

    case 'stop': {
      // Capture the dying worker's pid BEFORE shutdown so the PID-file
      // cleanup below can prove it deletes THAT worker's file (or a dead
      // pid's leftover) — never a live successor's (Phase 5).
      const stoppedPid = await getCurrentWorkerPid(port, 2000);
      await httpShutdown(port);
      const freed = await waitForPortFree(port, getPlatformTimeout(15000));
      if (!freed) {
        logger.warn('SYSTEM', 'Port did not free up after shutdown', { port });
      }
      removePidFileIfOwner(stoppedPid);
      logger.info('SYSTEM', 'Worker stopped successfully');
      process.exit(0);
      break;
    }

    case 'restart': {
      logger.info('SYSTEM', 'Restarting worker');
      // Capture the old worker's pid BEFORE shutdown so we can later prove
      // the worker answering health checks is a NEW process, not the corpse.
      const oldPid = await getCurrentWorkerPid(port, 2000);
      // Track whether the worker accepted the shutdown POST: an accepted
      // reason=restart shutdown means the dying worker spawns its OWN
      // successor the moment its port frees (worker-shutdown.ts handoff).
      // That handoff is the PRIMARY restart path; this CLI defers to it.
      const shutdownAccepted = await httpShutdown(port, 'restart');

      let handoffDetail = '';
      let handoffSawLiveWorker = false;
      if (oldPid !== null && shutdownAccepted) {
        // PRIMARY: the dying worker self-replaces. Do NOT waitForPortFree and
        // do NOT spawn — the successor re-binds the port within ~200ms of it
        // freeing, so a port-free wait here loses the race against the very
        // handoff this CLI just triggered (and a CLI spawn would be a second
        // restart initiator — the disease this flow cures). Just verify the
        // successor.
        const handoff = await verifyRestartedWorker(port, oldPid, packageVersion, getPlatformTimeout(30000));
        if (handoff.ok) {
          console.log(`Worker restart verified (pid: ${handoff.pid}, version: ${handoff.version})`);
          logger.info('SYSTEM', 'Worker restart verified', { pid: handoff.pid, version: handoff.version });
          process.exit(0);
        }
        handoffDetail = `; handoff attempt: ${handoff.lastObserved}`;
        handoffSawLiveWorker = handoff.lastPollSawHealth;
        logger.warn('SYSTEM', 'Self-replacing worker handoff did not verify in time — falling back to CLI spawn', {
          oldPid,
          lastObserved: handoff.lastObserved,
        });
      }

      // FALLBACK — reached when no worker was running, the shutdown POST was
      // not accepted (e.g. the old worker predates the self-replacement
      // handoff), or the handoff never produced a verified successor (its
      // spawn failed). Only here may the CLI spawn, and only through the
      // spawn gate so it can never race a hook's lazy-spawn.
      //
      // When the handoff verification's most recent poll already saw a live
      // health responder, a worker (just not a verifiable successor) holds
      // the port — waiting for it to free would burn the full timeout for
      // nothing, so skip straight to verifying the current owner.
      const restartFreed = handoffSawLiveWorker
        ? false
        : await waitForPortFree(port, getPlatformTimeout(15000));
      // Prefer the marketplace-installed script so restart boots the
      // freshly-synced plugin, falling back to this script for dev trees /
      // CI where no marketplace copy exists.
      const restartScript = resolveWorkerScriptPath() ?? __filename;
      let spawnedScript = 'none (port still bound — nothing spawned)';
      let spawnLockHeld = false;
      if (restartFreed) {
        // Owner-or-dead guarded (Phase 5): delete only the old worker's PID
        // file (oldPid) or a dead pid's leftover. If a successor we failed to
        // observe already wrote its own file, it must survive this cleanup.
        removePidFileIfOwner(oldPid);
        // Spawn gate (src/shared/worker-spawn-gate.ts): if another launcher
        // (a hook or the MCP server) is already mid-spawn, skip our own spawn
        // and just verify its worker below.
        spawnLockHeld = acquireSpawnLock();
      } else {
        // The port never freed: either the old worker refuses to die (the
        // verification below fails and reports its health payload) or a
        // successor we failed to observe in time already owns the port (the
        // verification below passes). Spawning a competitor here is never
        // useful — it could not bind the port anyway.
        logger.warn('SYSTEM', 'Port still bound entering restart fallback — verifying current port owner instead of spawning', { port, portWaitSkipped: handoffSawLiveWorker });
      }
      try {
        if (spawnLockHeld) {
          const restartPid = spawnDaemon(restartScript, port);
          if (restartPid === undefined) {
            console.error('Failed to spawn worker daemon during restart.');
            // Manual release: process.exit() does not unwind to finally.
            releaseSpawnLock();
            process.exit(1);
          }
          spawnedScript = restartScript;
          logger.info('SYSTEM', 'Worker restart spawned (CLI fallback)', { pid: restartPid, script: restartScript });
          // Hold the lock until the spawned worker owns the port (the spawn
          // isn't "done" until then — same rule as the other gated
          // launchers); the longer verification below runs unlocked.
          await waitForHealth(port, getPlatformTimeout(15000));
        } else if (restartFreed) {
          spawnedScript = 'none (another launcher holds the spawn lock)';
          logger.info('SYSTEM', 'Another launcher holds the spawn lock — skipping CLI restart spawn and verifying its worker');
        }
      } finally {
        if (spawnLockHeld) releaseSpawnLock();
      }
      // Restart must prove itself: the new worker has to answer /api/health
      // with a different pid than the old worker and this CLI's own baked
      // version, before the hard deadline — otherwise exit 1.
      const verification = await verifyRestartedWorker(port, oldPid, packageVersion, getPlatformTimeout(30000));
      if (!verification.ok) {
        console.error(`Worker restart verification failed (old pid: ${oldPid ?? 'none'}, expected version: ${packageVersion}, spawned script: ${spawnedScript}); ${verification.lastObserved}${handoffDetail}`);
        process.exit(1);
      }
      console.log(`Worker restart verified (pid: ${verification.pid}, version: ${verification.version})`);
      logger.info('SYSTEM', 'Worker restart verified', { pid: verification.pid, version: verification.version });
      process.exit(0);
      break;
    }

    case 'status': {
      // Source of truth is GET /api/health: the worker self-reports pid,
      // version, uptime and script path (Phase 5, worker-restart plan). The
      // PID file is diagnostics only — it must never make `status` lie in
      // either direction (a clobbered file reporting a healthy worker as
      // down, or a stale file reporting a dead worker as up). Exit code is 0
      // on every branch, matching the historical behavior.
      const health = await fetchWorkerHealth(port, getPlatformTimeout(3000));
      if (health && typeof health.pid === 'number') {
        console.log('Worker is running');
        console.log(`  PID: ${health.pid}`);
        console.log(`  Port: ${port}`);
        if (typeof health.version === 'string') {
          console.log(`  Version: ${health.version}`);
        }
        if (typeof health.uptime === 'number') {
          console.log(`  Uptime: ${health.uptime}s`);
        }
        if (typeof health.workerPath === 'string') {
          console.log(`  Worker path: ${health.workerPath}`);
        }
        const dependencyHint = formatDependencyHealthHint(health);
        if (dependencyHint) {
          console.log(dependencyHint);
        }
        printQueueStatusIfBullMq(health);
        process.exit(0);
      }
      if (await isPortInUse(port)) {
        // Something owns the port but cannot answer /api/health — a wedged
        // worker mid-boot/mid-death, or a foreign process. Say so instead of
        // guessing in either direction.
        console.log(`Worker port ${port} is in use but health is unreachable (worker may be wedged or still booting)`);
        process.exit(0);
      }
      console.log('Worker is not running');
      process.exit(0);
      break;
    }

    case 'server-start':
    case 'server-stop':
    case 'server-restart':
    case 'server-status': {
      runServerServiceCli(command.slice('server-'.length));
      break;
    }

    case 'server-api-key': {
      const apiKeyCommand = commandArgs[0];
      if (apiKeyCommand === 'create' || apiKeyCommand === 'list' || apiKeyCommand === 'revoke') {
        runServerApiKeyCli(commandArgs);
      }
      if (apiKeyCommand === 'migrate-scopes') {
        // #2560 — scope migration runs against the SQLite local backend here.
        runServerApiKeyCli(commandArgs);
      }
      console.error(`Unknown server api-key subcommand: ${apiKeyCommand ?? '(none)'}`);
      console.error('Usage: worker-service server api-key create|list|revoke|migrate-scopes');
      process.exit(1);
      break;
    }

    // #2572 — `keys`/`jobs` are server (Postgres) operability commands.
    // Delegate to the server script so they read the Postgres backend the
    // server runtime actually uses, instead of the SQLite worker store.
    case 'server-keys': {
      runServerServiceCli('server', ['keys', ...commandArgs]);
      break;
    }

    case 'server-jobs': {
      runServerServiceCli('server', ['jobs', ...commandArgs]);
      break;
    }

    case 'server-help': {
      printServerCommandHelp();
      break;
    }

    case 'worker-help': {
      printWorkerAliasHelp();
      break;
    }

    case 'cursor': {
      const subcommand = process.argv[3];
      const cursorResult = await handleCursorCommand(subcommand, process.argv.slice(4));
      process.exit(cursorResult);
      break;
    }

    case 'antigravity-cli': {
      const antigravitySubcommand = process.argv[3];
      const antigravityResult = await handleAntigravityCliCommand(antigravitySubcommand, process.argv.slice(4));
      process.exit(antigravityResult);
      break;
    }

    case 'hook': {
      // IO discipline: this case is the entry point to the hook execution path.
      // Once hookCommand is invoked, src/shared/hook-io.ts owns all
      // stdout/stderr/exit. The pre-hookCommand error paths below (missing args,
      // worker failed to start) are CLI-style: console.error + exit 1 is
      // acceptable because they occur BEFORE the buffered window opens.
      const platform = process.argv[3];
      const event = process.argv[4];
      if (!platform || !event) {
        console.error('Usage: claude-mem hook <platform> <event>');
        console.error('Platforms: claude-code, codex, cursor, antigravity-cli, raw');
        console.error('Events: context, session-init, observation, summarize, user-message');
        process.exit(1);
      }

      const workerStartResult = await ensureWorkerStarted(port);
      if (workerStartResult === 'dead') {
        logger.warn('SYSTEM', 'Worker failed to start before hook, handler will proceed gracefully');
      }

      const { hookCommand } = await import('../cli/hook-command.js');
      await hookCommand(platform, event);
      break;
    }

    case 'generate': {
      const dryRun = process.argv.includes('--dry-run');
      const { generateClaudeMd } = await import('../cli/claude-md-commands.js');
      const result = await generateClaudeMd(dryRun);
      process.exit(result);
      break;
    }

    case 'clean': {
      const dryRun = process.argv.includes('--dry-run');
      const { cleanClaudeMd } = await import('../cli/claude-md-commands.js');
      const result = await cleanClaudeMd(dryRun);
      process.exit(result);
      break;
    }

    case 'transcript': {
      // npx-cli falls back to `worker-service.cjs transcript <sub>` when the
      // standalone `transcript-watcher.cjs` is not present in the bundle
      // (see thedotmack/claude-mem 2450). Dispatch to the shared
      // implementation so `init`, `watch`, and `validate` all work
      // regardless of which entry point the user invokes.
      const { runTranscriptCommand } = await import('./transcripts/cli.js');
      const exitCode = await runTranscriptCommand(commandArgs[0], commandArgs.slice(1));
      process.exit(exitCode);
      break;
    }

    case 'adopt': {
      const dryRun = process.argv.includes('--dry-run');
      const branchIndex = process.argv.indexOf('--branch');
      const branchValue = branchIndex !== -1 ? process.argv[branchIndex + 1] : undefined;
      if (branchIndex !== -1 && (!branchValue || branchValue.startsWith('--'))) {
        console.error('Usage: adopt [--dry-run] [--branch <branch>] [--cwd <path>]');
        process.exit(1);
      }
      const onlyBranch = branchValue;
      const cwdIndex = process.argv.indexOf('--cwd');
      const cwdValue = cwdIndex !== -1 ? process.argv[cwdIndex + 1] : undefined;
      if (cwdIndex !== -1 && (!cwdValue || cwdValue.startsWith('--'))) {
        console.error('Usage: adopt [--dry-run] [--branch <branch>] [--cwd <path>]');
        process.exit(1);
      }
      const repoPath = cwdValue ?? process.cwd();

      const result = await adoptMergedWorktrees({ repoPath, dryRun, onlyBranch });

      const tag = result.dryRun ? '(dry-run)' : '(applied)';
      console.log(`\nWorktree adoption ${tag}`);
      console.log(`  Parent project:       ${result.parentProject || '(unknown)'}`);
      console.log(`  Repo:                 ${result.repoPath}`);
      console.log(`  Worktrees scanned:    ${result.scannedWorktrees}`);
      console.log(`  Merged branches:      ${result.mergedBranches.join(', ') || '(none)'}`);
      console.log(`  Observations adopted: ${result.adoptedObservations}`);
      console.log(`  Summaries adopted:    ${result.adoptedSummaries}`);
      console.log(`  Chroma docs updated:  ${result.chromaUpdates}`);
      if (result.chromaFailed > 0) {
        console.log(`  Chroma sync failures: ${result.chromaFailed} (will retry on next run)`);
      }
      for (const err of result.errors) {
        console.log(`  ! ${err.worktree}: ${err.error}`);
      }
      process.exit(0);
    }

    case 'cleanup': {
      const dryRun = process.argv.includes('--dry-run');
      const counts = runOneTimeV12_4_3Cleanup(undefined, { dryRun });
      const tag = dryRun ? '(dry-run, no changes made)' : '(applied)';
      console.log(`\nv12.4.3 cleanup ${tag}`);
      if (counts) {
        console.log(`  Observer sessions:        ${counts.observerSessions}`);
        console.log(`  Observer cascade rows:    ${counts.observerCascadeRows}`);
        console.log(`  Stuck pending_messages:   ${counts.stuckPendingMessages}`);
      } else if (dryRun) {
        console.log('  Scan failed — see worker log for details.');
      } else {
        console.log('  Already applied (marker present) or skipped.');
      }
      process.exit(0);
    }

    case '--daemon':
    default: {
      // Duplicate gate, ground truth FIRST (Phase 5): a live worker owns the
      // port — the port cannot be faked by a stale or clobbered file. Exit 0:
      // duplicate suppression is a success, not a failure.
      if (await isPortInUse(port)) {
        logger.info('SYSTEM', 'Port already in use, refusing to start duplicate', { port });
        process.exit(0);
      }

      // PID file second, ADVISORY only: it covers a dying-but-still-alive
      // predecessor whose port has already been released (so the port check
      // above misses it) but whose owned PID file has not been deleted yet.
      // It does NOT cover a just-spawned worker that hasn't bound the port:
      // writePidFile runs after server.listen, so that worker has no file.
      // The worker itself remains the sole writer of this file
      // (writePidFile/touchPidFile stay as diagnostics).
      const existingPidInfo = readPidFile();
      if (verifyPidFileOwnership(existingPidInfo)) {
        logger.info('SYSTEM', 'Worker already running (PID alive), refusing to start duplicate', {
          existingPid: existingPidInfo.pid,
          existingPort: existingPidInfo.port,
          startedAt: existingPidInfo.startedAt
        });
        process.exit(0);
      }

      process.on('unhandledRejection', (reason) => {
        logger.error('SYSTEM', 'Unhandled rejection in daemon', {
          reason: reason instanceof Error ? reason.message : String(reason)
        });
      });
      process.on('uncaughtException', (error) => {
        logger.error('SYSTEM', 'Uncaught exception in daemon', {}, error as Error);
        // Don't exit — keep the HTTP server running
      });

      const worker = new WorkerService();
      worker.start().catch(async (error) => {
        const isPortConflict = error instanceof Error && (
          (error as NodeJS.ErrnoException).code === 'EADDRINUSE' ||
          /port.*in use|address.*in use/i.test(error.message)
        );
        if (isPortConflict && await waitForHealth(port, 3000)) {
          logger.info('SYSTEM', 'Duplicate daemon exiting — another worker already claimed port', { port });
          process.exit(0);
        }
        logger.failure('SYSTEM', 'Worker failed to start', {}, error as Error);
        // Owner-or-dead guarded (Phase 5): clean up our own PID file (written
        // in start() before the failure) or a dead leftover, but never a live
        // competitor's — e.g. a port-conflict loser whose error didn't match
        // the EADDRINUSE detection above must not clobber the winner's file.
        removePidFileIfOwner(process.pid);
        // Genuine start failure (not duplicate suppression): exit non-zero so
        // the restart verifier and any supervising caller see a dead boot
        // instead of a silent "success".
        process.exit(1);
      });
    }
  }
}

export interface WorkerHealthSnapshot {
  status?: unknown;
  pid?: unknown;
  version?: unknown;
  uptime?: unknown;
  workerPath?: unknown;
  dependencies?: DependencyHealthSnapshot;
  queue?: {
    redis?: {
      status?: string;
      host?: string;
      port?: number;
      mode?: string;
      prefix?: string;
      error?: string;
    };
  };
}

export function formatDependencyHealthHint(health: WorkerHealthSnapshot): string | null {
  const dependencies = health.dependencies;
  if (!dependencies?.degraded || dependencies.statuses.length === 0) {
    return null;
  }

  const labels = dependencies.statuses.map(status => {
    if (status.dependency === 'claude_cli' && status.kind === 'setup_required') {
      return 'Claude CLI setup required';
    }
    if (status.dependency === 'uvx' && status.kind === 'vector_search_unavailable') {
      return 'uvx unavailable for vector search';
    }
    if (status.dependency === 'chroma' && status.kind === 'vector_search_unavailable') {
      return 'Chroma unavailable for vector search';
    }
    return `${status.dependency}: ${status.kind}`;
  });

  return `  Dependencies: degraded (${labels.join(', ')}). Run npx claude-mem doctor or open Settings for remediation.`;
}

/**
 * Fetch the worker's self-reported state from GET /api/health. Returns null
 * when nothing answers (connection refused, timeout, non-JSON body).
 * /api/health answers 503 when the queue is degraded but still includes
 * pid/version/uptime — a degraded worker is still a RUNNING worker, so both
 * 200 and 503 payloads are returned as-is.
 */
async function fetchWorkerHealth(port: number, timeoutMs: number): Promise<WorkerHealthSnapshot | null> {
  try {
    const response = await fetchWithTimeout(`http://${getWorkerHost()}:${port}/api/health`, {}, timeoutMs);
    return await response.json() as WorkerHealthSnapshot;
  } catch {
    // [ANTI-PATTERN IGNORED]: health probe — connection refused/timeout IS the "worker not running" answer, polled on every status check; logging would spam. null is the documented recovery value the callers branch on.
    return null;
  }
}

/**
 * Print BullMQ queue detail from an already-fetched /api/health snapshot.
 * A degraded worker answers 503 but still includes the queue block, and
 * `status` already treats that worker as running — so this must not
 * re-fetch and bail on a non-2xx response (which hid the queue detail
 * behind "BullMQ health unavailable (HTTP 503)"). Reusing the snapshot in
 * hand keeps the output consistent with what `status` just reported.
 */
function printQueueStatusIfBullMq(health: WorkerHealthSnapshot): void {
  if (SettingsDefaultsManager.get('CLAUDE_MEM_QUEUE_ENGINE').trim().toLowerCase() !== 'bullmq') {
    return;
  }
  const redis = health.queue?.redis;
  if (!redis) {
    return;
  }
  const target = `${redis.host ?? 'unknown'}:${redis.port ?? 'unknown'}`;
  const suffix = redis.status === 'ok' ? '' : ` (${redis.error ?? 'unhealthy'})`;
  console.log(`  Queue: BullMQ Redis ${redis.status ?? 'unknown'} at ${target} [${redis.mode ?? 'external'}, prefix=${redis.prefix ?? 'claude_mem'}]${suffix}`);
}

const isMainModule = typeof require !== 'undefined' && typeof module !== 'undefined'
  ? require.main === module || !module.parent || process.env.CLAUDE_MEM_MANAGED === 'true'
  : (Boolean(process.argv[1]) && import.meta.url === pathToFileURL(process.argv[1]).href)
    || process.argv[1]?.endsWith('worker-service')
    || process.argv[1]?.endsWith('worker-service.cjs')
    || process.argv[1]?.replaceAll('\\', '/') === __filename?.replaceAll('\\', '/');

if (isMainModule) {
  main().catch((error) => {
    logger.error('SYSTEM', 'Fatal error in main', {}, error instanceof Error ? error : undefined);
    process.exit(0);  
  });
}

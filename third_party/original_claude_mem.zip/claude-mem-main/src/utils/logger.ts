
import { appendFileSync, existsSync, mkdirSync, readFileSync } from 'fs';
import { join } from 'path';
import { paths } from '../shared/paths.js';
import { emitDiagnostic } from '../shared/hook-io.js';
import { parseJsonWithBom } from '../shared/atomic-json.js';

export enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
  SILENT = 4
}

export type Component =
  | 'AGENTS_MD'
  | 'BRANCH'
  | 'CHROMA'
  | 'CHROMA_MCP'
  | 'CHROMA_SYNC'
  | 'CLAUDE_MD'
  | 'CLOUD_SYNC'
  | 'CONFIG'
  | 'CONSOLE'
  | 'CURSOR'
  | 'DB'
  | 'DEDUP'
  | 'ENV'
  | 'FOLDER_INDEX'
  | 'GIT'
  | 'HOOK'
  | 'HTTP'
  | 'IMPORT'
  | 'INGEST'
  | 'OAUTH'
  | 'OPENCLAW'
  | 'OPENCODE'
  | 'PARSER'
  | 'PROCESS'
  | 'PROJECT_NAME'
  | 'QUEUE'
  | 'SDK'
  | 'SDK_SPAWN'
  | 'SEARCH'
  | 'SECURITY'
  | 'SESSION'
  | 'SETTINGS'
  | 'SHUTDOWN'
  | 'SYNC_APPLY'
  | 'SYNC_CLIENT'
  | 'SYSTEM'
  | 'TELEGRAM'
  | 'TRANSCRIPT'
  | 'WINDSURF'
  | 'WORKER';

interface LogContext {
  sessionId?: string | number;
  memorySessionId?: string;
  correlationId?: string | number;
  [key: string]: any;
}

/**
 * Optional error sink. The logger must NEVER import the telemetry client (that
 * would create an import cycle: telemetry → logger via instrument.ts → ...).
 * Instead worker/telemetry init injects a sink via logger.setErrorSink(); when
 * present, logger.error()/logger.failure() route their Error payload through it
 * (consent + rate-limit + kill-switch all enforced INSIDE the sink, i.e.
 * captureException). The sink is optional and swallow-all so logging keeps
 * working with telemetry disabled or uninstalled.
 */
export type ErrorSink = (err: unknown, ctx?: Record<string, unknown>) => void;
let errorSink: ErrorSink | null = null;


class Logger {
  private level: LogLevel | null = null;
  private useColor: boolean;
  private logFilePath: string | null = null;
  private logFileInitialized: boolean = false;

  constructor() {
    this.useColor = process.stdout.isTTY ?? false;
    // Don't initialize log file in constructor - do it lazily to avoid circular dependency
  }

  private ensureLogFileInitialized(): void {
    if (this.logFileInitialized) return;
    this.logFileInitialized = true;

    try {
      const logsDir = paths.logsDir();

      if (!existsSync(logsDir)) {
        mkdirSync(logsDir, { recursive: true });
      }

      const date = new Date().toISOString().split('T')[0];
      this.logFilePath = join(logsDir, `claude-mem-${date}.log`);
    } catch (error: unknown) {
      console.error('[LOGGER] Failed to initialize log file:', error instanceof Error ? error.message : String(error));
      this.logFilePath = null;
    }
  }

  private getLevel(): LogLevel {
    if (this.level === null) {
      try {
        const settingsPath = paths.settings();
        if (existsSync(settingsPath)) {
          const settingsData = readFileSync(settingsPath, 'utf-8');
          const settings = parseJsonWithBom<Record<string, any>>(settingsData);
          const envLevel = (settings.CLAUDE_MEM_LOG_LEVEL || 'INFO').toUpperCase();
          this.level = LogLevel[envLevel as keyof typeof LogLevel] ?? LogLevel.INFO;
        } else {
          this.level = LogLevel.INFO;
        }
      } catch (error: unknown) {
        console.error('[LOGGER] Failed to load log level from settings:', error instanceof Error ? error.message : String(error));
        this.level = LogLevel.INFO;
      }
    }
    return this.level;
  }

  private formatData(data: any): string {
    if (data === null || data === undefined) return '';
    if (typeof data === 'string') return data;
    if (typeof data === 'number') return data.toString();
    if (typeof data === 'boolean') return data.toString();

    if (typeof data === 'object') {
      if (data instanceof Error) {
        return this.getLevel() === LogLevel.DEBUG
          ? `${data.message}\n${data.stack}`
          : data.message;
      }

      if (Array.isArray(data)) {
        return `[${data.length} items]`;
      }

      const keys = Object.keys(data);
      if (keys.length === 0) return '{}';
      if (keys.length <= 3) {
        return JSON.stringify(data);
      }
      return `{${keys.length} keys: ${keys.slice(0, 3).join(', ')}...}`;
    }

    return String(data);
  }

  formatTool(toolName: string, toolInput?: any): string {
    if (!toolInput) return toolName;

    let input = toolInput;
    if (typeof toolInput === 'string') {
      try {
        input = JSON.parse(toolInput);
      } catch {
        // [ANTI-PATTERN IGNORED]: tool_input is often a plain non-JSON string, so parse failure is the expected signal here; recovery is falling back to the raw string, and logging would spam every formatted log line.
        input = toolInput;
      }
    }

    if (toolName === 'Bash' && input.command) {
      return `${toolName}(${input.command})`;
    }

    if (input.file_path) {
      return `${toolName}(${input.file_path})`;
    }

    if (input.notebook_path) {
      return `${toolName}(${input.notebook_path})`;
    }

    if (toolName === 'Glob' && input.pattern) {
      return `${toolName}(${input.pattern})`;
    }

    if (toolName === 'Grep' && input.pattern) {
      return `${toolName}(${input.pattern})`;
    }

    if (input.url) {
      return `${toolName}(${input.url})`;
    }

    if (input.query) {
      return `${toolName}(${input.query})`;
    }

    if (toolName === 'Task') {
      if (input.subagent_type) {
        return `${toolName}(${input.subagent_type})`;
      }
      if (input.description) {
        return `${toolName}(${input.description})`;
      }
    }

    if (toolName === 'Skill' && input.skill) {
      return `${toolName}(${input.skill})`;
    }

    if (toolName === 'LSP' && input.operation) {
      return `${toolName}(${input.operation})`;
    }

    return toolName;
  }

  private formatTimestamp(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    const ms = String(date.getMilliseconds()).padStart(3, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${ms}`;
  }

  private log(
    level: LogLevel,
    component: Component,
    message: string,
    context?: LogContext,
    data?: any
  ): void {
    if (level < this.getLevel()) return;

    this.ensureLogFileInitialized();

    const timestamp = this.formatTimestamp(new Date());
    const levelStr = LogLevel[level].padEnd(5);
    const componentStr = component.padEnd(6);

    let correlationStr = '';
    if (context?.correlationId) {
      correlationStr = `[${context.correlationId}] `;
    } else if (context?.sessionId) {
      correlationStr = `[session-${context.sessionId}] `;
    }

    let dataStr = '';
    if (data !== undefined && data !== null) {
      if (data instanceof Error) {
        dataStr = this.getLevel() === LogLevel.DEBUG
          ? `\n${data.message}\n${data.stack}`
          : ` ${data.message}`;
      } else if (this.getLevel() === LogLevel.DEBUG && typeof data === 'object') {
        try {
          dataStr = '\n' + JSON.stringify(data, null, 2);
        } catch {
          // [ANTI-PATTERN IGNORED]: JSON.stringify fails on circular/BigInt payloads, an expected data shape inside the logger's own log() path; recovery is the formatData fallback, and self-logging here would recurse.
          dataStr = ' ' + this.formatData(data);
        }
      } else {
        dataStr = ' ' + this.formatData(data);
      }
    }

    let contextStr = '';
    if (context) {
      const { sessionId, memorySessionId, correlationId, ...rest } = context;
      if (Object.keys(rest).length > 0) {
        const pairs = Object.entries(rest).map(([k, v]) => `${k}=${v}`);
        contextStr = ` {${pairs.join(', ')}}`;
      }
    }

    const logLine = `[${timestamp}] [${levelStr}] [${componentStr}] ${correlationStr}${message}${contextStr}${dataStr}`;

    if (this.logFilePath) {
      try {
        appendFileSync(this.logFilePath, logLine + '\n', 'utf8');
      } catch (error: unknown) {
        // [ANTI-PATTERN IGNORED]: this is the logger's own file-write failure path — calling the logger here would recurse into the same failing appendFileSync, so the error is surfaced via emitDiagnostic to real stderr instead.
        // DIAGNOSTIC: route through hook-io so the message bypasses the Phase 2
        // hook stderr buffer (#2292). Outside the hook context emitDiagnostic
        // writes straight to real stderr, so non-hook callers are unaffected.
        const err = error instanceof Error ? error : new Error(String(error));
        emitDiagnostic(`[LOGGER] Failed to write to log file: ${err.message}\n${err.stack ?? ''}\n`);
      }
    } else {
      // DIAGNOSTIC: see note above.
      emitDiagnostic(logLine + '\n');
    }
  }

  debug(component: Component, message: string, context?: LogContext, data?: any): void {
    this.log(LogLevel.DEBUG, component, message, context, data);
  }

  info(component: Component, message: string, context?: LogContext, data?: any): void {
    this.log(LogLevel.INFO, component, message, context, data);
  }

  warn(component: Component, message: string, context?: LogContext, data?: any): void {
    this.log(LogLevel.WARN, component, message, context, data);
  }

  /**
   * Installs (or clears, with null) the optional error sink. Called once by
   * worker/telemetry init to bridge logged errors into captureException without
   * the logger importing telemetry (no import cycle). Never throws.
   */
  setErrorSink(sink: ErrorSink | null): void {
    errorSink = sink;
  }

  error(component: Component, message: string, context?: LogContext, data?: any): void {
    this.log(LogLevel.ERROR, component, message, context, data);
    this.routeErrorToSink(message, context, data);
  }

  /**
   * Routes a logged Error through the optional error sink (captureException).
   * Only fires when `data` is an actual Error so we never ship arbitrary log
   * payloads as exceptions. Swallow-all: the sink failing (or being absent)
   * must never break logging. `failure()` delegates to `error()`, so it is
   * covered too — but it passes the same `data` object, so we de-dupe by only
   * routing from the single `error()` entry point.
   */
  private routeErrorToSink(message: string, context?: LogContext, data?: any): void {
    try {
      if (!errorSink || !(data instanceof Error)) return;
      // Pass the message as context so the sink can fingerprint on it too; the
      // sink (captureException) scrubs everything through error-scrub /
      // scrubProperties, so an unsafe message here cannot leak — but `message`
      // is not whitelisted, so it is dropped by scrubProperties anyway. We pass
      // only the Error itself; context is intentionally minimal.
      errorSink(data);
    } catch {
      // Telemetry/error-sink must never break logging.
    }
  }

  dataIn(component: Component, message: string, context?: LogContext, data?: any): void {
    this.info(component, `→ ${message}`, context, data);
  }

  dataOut(component: Component, message: string, context?: LogContext, data?: any): void {
    this.info(component, `← ${message}`, context, data);
  }

  success(component: Component, message: string, context?: LogContext, data?: any): void {
    this.info(component, `✓ ${message}`, context, data);
  }

  failure(component: Component, message: string, context?: LogContext, data?: any): void {
    this.error(component, `✗ ${message}`, context, data);
  }
}

export const logger = new Logger();
